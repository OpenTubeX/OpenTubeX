const __jsExtractorGlobal = typeof globalThis !== 'undefined' ? globalThis :
  typeof self !== 'undefined' ? self :
  typeof window !== 'undefined' ? window :
  typeof global !== 'undefined' ? global : {};

const exportedVars = (function(g) {
  const window = typeof __jsExtractorGlobal.window !== 'undefined' ? __jsExtractorGlobal.window : Object.create(null);
  const document = typeof __jsExtractorGlobal.document !== 'undefined' ? __jsExtractorGlobal.document : {};
  const self = typeof __jsExtractorGlobal.self !== 'undefined' ? __jsExtractorGlobal.self : window;

  var KI, Xm, sZ, JO, Yf, gk, gSf, pMa, UH, CaF, Gx, uQ, Oo, ctH, qf, Rsa, yv, eE, Uo, x2f, XMQ, ThQ, tyy, nHa, Hfa, zlc, mC, $pa, Ia, bV, ZvL, Zm, Ul, MZ, $2Q, p7y, dI, s_, fx, pP, Gc, gq, mA, CP, Qs, Es, R5, Sf, Yj, ih, uy, KP, QH, mAu, Fa, Is, gS, p5, lR, ebc, WG, sf, KHu, kG, kD, GT, JF, os, QpF, kj, lh, qj, Q6, CsD, Us, Nj, jZ, F3, lDa, T56, VA, vJ, BJ, jw, p0D, Fy, WT, jz, vT, BT, N5, gkX, Hb, xJ, zVA, CQp, EDY, NZ, WY, uc, RjF, lLL, WJ, Xy, r0, td6, aB, fLX, JID, G5L, w0, k5H, j0a, SU, MC, NTE, La, qgf, TV, om, rwD, Ca, nCf, mGH, C9a, Zy, zjO, Uk, Uw, N4, Qe, Pf, yg, AwF, ILd, Q0u, Hq, d0, E3, qH, Fu, QD, NR, jr, er, P1, yD, IN, Yby, VdE, BTE, zV, Ka, i5, DGu, g0, Znd, F1f, yZ, mHI, fd, ECa, NC, L1D, dGE, w0D, Yg6, Hnc, cwH, X0E, frD, Nb, gCQ, xG6, qC, eU, FJf, vQ, eN, BQ, NK, q8D, U_, S8d, R_X, nH, $X, zh, iE, E_, aDF, MD6, wI, f1u, D2H, qZ, OH, u7E, ZF, hA, tA, YG, zT, Ao, Kx, JC, nP, BR, vR, cU, K$, hIa, L$, rq, LP, dq, bh, wq, as, Mj, o5, FZ, oJF, a5, C$, dj, BU, by, ef, Ue, QX, yX, HU, qT, WdQ, qP, Dha, RUQ, TGL, pyE, V_y, t_L, Sgy, IE, PY, ATH, WI, ID, VHa, vSE, Jv, qBQ, BhL, juu, kQf, GQD, Ro, N9D, HNH, lsE, wSF, M8f, rdc, HUQ, asH, XSL, x6f, Kt, i6L, xo, Hy, rv, MjH, H6E, Eb, mK, Trf, ZNF, thX, umE, Xu, zt, FuX, ij, Gt, SOy, wv, b6H, wcD, i$, be, $i, auF, CNa, zSy, EH, nba, Vo, du, Jr, Vaa, AC, Zia, qp, ir, WLc, V7, QPu, QZ, zq, QWX, vbQ, GS, GrO, HT, M5, xPy, Hxc, A2, hSO, oba, WJu, Ke, XRu, ki, gB, Tp, gHE, wB, Ce, S2D, cAF, iT, $v, pRE, zp, R2f, TKf, lpy, xv, ft, Yv, JAf, a8, J2, MeF, ic, Az, Ff, HJ, fDf, oHH, F1, um, oa, qVH, ZD, DD, v7, O5E, B7, PRD, FCd, Gn, N7, QGH, tV, ACF, q7, am, bc, knc, Jma, Ol, rmX, Ld, nJQ, nd, l5, ara, sWD, Lda, bv6, wbu, dhH, ZbL, RIX, PrQ, md, E0, gG, cy, S0f, Y0F, M_f, bny, inf, $GO, s0c, xc, zId, Cd, m2, mhf, Cd6, EJX, XbL, xhD, tDX, lry, FK, agy, MQf, nb, rc, mp6, dp6, Kb, CRQ, E8, H5a, rCu, sGQ, b5E, wjX, xpf, cVc, ao, JVf, rI, Th, tHL, kWO, n$, O2, FQ, U2, ow, xsL, m$, Ee, Iw, w7c, bbH, u$, Ek, mO, x7E, HQ, saQ, O_, qK, H1, IDL, FgD, Kga, Cmd, z_E, npy, EpX, m7D, Qw, goL, ibF, $7d, F9, MK, VZ, iXu, fW, uD, Ms, hL, LAH, ChO, zaQ, iPu, sn, Jt, YS, kg, njO, EjH, a1, Z3, fE, dZ, wZ, PS, OZ, EM, FA, rZ, dT;

  //#region --- start [nsigFunction] ---
  var Q = "1970-01-01T04:15:08.000+04:15;splice;rr;path;&;;local;cmo=td;join;push;slice;length;\\.a1\\.googlevideo\\.com$;url;,;/;cmo=pf;scheme;=;B;split;/file/index.m3u8;call;Bh;mn;indexOf;K;W;1970-01-01T05:30:01.000+05:30;s;S;http://local;get;/videoplayback;startsWith;1970-01-01T02:30:05.000+02:30;set;Untrusted URL;pH;gC;sp;undefined;://;1;reverse;fromCharCode;forEach;signatureCipher;sN;www.youtube.com;1969-12-31T18:30:22.000-05:30;assign;vX;clone;file;Ij;unshift;playerfallback;rr?[1-9].*\\.c\\.youtube\\.com$;fallback_count;NaN;SIDjcN1boUM7aEBkt7-_w8_;toString;/api/manifest;//;match;1969-12-31T21:30:56.000-02:30;youtube.player.web_20260921_09_RC00;false;https://local;index.m3u8;pop;n;/initplayback;replace;1970-01-01T11:15:49.000+11:15;1970-01-01T03:15:30.000+03:15;a1.googlevideo.com;%3D;\\.googlevideo\\.com$;1969-12-31T16:00:18.000-08:00;lyDoEBV;redirector.googlevideo.com;fvip;true;/[\u220d;cmo;1970-01-01T04:31:34.000+04:30;1969-12-31T16:00:00.000-08:00;U0;r;Z".split(";");
  g.U3 = class extends Error{constructor(f,...k){super(f);this.args=[...k];Object.setPrototypeOf(this,new.target.prototype)}};
  var u9F = RegExp("^((http(s)?):)?\\/\\/((((lh[3-6](-tt|-d[a-g,z])?\\.((ggpht)|(googleusercontent)|(google)|(sandbox\\.google)))|(lh7\\-(eu|us|qw|rt|xx)\\.((googleusercontent)|(google)))|((photos|testonly|work)\\.fife\\.usercontent\\.google)|([\\w\\-]+\\.fife\\.usercontent\\.google)|(([1-4]\\.bp\\.blogspot)|(bp[0-3]\\.blogger))|(ccp-lh\\.googleusercontent)|((((cp|ci|gp)[3-6])|(ap[1-2]))\\.(ggpht|googleusercontent))|(gm[1-4]\\.ggpht)|(play-(ti-)?lh\\.googleusercontent)|(gz[0-1]\\.googleusercontent)|(lh3\\-gm\\.google)|(((yt[3-4])|(sp[1-3]))\\.(ggpht|googleusercontent)))\\.com)|(drive\\.google\\.com\\/drive\\-(usercontent|viewer))|(dp[3-6]\\.googleusercontent\\.cn)|(dp4\\.googleusercontent\\.com)|((photos|drive|contribution)\\-image\\-(dev|qa)(-us|-eu)?(-auth|-cookie)?\\.corp\\.google\\.com)|(photos\\-image\\-dev\\-dl\\-(auth|eu|us)\\.corp\\.google\\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\\.sandbox\\.google\\.com\\/image)|(image\\-(dev|qa)\\-lighthouse(-auth)?\\.sandbox\\.google\\.com(\\/image)?)|(drive\\-qa\\.corp\\.google\\.com\\/drive\\-(usercontent|viewer))|(docs(\\-(dev|qa)\\.corp)?\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|email\\-layouts)\\-images\\-(rt|qw|xx))|(docs\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|email\\-layouts)\\-images)|(sites\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(atari-green-test\\.corp\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(sites\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images))\\/|^https://([A-Za-z0-9-]{1,63}\\.)+demos\\.corp\\.google\\.com(/(?!url\\b)|$)|^https://([A-Za-z0-9-]{1,63}\\.)+sslproxy\\.corp\\.google\\.com(/|$)|^https?://(([A-Za-z0-9-]{1,63}\\.)*(corp\\.google\\.com|proxy\\.googleprod\\.com|c\\.googlers\\.com|proxy\\.googlers\\.com|borg\\.google\\.com|docs\\.google\\.com|drive\\.google\\.com|googleplex\\.com|googlevideo\\.com|prod\\.google\\.com|lh3\\.photos\\.google\\.com|mail\\.google\\.com|youtube\\.com|yt\\.akamaized\\.net|chat\\.google\\.com)[.]?(:[0-9]+)?/|([A-Za-z0-9-]{1,63}\\.)*(sandbox\\.google\\.com)(:[0-9]+)?(/(?!url\\b)|$)|([A-Za-z0-9-]{1,63}\\.)*c\\.lh3(-d[a-gyz]|-testonly)?\\.(googleusercontent|photos\\.google)\\.com/.*$)");
  var hBu = RegExp("^https?://([A-Za-z0-9-]{1,63}\\.)*(currents\\.google\\.com)[.]?(:[0-9]+)?/");
  var Ghd = !1;
  Yf = function(f,k,G){return k&&k.test(f)||Ghd&&G&&G.test(f)?!0:!1};
  g.Nd = {};
  var Nup = {};
  var oE = {};
  g.DR = function(f,k){return f in oE?oE[f]:k};
  pMa = function(f,k={}){if(f=f.dK){let G=f.Ony;f=[["componentStack",f.Bj],["wizTagName",f.tagName],["wizOwnerTrace",f.Y_H?.join(" > ")],["errorSeverity",f.HZ?.toString()],["wizFeatureFlags",G?Object.entries(G).join("\n"):void 0]];for(let [t,Z]of f)f=Z,f!==void 0&&(k[t]=f)}return k};
  UH = function(f,k){f=g.DR("EXPERIMENT_FLAGS",{})[f];return f!==void 0?f:k};
  g.e3 = function(f,k){f=UH(f,k);return typeof f==="string"&&f==="false"?!1:!!f};
  var Jt6 = [];
  var f3f = [];
  g.qd = function(f,k){f=f.split(".");k=k||g.Nd;for(var G=0;G<f.length;G++)if(k=k[f[G]],k==null)return null;return k};
  uQ = function(f){var k="";typeof f.toString==="function"&&(k=""+f);return k+f.stack};
  Gx = function(f,k){k||(k={});k[uQ(f)]=!0;var G=f.stack||"",t=f.cause;t&&!k[uQ(t)]&&(G+="\nCaused by: ",t.stack&&t.stack.indexOf(t.toString())==0||(G+=typeof t==="string"?t:t.message+"\n"),G+=Gx(t,k));f=f.errors;if(Array.isArray(f)){t=1;let Z;for(Z=0;Z<f.length&&!(t>4);Z++)k[uQ(f[Z])]||(G+="\nInner error "+t++ +": ",f[Z].stack&&f[Z].stack.indexOf(f[Z].toString())==0||(G+=typeof f[Z]==="string"?f[Z]:f[Z].message+"\n"),G+=Gx(f[Z],k));Z<f.length&&(G+="\n... "+(f.length-Z)+" more inner errors")}return G};
  var tr = {};
  CaF = function(f){var k=g.qd("window.location.href");f==null&&(f='Unknown Error of type "null/undefined"');if(typeof f==="string")return{message:f,name:"Unknown error",lineNumber:"Not available",fileName:k,stack:"Not available"};var G=!1;try{var t=f.lineNumber||f.line||"Not available"}catch(u){t="Not available",G=!0}try{var Z=f.fileName||f.filename||f.sourceURL||g.Nd.$googDebugFname||k}catch(u){Z="Not available",G=!0}k=Gx(f);if(!(!G&&f.lineNumber&&f.fileName&&f.stack&&f.message&&f.name)){G=f.message;
if(G==null){if(f.constructor&&f.constructor instanceof Function){if(f.constructor.name)G=f.constructor.name;else if(G=f.constructor,tr[G])G=tr[G];else{G=String(G);if(!tr[G]){let u=/function\s+([^\(]+)/m.exec(G);tr[G]=u?u[1]:"[Anonymous]"}G=tr[G]}G='Unknown Error of type "'+G+'"'}else G="Unknown Error of unknown type";typeof f.toString==="function"&&Object.prototype.toString!==f.toString&&(G+=": "+f.toString())}return{message:G,name:f.name||"UnknownError",lineNumber:t,fileName:Z,stack:k||"Not available"}}return{message:f.message,
name:f.name,lineNumber:f.lineNumber,fileName:f.fileName,stack:k}};
  Oo = function(f){try{return(typeof f==="string"?f:String(JSON.stringify(f))).substr(0,500)}catch(k){return`unable to serialize ${typeof f} (${k.message})`}};
  qf = function(f,k,G,t){G+=`.${f}`;f=Oo(k);t[G]=f;return G.length+f.length};
  yv = function(f){var k=f(),G=k&127;if(k<128)return G;k=f();G|=(k&127)<<7;if(k<128)return G;k=f();G|=(k&127)<<14;if(k<128)return G;k=f();return k<128?G|(k&127)<<21:Infinity};
  Rsa = function(f){var k=f.length,G=0,t=()=>f.charCodeAt(G++);
do{var Z=yv(t);if(Z===Infinity)break;let u=Z>>3;switch(Z&7){case 0:Z=yv(t);if(u===2)return Z;break;case 1:if(u===2)return;G+=8;break;case 2:Z=yv(t);if(u===2)return f.substr(G,Z);G+=Z;break;case 5:if(u===2)return;G+=4;break;default:return}}while(G<k)};
  ctH = function(f,k,G,t){if(f)if(Array.isArray(f)){var Z=t;for(t=0;t<f.length&&!(f[t]&&(Z+=qf(t,f[t],k,G),Z>500));t++);t=Z}else if(typeof f==="object")for(Z in f){if(f[Z]){a:{var u=Z;var h=f[Z],W=k,D=G;if(typeof h!=="string"||u!=="clickTrackingParams"&&u!=="trackingParams"){u=0;break a}u=(h=Rsa(atob(h.replace(/-/g,"+").replace(/_/g,"/"))))?qf(`${u}.ve`,h,W,D):0}t+=u;t+=qf(Z,f[Z],k,G);if(t>500)break}}else G[k]=Oo(f),t+=G[k].length;else G[k]=Oo(f),t+=G[k].length;return t};
  var l1y = class{constructor(){this.t0=[];this.oU=[]}};
  Uo = undefined;
  x2f = function(f){if(f.name==="JavaException")return!0;f=f.stack;return f.includes("chrome://")||f.includes("-extension://")||f.includes("webkit-masked-url://")};
  XMQ = function(f){if(!f.stack)return!0;var k=!f.stack.includes("\n");return k&&f.stack.includes("ErrorType: ")||k&&f.stack.includes("Anonymous function (Unknown script")||f.stack.toLowerCase()==="not available"||f.fileName==="user-script"||f.fileName.startsWith("user-script:")?!0:!1};
  var SBy = {};
  ThQ = function(f,k){k.oU&&f.oU.unshift.apply(f.oU,k.oU);k.t0&&f.t0.unshift.apply(f.t0,k.t0)};
  eE = function(){if(!Uo){var f=Uo=new l1y;f.oU.length=0;f.t0.length=0;ThQ(f,SBy)}return Uo};
  var kGL = [];
  var FI = {};
  var Iz = class{constructor(f,k){this.B=f===FI&&k||""}toString(){return this.B}};
  g.I0 = function(){this.jC=this.jC;this.Jo=this.Jo};
  g.uT = function(f){g.I0.call(this);this.A=1;this.W=[];this.S=0;this.B=[];this.K={};this.V=!!f};
  g.n = g.uT.prototype;
  g.n.subscribe = function(f,k,G){var t=this.K[f];t||(t=this.K[f]=[]);var Z=this.A;this.B[Z]=f;this.B[Z+1]=k;this.B[Z+2]=G;this.A=Z+3;t.push(Z);return Z};
  g.n.unsubscribe = function(f,k,G){if(f=this.K[f]){let t=this.B;if(f=f.find(function(Z){return t[Z+1]==k&&t[Z+2]==G}))return this.B4(f)}return!1};
  g.op = function(f,k){return Array.prototype.splice.call(f,k,1).length==1};
  g.We = function(f,k){k=Array.prototype.indexOf.call(f,k,void 0);var G;(G=k>=0)&&g.op(f,k);return G};
  g.n.B4 = function(f){var k=this.B[f];if(k){let G=this.K[k];this.S!=0?(this.W.push(f),this.B[f+1]=()=>{}):(G&&g.We(G,f),delete this.B[f],delete this.B[f+1],delete this.B[f+2])}return!!k};
  mC = function(f){g.Nd.setTimeout(()=>{throw f;},0)};
  var MuD = class{constructor(){this.next=this.scope=this.B=null}set(f,k){this.B=f;
this.scope=k;this.next=null}reset(){this.next=this.scope=this.B=null}};
  var aAf = class{constructor(f,k){this.W=f;this.S=k;this.K=0;this.B=null}get(){if(this.K>0){this.K--;var f=this.B;this.B=f.next;f.next=null}else f=this.W();return f}put(f){this.S(f);this.K<100&&(this.K++,f.next=this.B,this.B=f)}};
  var i5L = {};
  var rYc = class{constructor(){this.K=this.B=null}add(f,k){var G=i5L.get();G.set(f,k);this.K?this.K.next=G:this.B=G;this.K=G}remove(){var f=null;this.B&&(f=this.B,this.B=this.B.next,this.B||(this.K=null),f.next=null);return f}};
  $pa = {};
  Ia = !1;
  zlc = function(){for(var f;f=$pa.remove();){try{f.B.call(f.scope)}catch(k){mC(k)}i5L.put(f)}Ia=!1};
  bV = undefined;
  Hfa = ()=>{var f=Promise.resolve(void 0);bV=()=>{f.then(zlc)}};
  g.Cb = (f,k)=>{bV||Hfa();Ia||(bV(),Ia=!0);$pa.add(f,k)};
  nHa = function(f,k,G){g.Cb(function(){f.apply(k,G)})};
  g.n.publish = function(f,k){var G=this.K[f];if(G){let Z=Array(arguments.length-1);var t=arguments.length;let u;for(u=1;u<t;u++)Z[u-1]=arguments[u];if(this.V)for(u=0;u<G.length;u++)t=G[u],nHa(this.B[t+1],this.B[t+2],Z);else{this.S++;try{for(u=0,t=G.length;u<t&&!this.xj();u++){let h=G[u];this.B[h+1].apply(this.B[h+2],Z)}}finally{if(this.S--,this.W.length>0&&this.S==0)for(;G=this.W.pop();)this.B4(G)}}return u!=0}return!1};
  g.n.clear = function(f){if(f){let k=this.K[f];k&&(k.forEach(this.B4,this),delete this.K[f])}else this.B.length=0,this.K={}};
  g.n.GB = function(){g.uT.bY.GB.call(this);this.clear();this.W.length=0};
  var AE = {};
  var ZWu = 0;
  g.UM = function(){return{innertubeApiKey:g.DR("INNERTUBE_API_KEY"),innertubeApiVersion:g.DR("INNERTUBE_API_VERSION"),xB:g.DR("INNERTUBE_CONTEXT_CLIENT_CONFIG_INFO"),La:g.DR("INNERTUBE_CONTEXT_CLIENT_NAME","WEB"),nI:g.DR("INNERTUBE_CONTEXT_CLIENT_NAME",1),innertubeContextClientVersion:g.DR("INNERTUBE_CONTEXT_CLIENT_VERSION"),On:g.DR("INNERTUBE_CONTEXT_HL"),uT:g.DR("INNERTUBE_CONTEXT_GL"),BW:g.DR("INNERTUBE_HOST_OVERRIDE")||"",K$:!!g.DR("INNERTUBE_USE_THIRD_PARTY_AUTH",!1),iZ:!!g.DR("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT",
!1),appInstallData:g.DR("SERIALIZED_CLIENT_CONFIG_DATA")}};
  ZvL = function(){return"INNERTUBE_API_KEY"in oE&&"INNERTUBE_API_VERSION"in oE};
  g.u8 = class{constructor(f){this.config_=null;f?this.config_=f:ZvL()&&(this.config_=g.UM())}isReady(){!this.config_&&ZvL()&&(this.config_=g.UM());return!!this.config_}};
  Ul = window;
  g.S = undefined;
  MZ = function(){var f=g.qd("_lact",window);return f==null?-1:Math.max(Date.now()-f,0)};
  var tE = {};
  $2Q = function(f){tE[f]=f in tE?tE[f]+1:0;return tE[f]};
  var G$ = [];
  g.eF = function(f,k,G){f=f.split(".");G=G||g.Nd;for(var t;f.length&&(t=f.shift());)f.length||k===void 0?G[t]&&G[t]!==Object.prototype[t]?G=G[t]:G=G[t]={}:G[t]=k};
  dI = function(f,k){var G=g.qd("yt.logging.transport.enableScrapingForTest"),t=UH("il_payload_scraping");t=(t!==void 0?String(t):"")==="enable_il_payload_scraping";if(!G)if(t)G$=[],g.eF("yt.logging.transport.enableScrapingForTest",!0),g.eF("yt.logging.transport.scrapedPayloadsForTesting",G$),g.eF("yt.logging.transport.payloadToScrape","visualElementShown visualElementHidden visualElementAttached screenCreated visualElementGestured visualElementStateChanged".split(" ")),g.eF("yt.logging.transport.getScrapedPayloadFromClientEventsFunction"),
g.eF("yt.logging.transport.scrapeClientEvent",!0);else return;G=g.qd("yt.logging.transport.scrapedPayloadsForTesting");t=g.qd("yt.logging.transport.payloadToScrape");k&&(k=k.payload,(k=g.qd("yt.logging.transport.getScrapedPayloadFromClientEventsFunction").bind(k)())&&G.push(k));k=g.qd("yt.logging.transport.scrapeClientEvent");if(t&&t.length>=1)for(let Z=0;Z<t.length;Z++)f&&f.payload[t[Z]]&&(k?G.push(f.payload):G.push((f?.payload)[t[Z]]));g.eF("yt.logging.transport.scrapedPayloadsForTesting",G)};
  var lE = {};
  var xX = [1,2];
  Gc = function(f,k=!1){return k&&Symbol.for&&f?Symbol.for(f):f!=null?Symbol(f):Symbol()};
  var kH = undefined;
  pP = function(f){return f[kH]??(f[kH]=new Map)};
  var ZQ = undefined;
  mA = function(f,k,G,t,Z){var u=G+(Z?0:-1),h=f.length-1;if(h>=1+(Z?0:-1)&&u>=h){let W=f[h];if(W!=null&&typeof W==="object"&&W.constructor===Object)return W[G]=t,k}if(u<=h)return f[u]=t,k;t!==void 0&&(h=(k??(k=f[ZQ]|0))>>14&1023||536870912,G>=h?t!=null&&(f[h+(Z?0:-1)]={[G]:t}):f[u]=t);return k};
  CP = function(f,k,G,t){if(k===-1)return null;var Z=k+(G?0:-1),u=f.length-1;if(!(u<1+(G?0:-1))){if(Z>=u){var h=f[u];if(h!=null&&typeof h==="object"&&h.constructor===Object){G=h[k];var W=!0}else if(Z===u)G=h;else return}else G=f[Z];if(t&&G!=null){t=t(G);if(t==null)return t;if(!Object.is(t,G))return W?h[k]=t:f[Z]=t,t}return G}};
  gq = function(f,k,G,t,Z){var u=f.get(t);if(u!=null)return u;u=0;for(let h=0;h<t.length;h++){let W=t[h];CP(k,W,Z)!=null&&(u!==0&&(G=mA(k,G,u,void 0,Z)),u=W)}f.set(t,u);return u};
  fx = function(f,k,G){f=f.q0;return gq(pP(f),f,void 0,k)===G?G:-1};
  var PR = {};
  var tF = {};
  Es = function(f,k,G,t,Z){Object.isExtensible(f);k=CP(f.q0,k,G,Z);if(k!==null||t&&f.S!==tF)return k};
  R5 = function(f){return f==null||typeof f==="string"?f:void 0};
  Qs = function(f,k){return R5(Es(f,k,void 0,PR))};
  Sf = function(f){if(f!=null&&typeof f!=="string")throw Error();return f};
  uy = function(f,k){return k===void 0?f.B!==tF&&!!(2&(f.q0[ZQ]|0)):!!(2&k)&&f.B!==tF};
  Fa = function(f,k,G){f=new f.constructor(k);G&&(f.B=tF);f.S=tF;return f};
  Is = function(f,k,G){return G&2?!0:G&32&&!(G&4096)?(k[ZQ]=G|2,f.B=tF,!0):!1};
  var gj = {};
  var p$ = undefined;
  var RG = {};
  p5 = function(f){if(f!==RG)throw Error("illegal external caller");};
  var XH = /[-_.]/g;
  var UAL = {"-":"+",_:"/",".":"="};
  ebc = function(f){return UAL[f]||""};
  lR = function(f){f=XH.test(f)?f.replace(XH,ebc):f;f=atob(f);var k=new Uint8Array(f.length);for(let G=0;G<f.length;G++)k[G]=f.charCodeAt(G);return k};
  gS = function(f){p5(RG);var k=f.B;k=k==null||k!=null&&k instanceof Uint8Array?k:typeof k==="string"?lR(k):null;return k==null?k:f.B=k};
  var SQ = class{isEmpty(){return this.B==null}sizeBytes(){var f=gS(this);return f?f.length:0}constructor(f,k){p5(k);this.B=f;if(f!=null&&f.length===0)throw Error("ByteString should be constructed with non-empty values");}};
  mAu = function(f,k){if(typeof f!=="object")return f;if(Array.isArray(f)){var G=f[ZQ]|0;f.length===0&&G&1?f=void 0:G&2||(!k||4096&G||16&G?f=QH(f,G,!1,k&&!(G&16)):(f[ZQ]|=34,G&4&&Object.freeze(f)));return f}if(f!=null&&f[p$]===gj)return k=f.q0,G=k[ZQ]|0,uy(f,G)?f:Is(f,k,G)?Fa(f,k):QH(k,G);if(f instanceof SQ)return f};
  var fP = undefined;
  sf = function(f){return f};
  var AWL = undefined;
  var f$ = void 0;
  kD = function(f,k){f.__closure__error__context__984382||(f.__closure__error__context__984382={});f.__closure__error__context__984382.severity=k};
  kG = function(f,k){if(f!=null){var G=f$??(f$={});var t=G[f]||0;t>=k||(G[f]=t+1,f=Error(),kD(f,"incident"),mC(f))}};
  KHu = function(f,k){k<100||kG(AWL,1)};
  GT = function(f,k){for(let G in f)!isNaN(G)&&k(f,+G,f[G])};
  JF = function(f){return f};
  os = undefined;
  var to = class{};
  QpF = function(f){var k=new to;GT(f,(G,t,Z)=>{k[t]=[...Z]});
k.bM=f.bM;return k};
  kj = function(f){var k=sf(fP);return k?f[k]:void 0};
  WG = function(f,k,G,t){var Z=t!==void 0;t=!!t;var u=sf(fP),h;!Z&&u&&(h=f[u])&&GT(h,KHu);u=[];var W=f.length;h=4294967295;var D=!1,V=!!(k&64),U=V?k&128?0:-1:void 0;if(!(k&1)){var e=W&&f[W-1];e!=null&&typeof e==="object"&&e.constructor===Object?(W--,h=W):e=void 0;!V||k&128||Z||(D=!0,h=(os??JF)(h-U,U,f,e,void 0)+U)}k=void 0;for(var q=0;q<W;q++){let O=f[q];if(O!=null&&(O=G(O,t))!=null)if(V&&q>=h){let F=q-U;(k??(k={}))[F]=O}else u[q]=O}if(e)for(let O in e){W=e[O];if(W==null||(W=G(W,t))==null)continue;q=
+O;let F;V&&!Number.isNaN(q)&&(F=q+U)<h?u[F]=W:(k??(k={}))[O]=W}k&&(D?u.push(k):u[h]=k);Z&&sf(fP)&&(f=kj(f))&&f instanceof to&&(u[fP]=QpF(f));return u};
  QH = function(f,k,G,t){t??(t=!!(34&k));f=WG(f,k,mAu,t);t=32;G&&(t|=2);k=k&16769217|t;f[ZQ]=k;return f};
  KP = function(f){if(f.B!==tF)return!1;var k=f.q0;k=QH(k,k[ZQ]|0);k[ZQ]|=2048;f.q0=k;f.B=void 0;f.S=void 0;return!0};
  ih = function(f){if(!KP(f)&&uy(f,f.q0[ZQ]|0))throw Error();};
  lh = function(f,k,G,t,Z){t===0||G.includes(t);var u=pP(f),h=gq(u,f,k,G,Z);h!==t&&(h&&(k=mA(f,k,h,void 0,Z)),u.set(G,t));return k};
  Yj = function(f,k,G,t){ih(f);var Z=f.q0,u=Z[ZQ]|0;if(t==null){let h=pP(Z);if(gq(h,Z,u,G)===k)h.set(G,0);else return f}else u=lh(Z,u,G,k);mA(Z,u,k,t);return f};
  Q6 = function(f,k){var G=g.qd("CLOSURE_FLAGS");f=G&&G[f];return f!=null?f:k};
  var PG = undefined;
  var EMX = undefined;
  CsD = function(){if(PG)throw Error("carr");kG(EMX,5)};
  qj = function(f,k,G,t=0){if(f==null){var Z=32;G?(f=[G],Z|=128):f=[];k&&(Z=Z&-16760833|(k&1023)<<14)}else{if(!Array.isArray(f))throw Error("narr");Z=f[ZQ]|0;if(PG&&1&Z)throw Error("rfarr");2048&Z&&!(2&Z)&&CsD();if(Z&256)throw Error("farr");if(Z&64)return(Z|t)!==Z&&(f[ZQ]=Z|t),f;if(G&&(Z|=128,G!==f[0]))throw Error("mid");a:{G=f;Z|=64;var u=G.length;if(u){var h=u-1;let D=G[h];if(D!=null&&typeof D==="object"&&D.constructor===Object){k=Z&128?0:-1;h-=k;if(h>=1024)throw Error("pvtlmt");for(var W in D)if(u=
+W,u<h)G[u+k]=D[W],delete D[W];else break;Z=Z&-16760833|(h&1023)<<14;break a}}if(k){W=Math.max(k,u-(Z&128?0:-1));if(W>1024)throw Error("spvt");Z=Z&-16760833|(W&1023)<<14}}}f[ZQ]=Z|64|t;return f};
  var iia = {};
  var $AE = undefined;
  var iFF = undefined;
  var $w6 = undefined;
  F3 = function(f){f.QLt=!0;return f};
  var Dj = undefined;
  jZ = function(f){switch(typeof f){case "number":return Number.isFinite(f)?f:""+f;case "bigint":return Dj(f)?Number(f):""+f;case "boolean":return f?1:0;case "object":if(Array.isArray(f)){var k=f[ZQ]|0;return f.length===0&&k&1?void 0:WG(f,k,jZ)}if(f!=null&&f[p$]===gj)return Nj(f);if(f instanceof SQ){k=f.B;if(k==null)f="";else if(typeof k==="string")f=k;else{let G="",t=0,Z=k.length-10240;for(;t<Z;)G+=String.fromCharCode.apply(null,k.subarray(t,t+=10240));G+=String.fromCharCode.apply(null,t?k.subarray(t):
k);k=btoa(G);f=f.B=k}return f}return}return f};
  Nj = function(f){f=f.q0;return WG(f,f[ZQ]|0,jZ)};
  Us = function(f,k){if(k){os=k==null||k===JF||k[$AE]!==iia?JF:k;try{return Nj(f)}finally{os=void 0}}return Nj(f)};
  var xb = class{constructor(f,k,G){this.q0=qj(f,k,G,2048)}toJSON(){return Us(this)}Bk(f){return JSON.stringify(Us(this,f))}clone(){var f=this.q0,k=f[ZQ]|0;return Is(this,f,k)?Fa(this,f,!0):new this.constructor(QH(f,k,!1))}};
  var GWD = class extends xb{constructor(f){super(f)}YX(){return Qs(this,fx(this,xX,1))}setVideoId(f){return Yj(this,1,xX,Sf(f))}getPlaylistId(){return Qs(this,fx(this,xX,2))}};
  var X9 = {};
  s_ = function(f,k=!1){var G="";if(f.dangerousLogToVisitorSession)G="visitorOnlyApprovedKey";else if(f.cttAuthInfo){if(k){k=f.cttAuthInfo.token;G=f.cttAuthInfo;let t=new GWD;G.videoId?t.setVideoId(G.videoId):G.playlistId&&Yj(t,2,xX,Sf(G.playlistId));X9[k]=t}else k=f.cttAuthInfo,G={},k.videoId?G.videoId=k.videoId:k.playlistId&&(G.playlistId=k.playlistId),lE[f.cttAuthInfo.token]=G;G=f.cttAuthInfo.token}return G};
  var KrD = {accountStateChangeSignedIn:23,accountStateChangeSignedOut:24,delayedEventMetricCaptured:11,latencyActionBaselined:6,latencyActionInfo:7,latencyActionTicked:5,offlineTransferStatusChanged:2,offlineImageDownload:335,playbackStartStateChanged:9,systemHealthCaptured:3,mangoOnboardingCompleted:10,mangoPushNotificationReceived:230,mangoUnforkDbMigrationError:121,mangoUnforkDbMigrationSummary:122,mangoUnforkDbMigrationPreunforkDbVersionNumber:133,mangoUnforkDbMigrationPhoneMetadata:134,mangoUnforkDbMigrationPhoneStorage:135,
mangoUnforkDbMigrationStep:142,mangoAsyncApiMigrationEvent:223,mangoDownloadVideoResult:224,mangoHomepageVideoCount:279,mangoHomeV3State:295,mangoImageClientCacheHitEvent:273,sdCardStatusChanged:98,framesDropped:12,thumbnailHovered:13,deviceRetentionInfoCaptured:14,thumbnailLoaded:15,backToAppEvent:318,streamingStatsCaptured:17,offlineVideoShared:19,appCrashed:20,youThere:21,offlineStateSnapshot:22,mdxSessionStarted:25,mdxSessionConnected:26,mdxSessionDisconnected:27,bedrockResourceConsumptionSnapshot:28,
nextGenWatchWatchSwiped:29,kidsAccountsSnapshot:30,zeroStepChannelCreated:31,tvhtml5SearchCompleted:32,offlineSharePairing:34,offlineShareUnlock:35,mdxRouteDistributionSnapshot:36,bedrockRepetitiveActionTimed:37,unpluggedDegradationInfo:229,uploadMp4HeaderMoved:38,uploadVideoTranscoded:39,uploadProcessorStarted:46,uploadProcessorEnded:47,uploadProcessorReady:94,uploadProcessorRequirementPending:95,uploadProcessorInterrupted:96,uploadFrontendEvent:241,assetPackDownloadStarted:41,assetPackDownloaded:42,
assetPackApplied:43,assetPackDeleted:44,appInstallAttributionEvent:459,playbackSessionStopped:45,adBlockerMessagingShown:48,distributionChannelCaptured:49,dataPlanCpidRequested:51,detailedNetworkTypeCaptured:52,sendStateUpdated:53,receiveStateUpdated:54,sendDebugStateUpdated:55,receiveDebugStateUpdated:56,kidsErrored:57,mdxMsnSessionStatsFinished:58,appSettingsCaptured:59,mdxWebSocketServerHttpError:60,mdxWebSocketServer:61,startupCrashesDetected:62,coldStartInfo:435,offlinePlaybackStarted:63,liveChatMessageSent:225,
liveChatUserPresent:434,liveChatBeingModerated:457,liveChatGiftButtonImpressed:558,liveCreationCameraUpdated:64,liveCreationEncodingCaptured:65,liveCreationError:66,liveCreationHealthUpdated:67,liveCreationVideoEffectsCaptured:68,liveCreationStageOccured:75,offlineSystemFailure:546,liveCreationBroadcastScheduled:123,liveCreationArchiveReplacement:149,liveCreationCostreamingConnection:421,liveCreationPlayablesMetrics:533,liveCreationStreamWebrtcStats:288,liveCreationWebrtcError:526,mdxSessionRecoveryStarted:69,
mdxSessionRecoveryCompleted:70,mdxSessionRecoveryStopped:71,visualElementShown:72,visualElementHidden:73,visualElementGestured:78,visualElementStateChanged:208,screenCreated:156,playbackAssociated:202,visualElementAttached:215,playbackContextEvent:214,cloudCastingPlaybackStarted:74,webPlayerApiCalled:76,tvhtml5AccountDialogOpened:79,foregroundHeartbeat:80,foregroundHeartbeatScreenAssociated:111,kidsOfflineSnapshot:81,mdxEncryptionSessionStatsFinished:82,playerRequestCompleted:83,liteSchedulerStatistics:84,
mdxSignIn:85,spacecastMetadataLookupRequested:86,spacecastBatchLookupRequested:87,spacecastSummaryRequested:88,spacecastPlayback:89,spacecastDiscovery:90,tvhtml5LaunchUrlComponentChanged:91,mdxBackgroundPlaybackRequestCompleted:92,mdxBrokenAdditionalDataDeviceDetected:93,tvhtml5LocalStorage:97,tvhtml5DeviceStorageStatus:147,autoCaptionsAvailable:99,playbackScrubbingEvent:339,flexyState:100,interfaceOrientationCaptured:101,mainAppBrowseFragmentCache:102,offlineCacheVerificationFailure:103,offlinePlaybackExceptionDigest:217,
vrCopresenceStats:104,vrCopresenceSyncStats:130,vrCopresenceCommsStats:137,vrCopresencePartyStats:153,vrCopresenceEmojiStats:213,vrCopresenceEvent:141,vrCopresenceFlowTransitEvent:160,vrCowatchPartyEvent:492,vrCowatchUserStartOrJoinEvent:504,vrPlaybackEvent:345,kidsAgeGateTracking:105,offlineDelayAllowedTracking:106,mainAppAutoOfflineState:107,videoAsThumbnailDownload:108,videoAsThumbnailPlayback:109,liteShowMore:110,renderingError:118,kidsProfilePinGateTracking:119,abrTrajectory:124,scrollEvent:125,
streamzIncremented:126,kidsProfileSwitcherTracking:127,kidsProfileCreationTracking:129,buyFlowStarted:136,integrationAttributionEvent:556,mbsConnectionInitiated:138,mbsPlaybackInitiated:139,mbsLoadChildren:140,liteProfileFetcher:144,mdxRemoteTransaction:146,reelPlaybackError:148,reachabilityDetectionEvent:150,mobilePlaybackEvent:151,courtsidePlayerStateChanged:152,musicPersistentCacheChecked:154,musicPersistentCacheCleared:155,playbackInterrupted:157,playbackInterruptionResolved:158,fixFopFlow:159,
anrDetection:161,backstagePostCreationFlowEnded:162,clientError:163,gamingAccountLinkStatusChanged:164,liteHousewarming:165,buyFlowEvent:167,kidsParentalGateTracking:168,kidsSignedOutSettingsStatus:437,kidsSignedOutPauseHistoryFixStatus:438,tvhtml5WatchdogViolation:444,ypcUpgradeFlow:169,yongleStudy:170,ypcUpdateFlowStarted:171,ypcUpdateFlowCancelled:172,ypcUpdateFlowSucceeded:173,ypcUpdateFlowFailed:174,liteGrowthkitPromo:175,paymentFlowStarted:341,transactionFlowShowPaymentDialog:405,transactionFlowStarted:176,
transactionFlowSecondaryDeviceStarted:222,transactionFlowSecondaryDeviceSignedOutStarted:383,transactionFlowCancelled:177,transactionFlowPaymentCallBackReceived:387,transactionFlowPaymentSubmitted:460,transactionFlowPaymentSucceeded:329,transactionFlowSucceeded:178,transactionFlowFailed:179,transactionFlowPlayBillingConnectionStartEvent:428,transactionFlowSecondaryDeviceSuccess:458,transactionFlowErrorEvent:411,liteVideoQualityChanged:180,watchBreakEnablementSettingEvent:181,watchBreakFrequencySettingEvent:182,
videoEffectsCameraPerformanceMetrics:183,adNotify:184,startupTelemetry:185,playbackOfflineFallbackUsed:186,outOfMemory:187,ypcPauseFlowStarted:188,ypcPauseFlowCancelled:189,ypcPauseFlowSucceeded:190,ypcPauseFlowFailed:191,uploadFileSelected:192,ypcResumeFlowStarted:193,ypcResumeFlowCancelled:194,ypcResumeFlowSucceeded:195,ypcResumeFlowFailed:196,adsClientStateChange:197,ypcCancelFlowStarted:198,ypcCancelFlowCancelled:199,ypcCancelFlowSucceeded:200,ypcCancelFlowFailed:201,ypcCancelFlowGoToPaymentProcessor:402,
ypcDeactivateFlowStarted:320,ypcRedeemFlowStarted:203,ypcRedeemFlowCancelled:204,ypcRedeemFlowSucceeded:205,ypcRedeemFlowFailed:206,ypcFamilyCreateFlowStarted:258,ypcFamilyCreateFlowCancelled:259,ypcFamilyCreateFlowSucceeded:260,ypcFamilyCreateFlowFailed:261,ypcFamilyManageFlowStarted:262,ypcFamilyManageFlowCancelled:263,ypcFamilyManageFlowSucceeded:264,ypcFamilyManageFlowFailed:265,restoreContextEvent:207,embedsAdEvent:327,autoplayTriggered:209,clientDataErrorEvent:210,experimentalVssValidation:211,
tvhtml5TriggeredEvent:212,tvhtml5FrameworksFieldTrialResult:216,tvhtml5FrameworksFieldTrialStart:220,musicOfflinePreferences:218,watchTimeSegment:219,appWidthLayoutError:221,accountRegistryChange:226,userMentionAutoCompleteBoxEvent:227,downloadRecommendationEnablementSettingEvent:228,musicPlaybackContentModeChangeEvent:231,offlineDbOpenCompleted:232,kidsFlowEvent:233,kidsFlowCorpusSelectedEvent:234,videoEffectsEvent:235,unpluggedOpsEogAnalyticsEvent:236,playbackAudioRouteEvent:237,interactionLoggingDebugModeError:238,
offlineYtbRefreshed:239,kidsFlowError:240,musicAutoplayOnLaunchAttempted:242,deviceContextActivityEvent:243,deviceContextEvent:244,templateResolutionException:245,musicSideloadedPlaylistServiceCalled:246,embedsStorageAccessNotChecked:247,embedsHasStorageAccessResult:248,embedsItpPlayedOnReload:249,embedsRequestStorageAccessResult:250,embedsShouldRequestStorageAccessResult:251,embedsRequestStorageAccessState:256,embedsRequestStorageAccessFailedState:257,embedsItpWatchLaterResult:266,searchSuggestDecodingPayloadFailure:252,
siriShortcutActivated:253,tvhtml5KeyboardPerformance:254,latencyActionSpan:255,elementsLog:267,ytbFileOpened:268,tfliteModelError:269,apiTest:270,yongleUsbSetup:271,touStrikeInterstitialEvent:272,liteStreamToSave:274,appBundleClientEvent:275,ytbFileCreationFailed:276,adNotifyFailure:278,ytbTransferFailed:280,blockingRequestFailed:281,liteAccountSelector:282,liteAccountUiCallbacks:283,dummyPayload:284,browseResponseValidationEvent:285,entitiesError:286,musicIosBackgroundFetch:287,mdxNotificationEvent:289,
layersValidationError:290,musicPwaInstalled:291,liteAccountCleanup:292,html5PlayerHealthEvent:293,watchRestoreAttempt:294,liteAccountSignIn:296,notaireEvent:298,kidsVoiceSearchEvent:299,adNotifyFilled:300,delayedEventDropped:301,analyticsSearchEvent:302,systemDarkThemeOptOutEvent:303,flowEvent:304,networkConnectivityBaselineEvent:305,ytbFileImported:306,downloadStreamUrlExpired:307,directSignInEvent:308,lyricImpressionEvent:309,accessibilityStateEvent:310,tokenRefreshEvent:311,genericAttestationExecution:312,
tvhtml5VideoSeek:313,unpluggedAutoPause:314,scrubbingEvent:315,bedtimeReminderEvent:317,tvhtml5UnexpectedRestart:319,tvhtml5DeviceStorageStats:535,tvhtml5StabilityTraceEvent:478,tvhtml5OperationHealth:467,tvhtml5WatchKeyEvent:321,voiceLanguageChanged:322,tvhtml5LiveChatStatus:323,parentToolsCorpusSelectedEvent:324,offerAdsEnrollmentInitiated:325,networkQualityIntervalEvent:326,deviceStartupMetrics:328,heartbeatActionPlayerTransitioned:330,tvhtml5Lifecycle:331,heartbeatActionPlayerHalted:332,adaptiveInlineMutedSettingEvent:333,
mainAppLibraryLoadingState:334,thirdPartyLogMonitoringEvent:336,appShellAssetLoadReport:337,tvhtml5AndroidAttestation:338,tvhtml5StartupSoundEvent:340,iosBackgroundRefreshTask:342,iosBackgroundProcessingTask:343,sliEventBatch:344,postImpressionEvent:346,musicSideloadedPlaylistExport:347,idbUnexpectedlyClosed:348,voiceSearchEvent:349,mdxSessionCastEvent:350,idbQuotaExceeded:351,idbTransactionEnded:352,idbTransactionAborted:353,tvhtml5KeyboardLogging:354,idbIsSupportedCompleted:355,creatorStudioMobileEvent:356,
idbDataCorrupted:357,parentToolsAppChosenEvent:358,webViewBottomSheetResized:359,activeStateControllerScrollPerformanceSummary:360,navigatorValidation:361,mdxSessionHeartbeat:362,clientHintsPolyfillDiagnostics:363,clientHintsPolyfillEvent:364,proofOfOriginTokenError:365,kidsAddedAccountSummary:366,musicWearableDevice:367,ypcRefundFlowEvent:368,tvhtml5PlaybackMeasurementEvent:369,tvhtml5WatermarkMeasurementEvent:370,clientExpGcfPropagationEvent:371,mainAppReferrerIntent:372,leaderLockEnded:373,leaderLockAcquired:374,
googleHatsEvent:375,persistentLensLaunchEvent:376,parentToolsChildWelcomeChosenEvent:378,browseThumbnailPreloadEvent:379,finalPayload:380,mdxDialAdditionalDataUpdateEvent:381,webOrchestrationTaskLifecycleRecord:382,startupSignalEvent:384,accountError:385,gmsDeviceCheckEvent:386,accountSelectorEvent:388,accountUiCallbacks:389,mdxDialAdditionalDataProbeEvent:390,downloadsSearchIcingApiStats:391,downloadsSearchIndexUpdatedEvent:397,downloadsSearchIndexSnapshot:398,dataPushClientEvent:392,kidsCategorySelectedEvent:393,
mdxDeviceManagementSnapshotEvent:394,prefetchRequested:395,prefetchableCommandExecuted:396,gelDebuggingEvent:399,webLinkTtsPlayEnd:400,clipViewInvalid:401,persistentStorageStateChecked:403,cacheWipeoutEvent:404,playerEvent:410,sfvEffectPipelineStartedEvent:412,sfvEffectPipelinePausedEvent:429,sfvEffectPipelineEndedEvent:413,sfvEffectChosenEvent:414,sfvEffectLoadedEvent:415,sfvEffectUserInteractionEvent:465,sfvEffectFirstFrameProcessedLatencyEvent:416,sfvEffectAggregatedFramesProcessedLatencyEvent:417,
sfvEffectAggregatedFramesDroppedEvent:418,sfvEffectPipelineErrorEvent:430,sfvEffectGraphFrozenEvent:419,sfvEffectGlThreadBlockedEvent:420,mdeQosEvent:510,mdeVideoChangedEvent:442,mdePlayerPerformanceMetrics:472,mdeExporterEvent:497,genericClientExperimentEvent:423,homePreloadTaskScheduled:424,homePreloadTaskExecuted:425,homePreloadCacheHit:426,polymerPropertyChangedInObserver:427,applicationStarted:431,networkCronetRttBatch:432,networkCronetRttSummary:433,repeatChapterLoopEvent:436,seekCancellationEvent:462,
lockModeTimeoutEvent:483,externalVideoShareToYoutubeAttempt:501,parentCodeEvent:502,offlineTransferStarted:4,musicOfflineMixtapePreferencesChanged:16,mangoDailyNewVideosNotificationAttempt:40,mangoDailyNewVideosNotificationError:77,dtwsPlaybackStarted:112,dtwsTileFetchStarted:113,dtwsTileFetchCompleted:114,dtwsTileFetchStatusChanged:145,dtwsKeyframeDecoderBufferSent:115,dtwsTileUnderflowedOnNonkeyframe:116,dtwsBackfillFetchStatusChanged:143,dtwsBackfillUnderflowed:117,dtwsAdaptiveLevelChanged:128,
blockingVisitorIdTimeout:277,liteSocial:18,mobileJsInvocation:297,biscottiBasedDetection:439,coWatchStateChange:440,embedsVideoDataDidChange:441,shortsFirst:443,cruiseControlEvent:445,qoeClientLoggingContext:446,atvRecommendationJobExecuted:447,tvhtml5UserFeedback:448,producerProjectCreated:449,producerProjectOpened:450,producerProjectDeleted:451,producerProjectElementAdded:453,producerProjectElementRemoved:454,producerAppStateChange:509,producerProjectDiskInsufficientExportFailure:516,producerMediaServicesResetDetails:522,
tvhtml5ShowClockEvent:455,deviceCapabilityCheckMetrics:456,youtubeClearcutEvent:461,offlineBrowseFallbackEvent:463,getCtvTokenEvent:464,startupDroppedFramesSummary:466,screenshotEvent:468,miniAppPlayEvent:469,elementsDebugCounters:470,fontLoadEvent:471,webKillswitchReceived:473,webKillswitchExecuted:474,cameraOpenEvent:475,manualSmoothnessMeasurement:476,tvhtml5AppQualityEvent:477,polymerPropertyAccessEvent:479,miniAppSdkUsage:480,cobaltTelemetryEvent:481,crossDevicePlayback:482,channelCreatedWithObakeImage:484,
channelEditedWithObakeImage:485,offlineDeleteEvent:486,crossDeviceNotificationTransfer:487,androidIntentEvent:488,unpluggedAmbientInterludesCounterfactualEvent:489,keyPlaysPlayback:490,shortsCreationFallbackEvent:493,vssData:491,castMatch:494,miniAppPerformanceMetrics:495,userFeedbackEvent:496,kidsGuestSessionMismatch:498,musicSideloadedPlaylistMigrationEvent:499,sleepTimerSessionFinishEvent:500,watchEpPromoConflict:503,innertubeResponseCacheMetrics:505,miniAppAdEvent:506,dataPlanUpsellEvent:507,
producerProjectRenamed:508,producerMediaSelectionEvent:511,embedsAutoplayStatusChanged:512,remoteConnectEvent:513,connectedSessionMisattributionEvent:514,producerProjectElementModified:515,adsSeenClientLogging:517,producerEvent:518,tvhtml5CleanStart:519,deviceAccountMetricsEvent:520,derpLogEvent:521,playablesPortalEvent:523,ipValidationStarted:524,ipValidationReceived:525,reelsSequenceMutationEvent:527,watchZoomStateChange:528,metadataEditorEvent:529,kidsPrismaDeeplinksEvent:530,creationOrchestrationEvent:531,
coordinatedSamplingTriggered:532,recapScreenshotEvent:534,mdxLocalNetworkPermissionRequestEvent:536,mdxLocalNetworkPermissionResponseEvent:537,sessionReplayEvent:538,sessionReplayStatusEvent:539,loggingReliabilityProbe:540,keyValueStoreStatsEvent:541,deviceLocationPermissionEvent:542,remoteControlStarted:543,remoteControlCompleted:544,reelsAdsEvents:545,ytlrLoaderTestHarnessEvent:547,biometricAuthenticationEvent:548,mainAppLifecycleEvent:549,musicDownloadBackgroundContinuedProcessingTask:550,musicMetadataMismatchEvent:551,
scrollToComponentCompleted:552,entityStoreTelemetry:553,streamingDarkLaunchEvent:554,childAccountsDisplayEvent:555,tvfasPlaybackContext:557,mdeC2PaEvent:559,mdeBatchedPlayerEvents:560,tvhtml5UlpCreationFlowData:561,alwaysConnectedHandshakeRemoteControlStarted:562,alwaysConnectedHandshakeRemoteControlCompleted:563,alwaysConnectedHandshakeAwarenessStarted:564,alwaysConnectedHandshakeAwarenessCompleted:565};
  lDa = function(f){f=Object.keys(f);for(let k of f)if(KrD[k])return k};
  var dHY = class extends g.I0{constructor(){super();this.K=[];this.B=[];var f=g.qd("yt.gcf.config.hotUpdateCallbacks");f?(this.K=[...f],this.B=f):(this.B=[],g.eF("yt.gcf.config.hotUpdateCallbacks",this.B))}GB(){for(let k of this.K){var f=this.B;let G=f.indexOf(k);G>=0&&f.splice(G,1)}this.K.length=0;super.GB()}};
  VA = function(f,k){f.K=k;g.eF("yt.gcf.config.hotConfigGroup",f.K||null)};
  vJ = function(f,k){f.B=k;g.eF("yt.gcf.config.coldConfigGroup",f.B||null)};
  BJ = function(){return g.qd("yt.gcf.config.coldConfigGroup")};
  jw = function(){return g.qd("yt.gcf.config.hotConfigGroup")};
  WT = function(f){this.B=f};
  vT = function(f){this.B=f;this.K=null};
  g.n = vT.prototype;
  g.n.isAvailable = function(){if(this.K===null){var f=this.B;if(f)try{f.setItem("__sak","1");f.removeItem("__sak");var k=!0}catch(G){k=G instanceof DOMException&&(G.name==="QuotaExceededError"||G.code===22||G.code===1014||G.name==="NS_ERROR_DOM_QUOTA_REACHED")&&f&&f.length!==0}else k=!1;this.K=k}return this.K};
  BT = function(f){if(f.B==null)throw Error("Storage mechanism: Storage unavailable");f.isAvailable()||mC(Error("Storage mechanism: Storage unavailable"))};
  g.n.set = function(f,k){BT(this);try{this.B.setItem(f,k)}catch(G){if(this.B.length==0)throw"Storage mechanism: Storage disabled";throw"Storage mechanism: Quota exceeded";}};
  g.n.get = function(f){BT(this);f=this.B.getItem(f);if(typeof f!=="string"&&f!==null)throw"Storage mechanism: Invalid value was encountered";return f};
  g.n.remove = function(f){BT(this);this.B.removeItem(f)};
  g.Ln = function(){};
  g.qz = {};
  g.sg = function(f){return{value:f,done:!1}};
  g.n.Ht = function(f){BT(this);var k=0,G=this.B,t=new g.Ln;t.next=function(){if(k>=G.length)return g.qz;var Z=G.key(k++);if(f)return g.sg(Z);Z=G.getItem(Z);if(typeof Z!=="string")throw"Storage mechanism: Invalid value was encountered";return g.sg(Z)};
return t};
  g.n.clear = function(){BT(this);this.B.clear()};
  g.n.key = function(f){BT(this);return this.B.key(f)};
  jz = function(){var f=null;try{f=g.Nd.localStorage||null}catch(k){}vT.call(this,f)};
  N5 = function(f,k){this.K=f;this.B=k+"::"};
  g.Uv = function(f){var k=new jz;return k.isAvailable()?f?new N5(k,f):k:null};
  gkX = function(){};
  g.M7 = function(f){return(new gkX).Bk(f)};
  Hb = function(f){this.B=f||{cookie:""}};
  g.n = Hb.prototype;
  g.n.isEnabled = function(){if(!g.Nd.navigator.cookieEnabled)return!1;if(!this.isEmpty())return!0;this.set("TESTCOOKIESENABLED","1",{RM:60});if(this.get("TESTCOOKIESENABLED")!=="1")return!1;this.remove("TESTCOOKIESENABLED");return!0};
  g.n.set = function(f,k,G){var t=!1;if(typeof G==="object"){var Z=G.sameSite;t=G.secure||!1;var u=G.domain||void 0;var h=G.path||void 0;var W=G.RM}if(/[;=\s]/.test(f))throw Error('Invalid cookie name "'+f+'"');if(/[;\r\n]/.test(k))throw Error('Invalid cookie value "'+k+'"');W===void 0&&(W=-1);G=u?";domain="+u:"";h=h?";path="+h:"";t=t?";secure":"";W=W<0?"":W==0?";expires="+(new Date(1970,1,1)).toUTCString():";expires="+(new Date(Date.now()+W*1E3)).toUTCString();this.B.cookie=f+"="+k+G+h+W+t+(Z!=null?
";samesite="+Z:"")};
  g.n.get = function(f,k){var G=f+"=",t=(this.B.cookie||"").split(";");for(let Z=0,u;Z<t.length;Z++){u=t[Z].trim();if(u.lastIndexOf(G,0)==0)return u.slice(G.length);if(u==f)return""}return k};
  g.n.remove = function(f,k,G){var t=this.get(f)!==void 0;this.set(f,"",{RM:0,path:k,domain:G});return t};
  xJ = function(f){f=(f.B.cookie||"").split(";");var k=[],G=[];for(let u=0;u<f.length;u++){var t=f[u].trim();var Z=t.indexOf("=");Z==-1?(k.push(""),G.push(t)):(k.push(t.substring(0,Z)),G.push(t.substring(Z+1)))}return{keys:k,values:G}};
  g.n.dE = function(){return xJ(this).keys};
  g.n.t_ = function(){return xJ(this).values};
  g.n.isEmpty = function(){return!this.B.cookie};
  g.n.clear = function(){var f=xJ(this).keys;for(let k=f.length-1;k>=0;k--)this.remove(f[k])};
  var Yi = {};
  var gv = !1;
  g.JH = function(f,k,G,t="youtube.com",Z=!1){gv||Yi.set(""+f,k,{RM:G,path:"/",domain:t,secure:Z})};
  g.f0 = function(f,k){if(!gv)return Yi.get(""+f,k)};
  g.kK = function(f,k="/",G="youtube.com"){gv||Yi.remove(""+f,k,G)};
  var w_ = class{constructor(f){this.B=(f=g.Uv(f))?new WT(f):null;this.domain=document.domain||window.location.hostname}K(){return!!this.B}set(f,k,G,t){G=G||31104E3;this.remove(f);if(this.B)try{this.B.set(f,k,Date.now()+G*1E3);return}catch(u){}var Z="";if(t)try{Z=escape(g.M7(k))}catch(u){return}else Z=escape(String(k));g.JH(f,Z,G,this.domain)}get(f,k){var G=void 0,t=!this.K();if(!t&&this.B)try{G=this.B.get(f)}catch(Z){t=!0}if(t&&(G=g.f0(f)))if(t=unescape(G),k)try{G=JSON.parse(t)}catch(Z){this.remove(f),
G=void 0}else G=t;return G}remove(f){this.B&&this.B.remove(f);g.kK(f,"/",this.domain)}getCreationTime(f){return this.B&&(f=(this.B.K(f)||{}).creation,typeof f==="number")?f:null}};
  var IB = undefined;
  Fy = function(){return IB()?.get("LAST_RESULT_ENTRY_KEY",!0)};
  zVA = {AUTH_INVALID:"No user identifier specified.",EXPLICIT_ABORT:"Transaction was explicitly aborted.",IDB_NOT_SUPPORTED:"IndexedDB is not supported.",MISSING_INDEX:"Index not created.",MISSING_OBJECT_STORES:"Object stores not created.",DB_DELETED_BY_MISSING_OBJECT_STORES:"Database is deleted because expected object stores were not created.",DB_REOPENED_BY_MISSING_OBJECT_STORES:"Database is reopened because expected object stores were not created.",UNKNOWN_ABORT:"Transaction was aborted for unknown reasons.",QUOTA_EXCEEDED:"The current transaction exceeded its quota limitations.",
QUOTA_MAYBE_EXCEEDED:"The current transaction may have failed because of exceeding quota limitations.",EXECUTE_TRANSACTION_ON_CLOSED_DB:"Can't start a transaction on a closed database",INCOMPATIBLE_DB_VERSION:"The binary is incompatible with the database version"};
  CQp = {AUTH_INVALID:"ERROR",EXECUTE_TRANSACTION_ON_CLOSED_DB:"WARNING",EXPLICIT_ABORT:"IGNORED",IDB_NOT_SUPPORTED:"ERROR",MISSING_INDEX:"WARNING",MISSING_OBJECT_STORES:"ERROR",DB_DELETED_BY_MISSING_OBJECT_STORES:"WARNING",DB_REOPENED_BY_MISSING_OBJECT_STORES:"WARNING",QUOTA_EXCEEDED:"WARNING",QUOTA_MAYBE_EXCEEDED:"WARNING",UNKNOWN_ABORT:"WARNING",INCOMPATIBLE_DB_VERSION:"WARNING"};
  EDY = {};
  g.mZ = class extends g.U3{constructor(f,k={},G=zVA[f],t=CQp[f],Z=EDY[f]){super(G,{name:"YtIdbKnownError",isSw:self.document===void 0,isIframe:self!==self.top,type:f,...k});this.type=f;this.message=G;this.level=t;this.B=Z;Object.setPrototypeOf(this,g.mZ.prototype)}};
  g.s3 = function(f,k,G){var t=Fy();return new g.mZ("IDB_NOT_SUPPORTED",{context:{caller:f,publicName:k,version:G,hasSucceededOnce:t?.hasSucceededOnce}})};
  WY = function(...f){f=arguments;var k=oE;f.length>1?k[f[0]]=f[1]:f.length===1&&Object.assign(k,f[0])};
  NZ = function(f,k,G,t,Z){var u=g.qd("yt.logging.errors.log");u?u(f,"WARNING",k,G,t,void 0,Z):(u=g.DR("ERRORS",[]),u.push([f,"WARNING",k,G,t,void 0,Z]),WY("ERRORS",u))};
  uc = function(){return g.qd("ytglobal.idbToken_")||void 0};
  td6 = function(f,k,G){var t=()=>{try{f.removeEventListener("success",Z),f.removeEventListener("error",u)}catch{}},Z=()=>{k(f.result);
t()},u=()=>{G(f.error);
t()};
f.addEventListener("success",Z);f.addEventListener("error",u)};
  aB = class{constructor(f){this.B=f}};
  fLX = function(f){return f};
  JID = function(f){if(!f)throw Error();throw f;};
  w0 = function(f,k,G,t,Z){k===G?Z(new TypeError("Circular promise chain detected.")):G.then(u=>{u instanceof g.b5?w0(f,k,u,t,Z):t(u)},u=>{Z(u)})};
  G5L = function(f,k,G,t,Z){try{if(f.state.status!=="REJECTED")throw Error("calling handleReject before the promise is rejected.");let u=G(f.state.reason);u instanceof g.b5?w0(f,k,u,t,Z):t(u)}catch(u){Z(u)}};
  k5H = function(f,k,G,t,Z){try{if(f.state.status!=="FULFILLED")throw Error("calling handleResolve before the promise is fulfilled.");let u=G(f.state.value);u instanceof g.b5?w0(f,k,u,t,Z):t(u)}catch(u){Z(u)}};
  g.b5 = class{constructor(f){this.state={status:"PENDING"};this.B=[];this.K=[];f=f.B;var k=t=>{if(this.state.status==="PENDING"){this.state={status:"FULFILLED",value:t};for(let Z of this.B)Z()}},G=t=>{if(this.state.status==="PENDING"){this.state={status:"REJECTED",
reason:t};for(let Z of this.K)Z()}};
try{f(k,G)}catch(t){G(t)}}static all(f){return new g.b5(new aB((k,G)=>{var t=[],Z=f.length;Z===0&&k(t);for(let u=0;u<f.length;++u)g.b5.resolve(f[u]).then(h=>{t[u]=h;Z--;Z===0&&k(t)}).catch(h=>{G(h)})}))}static resolve(f){return new g.b5(new aB((k,G)=>{f instanceof g.b5?f.then(k,G):k(f)}))}static reject(f){return new g.b5(new aB((k,G)=>{G(f)}))}then(f,k){var G=f??fLX,t=k??JID;
return new g.b5(new aB((Z,u)=>{this.state.status==="PENDING"?(this.B.push(()=>{k5H(this,this,G,Z,u)}),this.K.push(()=>{G5L(this,this,t,Z,u)})):this.state.status==="FULFILLED"?k5H(this,this,G,Z,u):this.state.status==="REJECTED"&&G5L(this,this,t,Z,u)}))}catch(f){return this.then(void 0,f)}};
  r0 = function(f){return new g.b5(new aB((k,G)=>{td6(f,k,G)}))};
  var OnE = class{constructor(f,k){this.request=f;
this.cursor=k}delete(){return r0(this.cursor.delete()).then(()=>{})}getValue(){return this.cursor.value}update(f){return r0(this.cursor.update(f))}};
  SU = function(f){return r0(f).then(k=>k?new OnE(f,k):null)};
  g.cq = function(f){f.cursor.continue(void 0);return SU(f.request)};
  MC = function(f,k){return new g.b5(new aB((G,t)=>{var Z=()=>{var u=f?k(f):null;u?u.then(h=>{f=h;Z()},t):G()};
Z()}))};
  g.RB = function(f,k,G){f=f.B.openCursor(k.query,k.direction);return SU(f).then(t=>MC(t,G))};
  j0a = function(f,k){return g.RB(f,{query:k},G=>G.delete().then(()=>g.cq(G))).then(()=>{})};
  NTE = function(f,k,G){var t=[];return g.RB(f,{query:k},Z=>{if(!(G!==void 0&&t.length>=G))return t.push(Z.getValue()),g.cq(Z)}).then(()=>t)};
  La = class extends Error{constructor(f,k){super();this.index=f;this.objectStore=k;Object.setPrototypeOf(this,La.prototype)}};
  g.pa = function(f,k,G){var {query:t=null,direction:Z="next"}=k;f=f.B.openCursor(t,Z);return SU(f).then(u=>MC(u,G))};
  qgf = function(f,k,G){var t=[];return g.pa(f,{query:k},Z=>{if(!(G!==void 0&&t.length>=G))return t.push(Z.getValue()),g.cq(Z)}).then(()=>t)};
  var nDY = class{constructor(f){this.B=f}count(f){return r0(this.B.count(f))}delete(f){return g.pa(this,{query:f},k=>k.delete().then(()=>g.cq(k)))}get(f){return r0(this.B.get(f))}getAll(f,k){return"getAll"in IDBIndex.prototype?r0(this.B.getAll(f,k)):qgf(this,f,k)}keyPath(){return this.B.keyPath}unique(){return this.B.unique}};
  var vCu = class{constructor(f){this.B=f}add(f,k){return r0(this.B.add(f,k))}autoIncrement(){return this.B.autoIncrement}clear(){return r0(this.B.clear()).then(()=>{})}count(f){return r0(this.B.count(f))}delete(f){return f instanceof IDBKeyRange?j0a(this,f):r0(this.B.delete(f))}get(f){return r0(this.B.get(f))}getAll(f,k){return"getAll"in IDBObjectStore.prototype?r0(this.B.getAll(f,
k)):NTE(this,f,k)}index(f){try{return new nDY(this.B.index(f))}catch(k){if(k instanceof Error&&k.name==="NotFoundError")throw new La(f,this.B.name);
throw k;}}getName(){return this.B.name}keyPath(){return this.B.keyPath}put(f,k){return r0(this.B.put(f,k))}};
  Xy = function(f,k,G){f=f.B.createObjectStore(k,G);return new vCu(f)};
  TV = function(f,k,G){f.B.createIndex(k,G,{unique:!1})};
  Ca = function(f){if(f.indexOf(":")>=0)throw Error("Database name cannot contain ':'");};
  var tz = {};
  Zy = undefined;
  var AR = !1;
  g.D6 = function(){var f=g.Nd.navigator;return f&&(f=f.userAgent)?f:""};
  g.Z6 = function(f,k){return f.indexOf(k)!=-1};
  Uk = function(f){return g.Z6(g.D6(),f)};
  g.Gq = undefined;
  Uw = function(){var f=/WebKit\/([0-9]+)/.exec(g.D6());return!!(f&&parseInt(f[1],10)>=602)};
  N4 = function(){var f=/WebKit\/([0-9]+)/.exec(g.D6());return!!(f&&parseInt(f[1],10)>=600)};
  Qe = undefined;
  yg = function(){return Uk("iPhone")&&!Uk("iPod")&&!Uk("iPad")};
  Pf = {};
  g.kc = Pf||Qe;
  Hq = function(){return g.e3("idb_immediate_commit")};
  E3 = function(f){return f.substr(0,f.indexOf(":"))||f};
  qH = function(){return yg()||Uk("iPad")||Uk("iPod")};
  QD = function(){return Uk("Firefox")||Uk("FxiOS")};
  var jby = {};
  jr = undefined;
  var B1 = undefined;
  var v1 = undefined;
  NR = function(f){if(!v1&&!B1||!jr)return!1;for(let k=0;k<jr.brands.length;k++){let {brand:G}=jr.brands[k];if(G&&g.Z6(G,f))return!0}return!1};
  er = function(){return v1||B1?!!jr&&jr.brands.length>0:!1};
  P1 = function(){return er()?NR("Microsoft Edge"):Uk("Edg/")};
  yD = function(){return er()?!1:Uk("Opera")};
  IN = function(){return er()?NR("Chromium"):(Uk("Chrome")||Uk("CriOS"))&&!(er()?0:Uk("Edge"))||Uk("Silk")};
  Fu = function(){return Uk("Safari")&&!(IN()||(er()?0:Uk("Coast"))||yD()||(er()?0:Uk("Edge"))||P1()||(er()?NR("Opera"):Uk("OPR"))||QD()||Uk("Silk")||Uk("Android"))};
  g.na = {};
  Yby = ["The database connection is closing","Can't start a transaction on a closed database","A mutation operation was attempted on a database that did not allow mutations"];
  d0 = function(f,k,G,t){k=E3(k);var Z=f instanceof Error?f:Error(`Unexpected error: ${f}`);if(Z instanceof g.mZ)return Z;f={objectStoreNames:G,dbName:k,dbVersion:t};if(Z.name==="QuotaExceededError")return new g.mZ("QUOTA_EXCEEDED",f);if(g.na&&Z.name==="UnknownError")return new g.mZ("QUOTA_MAYBE_EXCEEDED",f);if(Z instanceof La)return new g.mZ("MISSING_INDEX",{...f,objectStore:Z.objectStore,index:Z.index});if(Z.name==="InvalidStateError"&&Yby.some(u=>Z.message.includes(u)))return new g.mZ("EXECUTE_TRANSACTION_ON_CLOSED_DB",
f);
if(Z.name==="AbortError")return new g.mZ("UNKNOWN_ABORT",f,Z.message);Z.args=[{...f,name:"IdbError",UR:Z.name}];Z.level="WARNING";return Z};
  var $9 = [];
  Ka = undefined;
  zV = function(f,k){AR||(Ka?Ka.logEvent(f,k):($9.push({type:"EVENT",eventType:f,payload:k}),$9.length>10&&$9.shift()))};
  BTE = function(f,k,G,t,Z,u="IDB_TRANSACTION_TAG_UNKNOWN"){zV("TRANSACTION_ENDED",{objectStoreNames:t,connectionHasUnknownAbortedTransaction:f.K,duration:Z,isSuccessful:k,tryCount:G,tag:u})};
  i5 = function(f){AR||(Ka?Ka.Hk(f):($9.push({type:"ERROR",payload:f}),$9.length>10&&$9.shift()))};
  VdE = function(f,k,G,t,Z,u,h){k=G-k;Z?(Z instanceof g.mZ&&(Z.type==="QUOTA_EXCEEDED"||Z.type==="QUOTA_MAYBE_EXCEEDED")&&zV("QUOTA_EXCEEDED",{dbName:E3(f.B.name),objectStoreNames:u,transactionCount:f.transactionCount,transactionMode:h.mode}),Z instanceof g.mZ&&Z.type==="UNKNOWN_ABORT"&&(G-=f.W,G<0&&G>=2147483648&&(G=0),zV("TRANSACTION_UNEXPECTEDLY_ABORTED",{objectStoreNames:u,transactionDuration:k,transactionCount:f.transactionCount,dbDuration:G}),f.K=!0),BTE(f,!1,t,u,k,h.tag),i5(Z)):BTE(f,!0,t,u,k,
h.tag)};
  var W1Q = class{constructor(f){this.B=f;this.K=new Map;this.aborted=!1;this.done=new Promise((k,G)=>{this.B.addEventListener("complete",()=>{k()});
this.B.addEventListener("error",t=>{t.currentTarget===t.target&&G(this.B.error)});
this.B.addEventListener("abort",()=>{var t=this.B.error;if(t)G(t);else if(!this.aborted){t=g.mZ;var Z=this.B.objectStoreNames;let u=[];for(let h=0;h<Z.length;h++){let W=Z.item(h);if(W===null)throw Error("Invariant: item in DOMStringList is null");u.push(W)}t=new t("UNKNOWN_ABORT",{objectStoreNames:u.join(),dbName:this.B.db.name,mode:this.B.mode});G(t)}})})}abort(){this.B.abort();
this.aborted=!0;throw new g.mZ("EXPLICIT_ABORT");}commit(){this.aborted||this.B.commit?.()}objectStore(f){f=this.B.objectStore(f);var k=this.K.get(f);k||(k=new vCu(f),this.K.set(f,k));return k}};
  DGu = function(f,k,G){var t=new Promise((Z,u)=>{try{let h=k(f);G&&f.commit();h.then(W=>{Z(W)}).catch(u)}catch(h){u(h),f.abort()}});
return Promise.all([t,f.done]).then(([Z])=>Z)};
  g.x9 = async function(f,k,G,t){var Z={mode:"readonly",C7:!1,tag:"IDB_TRANSACTION_TAG_UNKNOWN"};typeof G==="string"?Z.mode=G:Object.assign(Z,G);f.transactionCount++;G=Z.C7?3:1;for(var u=0,h;!h;){u++;let U=Math.round((0,g.S)());try{var W=f.B.transaction(k,Z.mode),D=t,V=!!Z.commit;let e=new W1Q(W),q=await DGu(e,D,V),O=Math.round((0,g.S)());VdE(f,U,O,u,void 0,k.join(),Z);return q}catch(e){D=Math.round((0,g.S)());let q=d0(e,f.B.name,k.join(),f.B.version);if(q instanceof g.mZ&&!q.B||u>=G)VdE(f,U,D,u,q,k.join(),
Z),h=q}}return Promise.reject(h)};
  var P9F = class{constructor(f,k){this.B=f;this.options=k;this.transactionCount=0;this.W=Math.round((0,g.S)());this.K=!1}add(f,k,G){return g.x9(this,[f],{mode:"readwrite",C7:!0,commit:Hq()},t=>t.objectStore(f).add(k,G))}clear(f){return g.x9(this,[f],{mode:"readwrite",
C7:!0},k=>k.objectStore(f).clear())}close(){this.B.close();
this.options?.closed&&this.options.closed()}count(f,k){return g.x9(this,[f],{mode:"readonly",C7:!0,commit:Hq()},G=>G.objectStore(f).count(k))}delete(f,k){return g.x9(this,[f],{mode:"readwrite",
C7:!0,commit:Hq()&&!(k instanceof IDBKeyRange)},G=>G.objectStore(f).delete(k))}get(f,k){return g.x9(this,[f],{mode:"readonly",
C7:!0,commit:Hq()},G=>G.objectStore(f).get(k))}getAll(f,k,G){return g.x9(this,[f],{mode:"readonly",
C7:!0},t=>t.objectStore(f).getAll(k,G))}put(f,k,G){return g.x9(this,[f],{mode:"readwrite",
C7:!0,commit:Hq()},t=>t.objectStore(f).put(k,G))}objectStoreNames(){return Array.from(this.B.objectStoreNames)}getName(){return this.B.name}};
  Q0u = function(f,k,G){return new Promise((t,Z)=>{var u=k!==void 0?self.indexedDB.open(f,k):self.indexedDB.open(f);var h=G.blocked,W=G.blocking,D=G.Ae,V=G.upgrade,U=G.closed,e,q=()=>{e||(e=new P9F(u.result,{closed:U}));return e};
u.addEventListener("upgradeneeded",O=>{try{if(O.newVersion===null)throw Error("Invariant: newVersion on IDbVersionChangeEvent is null");if(u.transaction===null)throw Error("Invariant: transaction on IDbOpenDbRequest is null");O.dataLoss&&O.dataLoss!=="none"&&zV("IDB_DATA_CORRUPTED",{reason:O.dataLossMessage||"unknown reason",dbName:E3(f)});let F=q(),m=new W1Q(u.transaction);V&&V(F,a=>O.oldVersion<a&&O.newVersion>=a,m);
m.done.catch(a=>{Z(a)})}catch(F){Z(F)}});
u.addEventListener("success",()=>{var O=u.result;W&&O.addEventListener("versionchange",()=>{W(q())});
O.addEventListener("close",()=>{zV("IDB_UNEXPECTEDLY_CLOSED",{dbName:E3(f),dbVersion:O.version});D&&D()});
t(q())});
u.addEventListener("error",()=>{Z(u.error)});
h&&u.addEventListener("blocked",()=>{h()})})};
  ILd = function(f,k,G={}){return Q0u(f,k,G)};
  Znd = function(f){return new Promise((k,G)=>{td6(f,k,G)})};
  g0 = async function(f,k={}){try{let G=self.indexedDB.deleteDatabase(f),t=k.blocked;t&&G.addEventListener("blocked",()=>{t()});
await Znd(G)}catch(G){throw d0(G,f,"",-1);}};
  F1f = function(f,k){return new g.mZ("INCOMPATIBLE_DB_VERSION",{dbName:f.name,oldVersion:f.options.version,newVersion:k})};
  yZ = function(f,k){return Number(UH(f,k)||0)};
  mHI = class extends g.mZ{constructor(f,k){super("MISSING_OBJECT_STORES",{expectedObjectStores:k,foundObjectStores:f},zVA.MISSING_OBJECT_STORES);Object.setPrototypeOf(this,mHI.prototype)}};
  var LTK = class{constructor(f,k){this.name=f;this.options=k;this.W=!0;this.Z=this.S=0}K(f,k,G={}){return ILd(f,k,G)}delete(f={}){return g0(this.name,f)}open(){if(!this.W)throw F1f(this);if(this.B)return this.B;var f,k=()=>{this.B===f&&(this.B=void 0)},G={blocking:Z=>{Z.close()},
closed:k,Ae:k,upgrade:this.options.upgrade},t=async()=>{var Z=Error().stack??"";try{let W=await this.K(this.name,this.options.version,G);var u=W,h=this.options;let D=[];for(let V of Object.keys(h.b4)){let {Xm:U,U5z:e=Number.MAX_VALUE}=h.b4[V];!(u.B.version>=U)||u.B.version>=e||u.B.objectStoreNames.contains(V)||D.push(V)}if(D.length!==0){let V=Object.keys(this.options.b4),U=W.objectStoreNames();if(this.Z<yZ("ytidb_reopen_db_retries",0))return this.Z++,W.close(),i5(new g.mZ("DB_REOPENED_BY_MISSING_OBJECT_STORES",
{dbName:this.name,expectedObjectStores:V,foundObjectStores:U})),t();if(this.S<yZ("ytidb_remake_db_retries",1))return this.S++,await this.delete(),i5(new g.mZ("DB_DELETED_BY_MISSING_OBJECT_STORES",{dbName:this.name,expectedObjectStores:V,foundObjectStores:U})),t();throw new mHI(U,V);}return W}catch(W){if(W instanceof DOMException?W.name==="VersionError":"DOMError"in self&&W instanceof DOMError?W.name==="VersionError":W instanceof Object&&"message"in W&&W.message==="An attempt was made to open a database using a lower version than the existing version."){Z=
await this.K(this.name,void 0,{...G,upgrade:void 0});u=Z.B.version;if(this.options.version!==void 0&&u>this.options.version+1)throw Z.close(),this.W=!1,F1f(this,u);return Z}k();W instanceof Error&&!g.e3("ytidb_async_stack_killswitch")&&(W.stack=`${W.stack}\n${Z.substring(Z.indexOf("\n")+1)}`);throw d0(W,this.name,"",this.options.version??-1);}};
return this.B=f=t()}};
  var JR = {};
  g.Y9 = function(f,k){if(!k)throw g.s3("openWithToken",E3(f.name));return f.open()};
  AwF = async function(f,k){return g.x9(await g.Y9(JR,k),["databases"],{C7:!0,mode:"readwrite"},G=>{var t=G.objectStore("databases");return t.get(f.actualName).then(Z=>{if(Z?f.actualName!==Z.actualName||f.publicName!==Z.publicName||f.userIdentifier!==Z.userIdentifier:1)return t.put(f).then(()=>{})})})};
  fd = async function(f,k){return f?(await g.Y9(JR,k)).delete("databases",f):void 0};
  zjO = async function(){if(Fy()?.hasSucceededOnce)return!0;var f;if(!(f=g.kc&&N4()&&!Uw()||g.Gq)){try{f=self;var k=!!(f.indexedDB&&f.IDBIndex&&f.IDBKeyRange&&f.IDBObjectStore)}catch(G){k=!1}f=!k}if(f||!("IDBTransaction"in self&&"objectStoreNames"in IDBTransaction.prototype))return!1;try{return await AwF({actualName:"yt-idb-test-do-not-use",publicName:"yt-idb-test-do-not-use",userIdentifier:void 0},tz),await fd("yt-idb-test-do-not-use",tz),!0}catch(G){return!1}};
  C9a = function(){if(Zy!==void 0)return Zy;AR=!0;return Zy=zjO().then(f=>{AR=!1;if(IB()?.K()){var k={hasSucceededOnce:Fy()?.hasSucceededOnce||f};IB()?.set("LAST_RESULT_ENTRY_KEY",k,2592E3,!0)}return f})};
  g.hz = function(){var f=uc();return f?Promise.resolve(f):C9a().then(k=>{k?(g.eF("ytglobal.idbToken_",tz),k=tz):k=void 0;return k})};
  g.jU = function(f="unknown"){if(g.DR("DATASYNC_ID")!==void 0)return g.DR("DATASYNC_ID");throw new g.U3("Datasync ID not set",f);};
  NC = function(){try{return g.jU(),!0}catch(f){return!1}};
  ECa = function(f){if(!NC())throw f=new g.mZ("AUTH_INVALID",{dbName:f}),i5(f),f;var k=g.jU();return{actualName:`${f}:${k}`,publicName:f,userIdentifier:k}};
  mGH = async function(f,k,G,t){var Z=Error().stack??"",u=await g.hz();if(!u)throw k=g.s3("openDbImpl",f,k),g.e3("ytidb_async_stack_killswitch")||(k.stack=`${k.stack}\n${Z.substring(Z.indexOf("\n")+1)}`),i5(k),k;Ca(f);Z=G?{actualName:f,publicName:f,userIdentifier:void 0}:ECa(f);try{return await AwF(Z,u),await ILd(Z.actualName,k,t)}catch(h){try{await fd(Z.actualName,u)}catch{}throw h;}};
  nCf = function(f,k,G={}){return mGH(f,k,!1,G)};
  L1D = function(f,k,G={}){return mGH(f,k,!0,G)};
  dGE = async function(f,k={}){var G=await g.hz();G&&(Ca(f),f=ECa(f),await g0(f.actualName,k),await fd(f.actualName,G))};
  w0D = async function(f,k={}){var G=await g.hz();G&&(Ca(f),await g0(f,k),await fd(f,G))};
  var aLu = class extends LTK{constructor(f,k){super(f,k);this.options=k;Ca(f)}K(f,k,G={}){return(this.options.shared?L1D:nCf)(f,k,{...G})}delete(f={}){return(this.options.shared?w0D:dGE)(this.name,f)}};
  rwD = function(f,k){var G;return()=>{G||(G=new aLu(f,k));return G}};
  om = function(f,k){return rwD(f,k)};
  var Md6 = undefined;
  WJ = function(f){return g.Y9(Md6(),f)};
  lLL = async function(f){f=await WJ(f);var k=void 0;await g.x9(f,["hotConfigStore"],{mode:"readwrite",C7:!0},G=>g.pa(G.objectStore("hotConfigStore").index("hotTimestampIndex"),{direction:"prev"},t=>{k=t.getValue()}));
return k};
  Yg6 = function(f){VA(f,g.DR("RAW_HOT_CONFIG_GROUP"));f.W2(g.DR("SERIALIZED_HOT_HASH_DATA"))};
  Hnc = async function(f,k,G,t){f={config:f,hashData:k,timestamp:t!==void 0?t:(0,g.S)()};G=await WJ(G);await G.clear("hotConfigStore");return await G.put("hotConfigStore",f)};
  RjF = async function(f){if(f.K)return jw();if(!f.Z)return f=g.s3("getHotConfig IDB not initialized"),NZ(f),Promise.reject(f);var k=uc(),G=g.DR("TIME_CREATED_MS");if(k){var t=await lLL(k);if(t&&t.timestamp>G)return VA(f,t.config),f.W2(t.hashData),jw()}else t=g.s3("getHotConfig token error"),NZ(t);Yg6(f);k&&f.K&&f.hotHashData&&await Hnc(f.K,f.hotHashData,k,G);return f.K?jw():(f=new g.U3("Config not available in ytConfig"),NZ(f),Promise.reject(f))};
  X0E = async function(f){f=await WJ(f);var k=void 0;await g.x9(f,["coldConfigStore"],{mode:"readwrite",C7:!0},G=>g.pa(G.objectStore("coldConfigStore").index("coldTimestampIndex"),{direction:"prev"},t=>{k=t.getValue()}));
return k};
  frD = function(f,k){f.configData=k;g.eF("yt.gcf.config.coldConfigData",f.configData||null)};
  Nb = function(f,k){f.coldHashData=k;g.eF("yt.gcf.config.coldHashData",f.coldHashData||null)};
  gCQ = function(f){vJ(f,g.DR("RAW_COLD_CONFIG_GROUP"));Nb(f,g.DR("SERIALIZED_COLD_HASH_DATA"));frD(f,f.B?.configData)};
  xG6 = async function(f,k,G,t,Z){f={config:f,hashData:k,configData:G,timestamp:Z!==void 0?Z:(0,g.S)()};t=await WJ(t);await t.clear("coldConfigStore");return await t.put("coldConfigStore",f)};
  cwH = async function(f){if(f.B)return BJ();if(!f.Z)return f=g.s3("getColdConfig IDB not initialized"),NZ(f),Promise.reject(f);var k=uc(),G=g.DR("TIME_CREATED_MS");if(k){var t=await X0E(k);if(t&&t.timestamp>G)return vJ(f,t.config),frD(f,t.configData),Nb(f,t.hashData),BJ()}else t=g.s3("getColdConfig"),NZ(t);gCQ(f);k&&f.B&&f.coldHashData&&f.configData&&await xG6(f.B,f.coldHashData,f.configData,k,G);return f.B?BJ():(f=new g.U3("Config not available in ytConfig"),NZ(f),Promise.reject(f))};
  g.sH = function(f){window.clearTimeout(f)};
  var vY = [];
  FJf = function(f){vY.forEach(k=>k(f))};
  g.BY = function(f){var k=g.qd("yt.logging.errors.log");k?k(f,"ERROR",void 0,void 0,void 0,void 0,void 0):(k=g.DR("ERRORS",[]),k.push([f,"ERROR",void 0,void 0,void 0,void 0,void 0]),WY("ERRORS",k));FJf(f)};
  g.j3 = function(f){return f&&window.yterr?function(){try{return f.apply(this,arguments)}catch(k){g.BY(k)}}:f};
  g.Lt = function(f,k){typeof f==="function"&&(f=g.j3(f));return window.setTimeout(f,k)};
  eU = function(f,k,G,t){t!==void 0&&Number.isNaN(Number(t))&&(t=void 0);return(f=g.qd("yt.scheduler.instance.addJob"))?f(k,G,t):t===void 0?(k(),NaN):g.Lt(k,t||0)};
  var iYe = class{constructor(){this.B=new WeakMap}Sw(f,k){return eU(0,f,1,k)}uG(f){(f=this.B.get(f))&&f()}};
  qC = class extends iYe{Cl(f){if(f===void 0||!Number.isNaN(Number(f))){var k=g.qd("yt.scheduler.instance.cancelJob");k?k(f):g.sH(f)}}start(){var f=g.qd("yt.scheduler.instance.start");f&&f()}pause(){var f=g.qd("yt.scheduler.instance.pause");f&&f()}};
  g.O3 = function(){qC.instance||(qC.instance=new qC);return qC.instance};
  g.QL = undefined;
  p0D = function(f){if(!f.K||!f.B){if(!uc()){let k=g.s3("scheduleGetConfigs");NZ(k)}f.S||(f.S=g.QL.Sw(async()=>{try{await RjF(f)}catch{}try{await cwH(f)}catch{}f.S&&(f.S=0)},100))}};
  var Dy = class{constructor(){this.Z=!1;this.W=this.S=0;this.A=new dHY;this.OQ={JRo:()=>{this.Z=!0},
M0o:()=>this.B,
fB6:f=>{VA(this,f)},
W2:f=>{this.W2(f)},
NAj:f=>{vJ(this,f)},
MX:()=>this.coldHashData,
Yl:()=>this.hotHashData,
Jre:()=>this.K,
Prt:()=>BJ(),
voG:()=>jw(),
XkB:()=>g.qd("yt.gcf.config.coldHashData"),
jJz:()=>g.qd("yt.gcf.config.hotHashData"),
w1x:()=>{p0D(this)},
d5e:()=>{this.W2(void 0);Nb(this);delete Dy.instance},
i2L:f=>{this.W=f},
abx:()=>this.W}}v8(){return jw()??g.DR("RAW_HOT_CONFIG_GROUP")}W2(f){this.hotHashData=f;
g.eF("yt.gcf.config.hotHashData",this.hotHashData||null)}};
  var Vw = class{constructor(f){this.key=f}};
  vQ = function(f){return new Vw(f)};
  BQ = function(f,k){f.K.set(k.Zn,k);var G=f.W.get(k.Zn);if(G)try{G.ZC(f.resolve(k.Zn))}catch(t){G.HP(t)}};
  var jN = Symbol("injectionDeps");
  q8D = function(f,k,G){return k?k.map(t=>t instanceof Vw?NK(f,t.key,G,!0):NK(f,t,G)):[]};
  NK = function(f,k,G,t=!1){if(G.indexOf(k)>-1)throw Error(`Deps cycle for: ${k}`);if(f.B.has(k))return f.B.get(k);if(!f.K.has(k)){if(t)return;throw Error(`No provider for: ${k}`);}var Z=f.K.get(k);G.push(k);if(Z.v_!==void 0)t=Z.v_;else if(Z.PY)t=Z[jN]?q8D(f,Z[jN],G):[],t=Z.PY(...t);else if(Z.S0){t=Z.S0;let u=t[jN]?q8D(f,t[jN],G):[];t=new t(...u)}else{if(!t)throw Error(`Could not resolve providers for: ${k}`);t=void 0}G.pop();Z.IL||f.B.set(k,t);return t};
  var ObO = class{constructor(){this.K=new Map;this.W=new Map;this.B=new Map;this.OQ={t0x:()=>new Map(this.K),
x5H:f=>{var k=this.K.get(f.Zn),G=this.B.get(f.Zn);this.B.delete(f.Zn);BQ(this,f);return()=>{this.K.delete(f.Zn);this.B.delete(f.Zn);k&&BQ(this,k);G&&this.B.set(f.Zn,G)}}}}resolve(f){return f instanceof Vw?NK(this,f.key,[],!0):NK(this,f,[])}};
  U_ = undefined;
  eN = function(){U_||(U_=new ObO);return U_};
  T56 = function(f){if(g.e3("enable_web_tiered_gel")){f=KrD[f||""];var k=eN().resolve(vQ(Dy))?.v8()?.loggingHotConfig?.eventLoggingConfig?.payloadPolicies;if(k)for(let G=0;G<k.length;G++)if(k[G].payloadNumber===f)return k[G]}};
  S8d = function(f){switch(f){case "DELAYED_EVENT_TIER_UNSPECIFIED":return 0;case "DELAYED_EVENT_TIER_DEFAULT":return 100;case "DELAYED_EVENT_TIER_DISPATCH_TO_EMPTY":return 200;case "DELAYED_EVENT_TIER_FAST":return 300;case "DELAYED_EVENT_TIER_IMMEDIATE":return 400;default:return 200}};
  $X = function(f){return[f.auth===void 0?"undefined":f.auth,f.isJspb===void 0?"undefined":f.isJspb,f.cttAuthInfo===void 0?"undefined":f.cttAuthInfo,f.tier===void 0?"undefined":f.tier].join("/")};
  iE = function(f,k){return f===void 0||f==="undefined"?!0:f===k};
  zh = function(f,k){var G=$X(k);if(f.K[G])return f.K[G];var t=Object.keys(f.store)||[];if(t.length<=1&&$X(k)===t[0])return t;var Z=[];for(let h=0;h<t.length;h++){let W=t[h].split("/");if(iE(k.auth,W[0])){var u=k.isJspb;iE(u===void 0?"undefined":u?"true":"false",W[1])&&iE(k.cttAuthInfo,W[2])&&(u=k.tier,u=u===void 0?"undefined":JSON.stringify(u),iE(u,W[3])&&Z.push(t[h]))}}return f.K[G]=Z};
  var mQ = class{constructor(){this.store={};this.B=0;this.K={};this.OQ={wky:()=>this.B}}storePayload(f,k){f=$X(f);
this.store[f]?this.store[f].push(k):(this.K={},this.store[f]=[k]);this.B++;g.e3("more_accurate_gel_parser")&&(k=new CustomEvent("TRANSPORTING_NEW_EVENT"),window.dispatchEvent(k));return f}smartExtractMatchingEntries(f){if(!f.keys.length)return[];var k=zh(this,f.keys.splice(0,1)[0]),G=[];for(let t=0;t<k.length;t++)this.store[k[t]]&&f.sizeLimit&&(this.store[k[t]].length<=f.sizeLimit?(G.push(...this.store[k[t]]),delete this.store[k[t]]):G.push(...this.store[k[t]].splice(0,f.sizeLimit)));this.B-=G.length;
f?.sizeLimit&&G.length<f?.sizeLimit&&(f.sizeLimit-=G.length,G.push(...this.smartExtractMatchingEntries(f)));return G}extractMatchingEntries(f){f=zh(this,f);var k=[];for(let G=0;G<f.length;G++)this.store[f[G]]&&(k.push(...this.store[f[G]]),delete this.store[f[G]]);this.B-=k.length;return k}getSequenceCount(f){f=zh(this,f);var k=0;for(let G=0;G<f.length;G++)k+=this.store[f[G]]?.length||0;return k}};
  nH = function(){var f=g.qd("yt.logging.ims");f||(f=new mQ,g.eF("yt.logging.ims",f));return f};
  var rVf = null;
  aDF = function(){return g.e3("html5_send_qoe_on_gel")||g.e3("web_send_vss3_isolated_payload")};
  var CH = void 0;
  E_ = function(f){rVf=f;aDF()&&(g.Nd.ytLoggingTransportRegisteredClientCtor_=f);CH=new f};
  MD6 = function(f){return f?f:aDF()?rVf||g.Nd.ytLoggingTransportRegisteredClientCtor_||null:null};
  wI = function(f){return f==="gelDebuggingEvent"||f==="watchTimeSegment"};
  D2H = function(f=!1){return f&&g.e3("vss_through_gel_video_stats")?"video_stats":"log_event"};
  qZ = function(){return g.DR("EXPERIMENTS_TOKEN","")};
  OH = function(){var f=[],k=g.DR("EXPERIMENTS_FORCED_FLAGS",{});for(var G of Object.keys(k))f.push({key:G,value:String(k[G])});G=g.DR("EXPERIMENT_FLAGS",{});for(let t of Object.keys(G))t.startsWith("force_")&&k[t]===void 0&&f.push({key:t,value:String(G[t])});return f};
  ZF = function(){if(!g.Nd.matchMedia)return"WEB_DISPLAY_MODE_UNKNOWN";try{return g.Nd.matchMedia("(display-mode: standalone)").matches?"WEB_DISPLAY_MODE_STANDALONE":g.Nd.matchMedia("(display-mode: minimal-ui)").matches?"WEB_DISPLAY_MODE_MINIMAL_UI":g.Nd.matchMedia("(display-mode: fullscreen)").matches?"WEB_DISPLAY_MODE_FULLSCREEN":g.Nd.matchMedia("(display-mode: browser)").matches?"WEB_DISPLAY_MODE_BROWSER":"WEB_DISPLAY_MODE_UNKNOWN"}catch(f){return"WEB_DISPLAY_MODE_UNKNOWN"}};
  var yA = class extends xb{constructor(f){super(f)}};
  YG = function(f,k,G){if(f!=null&&f[p$]===gj)return f;if(Array.isArray(f)){var t=f[ZQ]|0;G=t|G&32|G&2;G!==t&&(f[ZQ]=G);return new k(f)}};
  zT = function(f,k){k===void 0&&(k=f[ZQ]|0);k&32&&!(k&4096)&&(f[ZQ]=k|4096)};
  tA = function(f,k,G,t,Z){var u=!1;t=CP(f,t,Z,h=>{var W=YG(h,G,k);u=W!==h&&W!=null;return W});
if(t!=null)return u&&!uy(t)&&zT(f,k),t};
  Ao = function(f){var k=f.q0,G=k[ZQ]|0;return uy(f,G)?Is(f,k,G)?Fa(f,k,!0):new f.constructor(QH(k,G,!1)):f};
  hA = function(f,k,G,t){var Z=f.q0,u=Z[ZQ]|0;k=tA(Z,u,k,G,t);if(k==null)return k;u=Z[ZQ]|0;if(!uy(f,u)){let h=Ao(k);h!==k&&(KP(f)&&(Z=f.q0,u=Z[ZQ]|0),k=h,u=mA(Z,u,G,k,t),zT(Z,u))}return k};
  var vJD = {m_t:"WEB_DISPLAY_MODE_UNKNOWN",YiG:"WEB_DISPLAY_MODE_BROWSER",F86:"WEB_DISPLAY_MODE_MINIMAL_UI",alb:"WEB_DISPLAY_MODE_STANDALONE",HqL:"WEB_DISPLAY_MODE_FULLSCREEN"};
  JC = function(f){f=Error(f);kD(f,"warning");return f};
  var zc = {};
  nP = function(f,k,G,t){ih(f);var Z=f.q0;mA(Z,Z[ZQ]|0,k,G,t);return f};
  Kx = function(f,k,G){if(G!=null){if(!zc(G))throw JC("enum");G|=0}return nP(f,k,G)};
  K$ = function(f){return f.displayName||f.name||"unknown type name"};
  cU = function(f,k){if(!(f instanceof k))throw Error(`Expected instanceof ${K$(k)} but got ${f&&K$(f.constructor)}`);return f};
  vR = function(f,k){f!=null?cU(f,k):f=void 0;return f};
  BR = function(f,k,G,t,Z){t=vR(t,k);nP(f,G,t,Z);t&&!uy(t)&&zT(f.q0);return f};
  u7E = function(f,k,G){f=f.La;if(f==="WEB"||f==="MWEB"||f===1||f===2)k?(G=hA(k,yA,96)||new yA,f=ZF(),f=Object.keys(vJD).indexOf(f),f=f===-1?null:f,f!==null&&Kx(G,3,f),BR(k,yA,96,G)):G&&(G.client.mainAppWebInfo=G.client.mainAppWebInfo??{},G.client.mainAppWebInfo.webDisplayMode=ZF())};
  L$ = function(f){if(f==null)return f;if(typeof f==="string"&&f)f=+f;else if(typeof f!=="number")return;return zc(f)?f>>>0:void 0};
  var Ki6 = [];
  dq = undefined;
  LP = function(f,k,G){f=CP(f,k,G);return Array.isArray(f)?f:dq};
  bh = function(f,k){2&k&&(f|=2);return f|1};
  wq = function(f,k){return f=(2&k?f|2:f&-3)&-273};
  Mj = function(f){return!!(2&f)&&!!(4&f)||!!(256&f)};
  as = function(f,k,G,t,Z,u,h,W,D){var V=k;h===1||(h!==4?0:2&k||!(16&k)&&32&t)?Mj(k)||(k|=!f.length||W&&!(4096&k)||32&t&&!(4096&k||16&k)?2:256,k!==V&&(f[ZQ]=k),Object.freeze(f)):(h===2&&Mj(k)&&(f=[...f],V=0,k=wq(k,t),t=mA(G,t,Z,f,u)),Mj(k)||(D||(k|=16),k!==V&&(f[ZQ]=k)));2&k||!(4096&k||16&k)||zT(G,t);return f};
  rq = function(f,k,G,t,Z){var u=f.q0,h=u[ZQ]|0;t=uy(f,h)?1:t;Z=!!Z||t===3;t===2&&KP(f)&&(u=f.q0,h=u[ZQ]|0);f=LP(u,k);var W=f===dq?7:f[ZQ]|0,D=bh(W,h);var V=4&D?!1:!0;if(V){4&D&&(f=[...f],W=0,D=wq(D,h),h=mA(u,h,k,f));let U=0,e=0;for(;U<f.length;U++){let q=G(f[U]);q!=null&&(f[e++]=q)}e<U&&(f.length=e);G=(D|4)&-513;D=G&=-1025;D&=-4097}D!==W&&(f[ZQ]=D,2&D&&Object.freeze(f));return f=as(f,D,u,h,k,void 0,t,V,Z)};
  o5 = function(f,k){if(typeof k!=="number"||k<0||k>=f.length)throw Error();};
  var qb = class extends xb{constructor(f){super(f)}vK(f){var k=rq(this,5,L$,3,!0);o5(k,f);return k[f]}};
  FZ = function(f,k,G){return nP(f,k,Sf(G))};
  hIa = function(f,k){var G=g.qd("yt.embedded_player.embed_url");G&&(f?(k=hA(f,qb,7)||new qb,FZ(k,4,G),BR(f,qb,7,k)):k&&(k.thirdParty={embedUrl:G}))};
  var yWX = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  C$ = function(f){switch(typeof f){case "bigint":return!0;case "number":return zc(f);case "string":return yWX.test(f);default:return!1}};
  var rj = {};
  var vU = undefined;
  var IG = undefined;
  BU = function(f){if(IG(f)){if(!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(f))throw Error(String(f));}else if(vU(f)&&!Number.isSafeInteger(f))throw Error(String(f));return BigInt(f)};
  var MT = {};
  var se = undefined;
  dj = function(f){var k=rj(Number(f));if(MT(k))return BU(k);k=f.indexOf(".");k!==-1&&(f=f.substring(0,k));return BU(se(64,BigInt(f)))};
  var jf = 0;
  var NT = 0;
  Ue = function(f){var k=f>>>0;jf=k;NT=(f-k)/4294967296>>>0};
  ef = function(f){if(f<0){Ue(0-f);f=jf;var k=NT;k=~k;f?f=~f+1:k+=1;let [G,t]=[f,k];jf=G>>>0;NT=t>>>0}else Ue(f)};
  yX = function(f,k){k>>>=0;f>>>=0;var G;k<=2097151?G=""+(4294967296*k+f):G=""+(BigInt(k)<<BigInt(32)|BigInt(f));return G};
  QX = function(){var f=jf,k=NT,G;k&2147483648?G=""+(BigInt(k|0)<<BigInt(32)|BigInt(f>>>0)):G=yX(f,k);return G};
  qT = function(f,k){var G=k*4294967296+(f>>>0);return Number.isSafeInteger(G)?G:yX(f,k)};
  HU = function(f){C$(f);f=rj(f);if(!MT(f)){ef(f);var k=jf,G=NT;if(f=G&2147483648)k=~k+1>>>0,G=~G>>>0,k==0&&(G=G+1>>>0);k=qT(k,G);f=typeof k==="number"?f?-k:k:f?"-"+k:k}return f};
  by = function(f){MT(f)?f=BU(HU(f)):(C$(f),f=rj(f),MT(f)?f=String(f):(ef(f),f=QX()),f=BU(f));return f};
  a5 = function(f){if(f!=null)a:{if(!C$(f))throw JC("int64");switch(typeof f){case "string":f=dj(f);break a;case "bigint":f=BU(se(64,f));break a;default:f=by(f)}}return f};
  oJF = function(f,k){if(g.e3("web_log_memory_total_kbytes")&&g.Nd.navigator?.deviceMemory){let G=g.Nd.navigator?.deviceMemory;f?nP(f,95,a5(G*1E6)):k&&(k.client.memoryTotalKbytes=`${G*1E6}`)}};
  qP = function(f,k,G="",t){return R5(Es(f,k,t))??G};
  var OM = class extends xb{constructor(f){super(f)}MX(){return qP(this,3)}Yl(){return qP(this,5)}W2(f){return FZ(this,5,f)}};
  WdQ = function(f,k,G){f.appInstallData&&(k?(G=hA(k,OM,62)??new OM,FZ(G,6,f.appInstallData),BR(k,OM,62,G)):G&&(G.client.configInfo=G.client.configInfo||{},G.client.configInfo.appInstallData=f.appInstallData))};
  TGL = function(){var f=g.Nd.navigator;return f?f.connection:void 0};
  var SbO = {bluetooth:"CONN_DISCO",cellular:"CONN_CELLULAR_UNKNOWN",ethernet:"CONN_WIFI",none:"CONN_NONE",wifi:"CONN_WIFI",wimax:"CONN_CELLULAR_4G",other:"CONN_UNKNOWN",unknown:"CONN_UNKNOWN","slow-2g":"CONN_CELLULAR_2G","2g":"CONN_CELLULAR_2G","3g":"CONN_CELLULAR_3G","4g":"CONN_CELLULAR_4G"};
  RUQ = function(){var f=TGL();if(f){var k=SbO[f.type||"unknown"]||"CONN_UNKNOWN";f=SbO[f.effectiveType||"unknown"]||"CONN_UNKNOWN";k==="CONN_CELLULAR_UNKNOWN"&&f!=="CONN_UNKNOWN"&&(k=f);if(k!=="CONN_UNKNOWN")return k;if(f!=="CONN_UNKNOWN")return f}};
  var B9D = {CONN_DEFAULT:0,CONN_UNKNOWN:1,CONN_NONE:2,CONN_WIFI:3,CONN_CELLULAR_2G:4,CONN_CELLULAR_3G:5,CONN_CELLULAR_4G:6,CONN_CELLULAR_UNKNOWN:7,CONN_DISCO:8,CONN_CELLULAR_5G:9,CONN_WIFI_METERED:10,CONN_CELLULAR_5G_SA:11,
CONN_CELLULAR_5G_NSA:12,CONN_WIRED:30,CONN_INVALID:31};
  var jWu = {EFFECTIVE_CONNECTION_TYPE_UNKNOWN:0,EFFECTIVE_CONNECTION_TYPE_OFFLINE:1,EFFECTIVE_CONNECTION_TYPE_SLOW_2G:2,EFFECTIVE_CONNECTION_TYPE_2G:3,EFFECTIVE_CONNECTION_TYPE_3G:4,EFFECTIVE_CONNECTION_TYPE_4G:5};
  var cI6 = {"slow-2g":"EFFECTIVE_CONNECTION_TYPE_SLOW_2G","2g":"EFFECTIVE_CONNECTION_TYPE_2G","3g":"EFFECTIVE_CONNECTION_TYPE_3G","4g":"EFFECTIVE_CONNECTION_TYPE_4G"};
  pyE = function(){var f=TGL();if(f?.effectiveType)return cI6.hasOwnProperty(f.effectiveType)?cI6[f.effectiveType]:"EFFECTIVE_CONNECTION_TYPE_UNKNOWN"};
  Dha = function(f,k){var G=RUQ();G&&(f?Kx(f,61,B9D[G]):k&&(k.client.connectionType=G));g.e3("web_log_effective_connection_type")&&(G=pyE())&&(f?Kx(f,94,jWu[G]):k&&(k.client.effectiveConnectionType=G))};
  Sgy = function(){if(!Dy.instance){let f=new Dy;Dy.instance=f}return Dy.instance};
  t_L = function(){var f=Sgy(),k=(0,g.S)()-f.W;if(!(f.W!==0&&k<yZ("send_config_hash_timer"))){k=g.qd("yt.gcf.config.coldConfigData");var G=g.qd("yt.gcf.config.hotHashData"),t=g.qd("yt.gcf.config.coldHashData");k&&G&&t&&(f.W=(0,g.S)());return{coldConfigData:k,hotHashData:G,coldHashData:t}}};
  V_y = function(f,k){var G=t_L();if(G){var t=G.coldConfigData,Z=G.coldHashData;G=G.hotHashData;f?(k=hA(f,OM,62)??new OM,t=FZ(k,1,t),FZ(t,3,Z).W2(G),BR(f,OM,62,k)):k&&(k.client.configInfo=k.client.configInfo||{},t&&(k.client.configInfo.coldConfigData=t),Z&&(k.client.configInfo.coldHashData=Z),G&&(k.client.configInfo.hotHashData=G))}};
  var KJa = String(PY);
  var $0D = {};
  WI = function(f){return decodeURIComponent(f.replace(/\+/g," "))};
  var Eby = /^[\w.]*$/;
  ATH = function(f){return f&&f.match(Eby)?f:WI(f)};
  ID = function(f){var k=typeof f;return k!="object"?k:f?Array.isArray(f)?"array":k:"null"};
  g.FL = function(f){var k=ID(f);return k=="array"||k=="object"&&typeof f.length=="number"};
  g.Be = function(f,k){for(let G=1;G<arguments.length;G++){let t=arguments[G];if(g.FL(t)){let Z=f.length||0,u=t.length||0;f.length=Z+u;for(let h=0;h<u;h++)f[Z+h]=t[h]}else f.push(t)}};
  PY = function(f,k){k=f.split(k);var G={};for(let u=0,h=k.length;u<h;u++){let W=k[u].split("=");if(W.length===1&&W[0]||W.length===2)try{let D=ATH(W[0]||""),V=ATH(W[1]||"");if(D in G){let U=G[D];Array.isArray(U)?g.Be(U,V):G[D]=[U,V]}else G[D]=V}catch(D){var t=D,Z=W[0];let V=String(PY);t.args=[{key:Z,value:W[1],query:f,method:KJa===V?"unchanged":V}];$0D.hasOwnProperty(Z)||NZ(t)}}return G};
  IE = function(f){f.charAt(0)==="?"&&(f=f.substring(1));return PY(f,"&")};
  g.ew = function(f){var k={client:{hl:f.On,gl:f.uT,clientName:f.La,clientVersion:f.innertubeContextClientVersion,configInfo:f.xB}};navigator.userAgent&&(k.client.userAgent=String(navigator.userAgent));var G=g.Nd.devicePixelRatio;G&&G!=1&&(k.client.screenDensityFloat=String(G));G=qZ();G!==""&&(k.client.experimentsToken=G);G=OH();G.length>0&&(k.request={internalExperimentFlags:G});u7E(f,void 0,k);hIa(void 0,k);oJF(void 0,k);WdQ(f,void 0,k);Dha(void 0,k);g.e3("start_client_gcf")&&V_y(void 0,k);g.DR("DELEGATED_SESSION_ID")&&
!g.e3("pageid_as_header_web")&&(k.user={onBehalfOfUser:g.DR("DELEGATED_SESSION_ID")});!g.e3("fill_delegate_context_in_gel_killswitch")&&(f=g.DR("INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT"))&&(k.user={...k.user,serializedDelegationContext:f});f=g.DR("INNERTUBE_CONTEXT");g.e3("enable_persistent_device_token")&&f?.client?.rolloutToken&&(k.client.rolloutToken=f?.client?.rolloutToken);f=Object;G=f.assign;var t=k.client,Z=g.DR("DEVICE",""),u={};for(let [h,W]of Object.entries(IE(Z))){Z=h;let D=W;Z===
"cbrand"?u.deviceMake=D:Z==="cmodel"?u.deviceModel=D:Z==="cbr"?u.browserName=D:Z==="cbrver"?u.browserVersion=D:Z==="cos"?u.osName=D:Z==="cosver"?u.osVersion=D:Z==="cplatform"&&(u.platform=D)}k.client=G.call(f,t,u);g.e3("web_attention_logging_enabled")&&(k.client.windowWidthPoints=window.innerWidth,k.client.windowHeightPoints=window.innerHeight);return k};
  g.Rp = function(f){if(!f||typeof f!=="object")return f;if(typeof f.clone==="function")return f.clone();if(typeof Map!=="undefined"&&f instanceof Map)return new Map(f);if(typeof Set!=="undefined"&&f instanceof Set)return new Set(f);if(f instanceof Date)return new Date(f.getTime());var k=Array.isArray(f)?[]:typeof ArrayBuffer!=="function"||typeof ArrayBuffer.isView!=="function"||!ArrayBuffer.isView(f)||f instanceof DataView?{}:new f.constructor(f.length);for(let G in f)k[G]=g.Rp(f[G]);return k};
  VHa = function(f,k,G){if(G.videoId)var t="VIDEO";else if(G.playlistId)t="PLAYLIST";else return;f.credentialTransferTokenTargetId=G;f.context=f.context||{};f.context.user=f.context.user||{};f.context.user.credentialTransferTokens=[{token:k,scope:t}]};
  Jv = function(){return g.e3("use_request_time_ms_header")};
  qBQ = function(){var f=g.DR("BATCH_CLIENT_COUNTER")||0;f||(f=Math.floor(Math.random()*65535/2));f++;f>65535&&(f=1);WY("BATCH_CLIENT_COUNTER",f);return f};
  vSE = function(f,k,G){Jv()||(f.requestTimeMs=String(k));g.e3("unsplit_gel_payloads_in_logs")&&(f.unsplitGelPayloadsInLogs=!0);!G&&(k=g.DR("EVENT_ID"))&&(G=qBQ(),f.serializedClientEventId={serializedEventId:k,clientCounter:String(G)})};
  BhL = function(f){g.e3("always_send_and_write")&&(f.writeThenSend=!1)};
  g.o$ = class{constructor(f){this.name=f}};
  var PoL = {};
  g.x = function(f,k){if(f)return f[k.name]};
  var Qu6 = {};
  kQf = async function(f,k,G){if(g.e3("start_client_gcf")){G&&VA(f,G);f.W2(k);let t=uc();t&&(G||(G=(await lLL(t))?.config),await Hnc(G,k,t));if(G){f=f.A;for(let Z of f.B)Z(G)}}};
  GQD = async function(f,k,G){g.e3("start_client_gcf")&&(Nb(f,k),f=uc())&&(G||(G=(await X0E(f))?.config),G&&await xG6(G,k,G.configData,f))};
  var Q8 = class{constructor(f){this.name=f}toString(){return`InjectionToken(${this.name})`}};
  var I1Q = {};
  juu = async function(f){f=f?.responseContext?.globalConfigGroup;var k=g.x(f,PoL),G=f?.hotHashData,t=g.x(f,Qu6),Z=f?.coldHashData,u=eN().resolve(vQ(Dy));u&&(G&&(k?await kQf(u,G,k):await kQf(u,G)),Z&&(t?await GQD(u,Z,t):await GQD(u,Z)));k=f?.rawFinchStaticConfigGroup;(f=f?.finchStaticHashData)?(G=eN().resolve(vQ(I1Q)))?await G.XIz({config:k||{},x6e:f||""}):(k||f)&&NZ(new g.U3("FinchConfigManagerService is not present, but Finch config data is present.")):k&&NZ(new g.U3("Finch config data is present, but hash is missing."))};
  Ro = function(f,k,G,t,Z){f={retry:!0,onSuccess:G,onError:t,networklessOptions:f,dangerousLogToVisitorSession:k,zUL:!!Z,headers:{},postBodyFormat:"",postBody:"",compress:g.e3("compress_gel")||g.e3("compress_gel_lr")};Jv()&&(f.headers["X-Goog-Request-Time"]=JSON.stringify(Math.round((0,g.S)())));return f};
  var PJ = {identityType:"UNAUTHENTICATED_IDENTITY_TYPE_UNKNOWN"};
  wSF = function(f){if(!f)return"";if(/^about:(?:blank|srcdoc)$/.test(f))return window.origin||"";f.indexOf("blob:")===0&&(f=f.substring(5));f=f.split("#")[0].split("?")[0];f=f.toLowerCase();f.indexOf("//")==0&&(f=window.location.protocol+f);/^[\w\-]*:\/\//.test(f)||(f=window.location.href);var k=f.substring(f.indexOf("://")+3),G=k.indexOf("/");G!=-1&&(k=k.substring(0,G));G=f.substring(0,f.indexOf("://"));if(!G)throw Error("URI is missing protocol: "+f);if(G!=="http"&&G!=="https"&&G!=="chrome-extension"&&
G!=="moz-extension"&&G!=="file"&&G!=="android-app"&&G!=="chrome-search"&&G!=="chrome-untrusted"&&G!=="chrome"&&G!=="app"&&G!=="devtools")throw Error("Invalid URI scheme in origin: "+G);f="";var t=k.indexOf(":");if(t!=-1){var Z=k.substring(t+1);k=k.substring(0,t);if(G==="http"&&Z!=="80"||G==="https"&&Z!=="443")f=":"+Z}return G+"://"+k+f};
  g.HH = function(f,k,G){Array.prototype.forEach.call(f,k,G)};
  asH = function(){function f(){Z[0]=1732584193;Z[1]=4023233417;Z[2]=2562383102;Z[3]=271733878;Z[4]=3285377520;U=V=0}
function k(e){for(var q=h,O=0;O<64;O+=4)q[O/4]=e[O]<<24|e[O+1]<<16|e[O+2]<<8|e[O+3];for(O=16;O<80;O++)e=q[O-3]^q[O-8]^q[O-14]^q[O-16],q[O]=(e<<1|e>>>31)&4294967295;e=Z[0];var F=Z[1],m=Z[2],a=Z[3],r=Z[4];for(O=0;O<80;O++){if(O<40)if(O<20){var X=a^F&(m^a);var l=1518500249}else X=F^m^a,l=1859775393;else O<60?(X=F&m|a&(F|m),l=2400959708):(X=F^m^a,l=3395469782);X=((e<<5|e>>>27)&4294967295)+X+r+l+q[O]&4294967295;r=a;a=m;m=(F<<30|F>>>2)&4294967295;F=e;e=X}Z[0]=Z[0]+e&4294967295;Z[1]=Z[1]+F&4294967295;Z[2]=
Z[2]+m&4294967295;Z[3]=Z[3]+a&4294967295;Z[4]=Z[4]+r&4294967295}
function G(e,q){if(typeof e==="string"){e=unescape(encodeURIComponent(e));for(var O=[],F=0,m=e.length;F<m;++F)O.push(e.charCodeAt(F));e=O}q||(q=e.length);O=0;if(V==0)for(;O+64<q;)k(e.slice(O,O+64)),O+=64,U+=64;for(;O<q;)if(u[V++]=e[O++],U++,V==64)for(V=0,k(u);O+64<q;)k(e.slice(O,O+64)),O+=64,U+=64}
function t(){var e=[],q=U*8;V<56?G(W,56-V):G(W,64-(V-56));for(var O=63;O>=56;O--)u[O]=q&255,q>>>=8;k(u);for(O=q=0;O<5;O++)for(var F=24;F>=0;F-=8)e[q++]=Z[O]>>F&255;return e}
for(var Z=[],u=[],h=[],W=[128],D=1;D<64;++D)W[D]=0;var V,U;f();return{reset:f,update:G,digest:t,XT:function(){for(var e=t(),q="",O=0;O<e.length;O++)q+="0123456789ABCDEF".charAt(Math.floor(e[O]/16))+"0123456789ABCDEF".charAt(e[O]%16);return q}}};
  HUQ = function(f){var k=asH();k.update(f);return k.XT().toLowerCase()};
  rdc = function(f,k,G){var t=[],Z=[];if((Array.isArray(G)?2:1)==1)return Z=[k,f],g.HH(t,function(W){Z.push(W)}),HUQ(Z.join(" "));
var u=[],h=[];g.HH(G,function(W){h.push(W.key);u.push(W.value)});
G=Math.floor((new Date).getTime()/1E3);Z=u.length==0?[G,k,f]:[u.join(":"),G,k,f];g.HH(t,function(W){Z.push(W)});
f=HUQ(Z.join(" "));f=[G,f];h.length==0||f.push(h.join(""));return f.join("_")};
  M8f = function(f,k,G){var t=String(g.Nd.location.href);return t&&f&&k?[k,rdc(wSF(t),f,G||null)].join(" "):null};
  XSL = function(f,k,G,t){(f=g.Nd[f])||typeof document==="undefined"||(f=(new Hb(document)).get(k));return f?M8f(f,G,t):null};
  x6f = function(){var f=g.Nd.__SAPISID||g.Nd.__APISID||g.Nd.__3PSAPISID||g.Nd.__1PSAPISID||g.Nd.__OVERRIDE_SID;if(f)return!0;typeof document!=="undefined"&&(f=new Hb(document),f=f.get("SAPISID")||f.get("APISID")||f.get("__Secure-3PAPISID")||f.get("__Secure-1PAPISID"));return!!f};
  lsE = function(f){var k=wSF(g.Nd?.location.href),G=[];if(x6f()){k=k.indexOf("https:")==0||k.indexOf("chrome-extension:")==0||k.indexOf("chrome-untrusted://new-tab-page")==0||k.indexOf("moz-extension:")==0;var t,Z=(t=k)?g.Nd.__SAPISID:g.Nd.__APISID;Z||typeof document==="undefined"||(Z=new Hb(document),Z=Z.get(t?"SAPISID":"APISID")||Z.get("__Secure-3PAPISID"));(t=Z?M8f(Z,t?"SAPISIDHASH":"APISIDHASH",f):null)&&G.push(t);k&&((k=XSL("__1PSAPISID","__Secure-1PAPISID","SAPISID1PHASH",f))&&G.push(k),(f=XSL("__3PSAPISID",
"__Secure-3PAPISID","SAPISID3PHASH",f))&&G.push(f))}return G.length==0?null:G.join(" ")};
  var oB = class{constructor(){this.oT=!0}PZ(f,k){f={};var G=[];"USER_SESSION_ID"in oE&&G.push({key:"u",value:g.DR("USER_SESSION_ID")});if(G=lsE(G))f.Authorization=G,G=k=k?.sessionIndex,G===void 0&&(G=Number(g.DR("SESSION_INDEX",0)),G=isNaN(G)?0:G),g.e3("voice_search_auth_header_removal")||(f["X-Goog-AuthUser"]=G.toString()),"INNERTUBE_HOST_OVERRIDE"in oE||(f["X-Origin"]=window.location.origin),k===void 0&&"DELEGATED_SESSION_ID"in oE&&(f["X-Goog-PageId"]=g.DR("DELEGATED_SESSION_ID"));return f}};
  HNH = function(){oB.instance||(oB.instance=new oB);return oB.instance};
  N9D = function(f,k,G={}){var t={};g.DR("EOM_VISITOR_DATA")?t={"X-Goog-EOM-Visitor-Id":g.DR("EOM_VISITOR_DATA")}:t={"X-Goog-Visitor-Id":G.visitorData||g.DR("VISITOR_DATA","")};if(k&&k.includes("www.youtube-nocookie.com"))return t;k=G.Nq||g.DR("AUTHORIZATION");k||(f?k=`Bearer ${g.qd("gapi.auth.getToken")().access_token}`:(f=HNH().PZ(PJ),g.e3("pageid_as_header_web")||delete f["X-Goog-PageId"],t={...t,...f}));k&&(t.Authorization=k);return t};
  g.wC = function(f,k){return f!==null&&k in f};
  g.o7 = function(f){return encodeURIComponent(String(f))};
  xo = function(f,k,G){if(Array.isArray(k))for(let t=0;t<k.length;t++)xo(f,String(k[t]),G);else k!=null&&G.push(f+(k===""?"":"="+g.o7(k)))};
  g.Ta = function(f){var k=[];for(let G in f)xo(G,f[G],k);return k.join("&")};
  Hy = function(f,k){if(!k)return f;var G=f.indexOf("#");G<0&&(G=f.length);var t=f.indexOf("?");if(t<0||t>G){t=G;var Z=""}else Z=f.substring(t+1,G);f=[f.slice(0,t),Z,f.slice(G)];G=f[1];f[1]=k?G?G+"&"+k:k:G;return f[0]+(f[1]?"?"+f[1]:"")+f[2]};
  g.Sh = function(f,k){k=g.Ta(k);return Hy(f,k)};
  i6L = function(f,k,G){if(g.e3("fix_uri_parsing_for_legacy_underescaping")){var t=(f||"").split("#",2);f=t[0];t=t.length>1?"#"+t[1]:"";let h=f.indexOf("?");var Z=h!==-1?f.substring(0,h):f;f=IE(h!==-1?f.substring(h+1):"");for(var u in k)if(G||!g.wC(f,u))f[u]=k[u];return g.Sh(Z,f)+t}u=f.split("#",2);f=u[0];u=u.length>1?"#"+u[1]:"";Z=f.split("?",2);f=Z[0];Z=IE(Z[1]||"");for(t in k)if(G||!g.wC(Z,t))Z[t]=k[t];return g.Sh(f,Z)+u};
  Kt = function(f,k){return i6L(f,k||{},!0)};
  MjH = function(f,k){k.includeDomain&&(f=document.location.protocol+"//"+document.location.hostname+(document.location.port?":"+document.location.port:"")+f);var G=g.DR("XSRF_FIELD_NAME");if(k=k.urlParams)k[G]&&delete k[G],f=Kt(f,k);return f};
  var Xe6 = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
  g.CN = function(f){return f.match(Xe6)};
  Eb = function(f){return f?decodeURI(f):f};
  g.sb = function(f){return Eb(g.CN(f)[3]||null)};
  var ce = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
  g.pi = function(f,k){for(let Z=1;Z<arguments.length;Z++){var G=arguments[Z];for(t in G)f[t]=G[t];for(let u=0;u<ce.length;u++){var t=ce[u];Object.prototype.hasOwnProperty.call(G,t)&&(f[t]=G[t])}}};
  g.xM = function(f){for(let k in f)return!1;return!0};
  var GaF = !1;
  H6E = function(f,k){var G=g.DR("XSRF_FIELD_NAME"),t=g.DR("XSRF_TOKEN"),Z=k.postBody||"",u=k.postParams,h=g.DR("XSRF_FIELD_NAME"),W;k.headers&&(W=k.headers["Content-Type"]);k.excludeXsrf||g.sb(f)&&!k.withCredentials&&g.sb(f)!==document.location.hostname||k.method!=="POST"||W&&W!=="application/x-www-form-urlencoded"||k.postParams&&k.postParams[h]||(u||(u={}),u[G]=t);u&&typeof Z==="string"&&(Z=IE(Z),g.pi(Z,u),Z=k.postBodyFormat&&k.postBodyFormat==="JSON"?JSON.stringify(Z):g.Ta(Z));u=Z||u&&!g.xM(u);!GaF&&
u&&k.method!=="POST"&&(GaF=!0,g.BY(Error("AJAX request with postData should use POST")));return Z};
  mK = function(f){return f&&"status"in f?f.status:-1};
  g.nt = function(f){switch(mK(f)){case 200:case 201:case 202:case 203:case 204:case 205:case 206:case 304:return!0;default:return!1}};
  ZNF = function(f){var k="";g.HH(f.childNodes,G=>{k+=G.nodeValue});
return k};
  thX = function(f){return f?(f=("responseXML"in f?f.responseXML:f).getElementsByTagName("root"))&&f.length>0?f[0]:null:null};
  var $6 = {};
  FuX = function(){var f=null;if(!$6)return f;try{let k=G=>G;
f=$6.createPolicy("goog#html",{createHTML:k,createScript:k,createScriptURL:k})}catch(k){}return f};
  ij = undefined;
  zt = function(){ij===void 0&&(ij=FuX());return ij};
  var x6 = class{constructor(f){this.B=f}toString(){return this.B+""}};
  Xu = function(f){var k=zt();f=k?k.createHTML(f):f;return new x6(f)};
  Gt = function(f,k){var G=f.length-k.length;return G>=0&&f.indexOf(k,G)==G};
  g.AQ = function(f){var k=typeof f;return k=="object"&&f!=null||k=="function"};
  umE = function(f){if(g.AQ(f))for(let k in f)k==="html_content"||Gt(k,"_html")?f[k]=Xu(f[k]):umE(f[k])};
  Trf = function(f,k,G,t){var Z=null;switch(k){case "JSON":let u;try{u=G.responseText}catch(h){throw t=Error("Error reading responseText"),t.params=f,NZ(t),h;}f=G.getResponseHeader("Content-Type")||"";if(u&&f.indexOf("json")>=0){u.substring(0,5)===")]}'\n"&&(u=u.substring(5));try{Z=JSON.parse(u)}catch(h){}}break;case "XML":if(f=(f=G.responseXML)?thX(f):null)Z={},g.HH(f.getElementsByTagName("*"),h=>{Z[h.tagName]=ZNF(h)})}t&&umE(Z);
return Z};
  SOy = function(f,k,G){if(k&&k.status===204)return!0;switch(f){case "JSON":return!!G;case "XML":return Number(G&&G.return_code)===0;case "RAW":return!0;default:return!!G}};
  var sPy = undefined;
  b6H = function(){if(!sPy)return null;var f=sPy();return"open"in f?f:null};
  i$ = function(f){if(!k)var k=window.location.href;var G=g.CN(f)[1]||null,t=g.sb(f);G&&t?(f=g.CN(f),k=g.CN(k),f=f[3]==k[3]&&f[1]==k[1]&&f[4]==k[4]):f=t?g.sb(k)===t&&(Number(g.CN(k)[4]||null)||null)===(Number(g.CN(f)[4]||null)||null):!0;return f};
  be = function(f){return Eb(g.CN(f)[5]||null)};
  var UHb = "absolute_experiments client_dev_domain client_dev_expflag client_dev_regex_map client_dev_root_url client_rollout_override expflag forcedCapability jsfeat jsmode mods theme".split(" ");
  var hUd = [];
  $i = function(f,k){return i6L(f,k||{},!1)};
  wcD = function(f){var k=window.location.search,G=g.sb(f);g.e3("debug_handle_relative_url_for_query_forward_killswitch")||!G&&i$(f)&&(G=document.location.hostname);var t=be(f);t=(G=G&&(G.endsWith("youtube.com")||G.endsWith("youtube-nocookie.com")))&&t&&t.startsWith("/api/");if(!G||t)return f;var Z=IE(k),u={};g.HH(hUd,h=>{Z[h]&&(u[h]=Z[h])});
return $i(f,u)};
  var rT6 = {Authorization:"AUTHORIZATION","X-Goog-EOM-Visitor-Id":"EOM_VISITOR_DATA","X-Goog-Visitor-Id":"SANDBOXED_VISITOR_ID","X-Youtube-Domain-Admin-State":"DOMAIN_ADMIN_STATE","X-Youtube-Chrome-Connected":"CHROME_CONNECTED_HEADER","X-YouTube-Client-Name":"INNERTUBE_CONTEXT_CLIENT_NAME","X-YouTube-Client-Version":"INNERTUBE_CONTEXT_CLIENT_VERSION","X-YouTube-Delegation-Context":"INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT","X-YouTube-Device":"DEVICE","X-Youtube-Identity-Token":"ID_TOKEN","X-YouTube-Page-CL":"PAGE_CL",
"X-YouTube-Page-Label":"PAGE_BUILD_LABEL","X-Goog-AuthUser":"SESSION_INDEX","X-Goog-PageId":"DELEGATED_SESSION_ID"};
  zSy = function(f){f=g.sb(f);return f!==null?f.split(".").reverse():null};
  CNa = function(f){f=zSy(f);return f===null?!1:f[1]==="google"?!0:f[2]==="google"?f[0]==="au"&&f[1]==="com"?!0:f[0]==="uk"&&f[1]==="co"?!0:!1:!1};
  var LJX = {};
  var m0X = undefined;
  var Qj = window;
  nba = function(f){a:{let G;try{G=f.B.top.location.href}catch(t){f=2;break a}f=G?G===f.K.location.href?0:1:2}f={dt:m0X,flash:"0",frm:f};try{f.u_tz=-(new Date).getTimezoneOffset();try{var k=Qj.history.length}catch(G){k=0}f.u_his=k;f.u_h=Qj.screen?.height;f.u_w=Qj.screen?.width;f.u_ah=Qj.screen?.availHeight;f.u_aw=Qj.screen?.availWidth;f.u_cd=Qj.screen?.colorDepth}catch(G){}return f};
  g.nY = function(f,k){this.width=f;this.height=k};
  g.n = g.nY.prototype;
  g.n.clone = function(){return new g.nY(this.width,this.height)};
  g.n.aspectRatio = function(){return this.width/this.height};
  du = function(f){return f.width*f.height};
  g.n.isEmpty = function(){return!du(this)};
  g.n.ceil = function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
  g.n.floor = function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
  g.n.round = function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};
  g.n.scale = function(f,k){k=typeof k==="number"?k:f;this.width*=f;this.height*=k;return this};
  Jr = function(f){f=f.document;f=f.compatMode=="CSS1Compat"?f.documentElement:f.body;return new g.nY(f.clientWidth,f.clientHeight)};
  Vo = function(f,k,G=!1){if(f&&k!==null&&k!=k.top){if(!k.top)return new g.nY(-12245933,-12245933);k=k.top}try{return G?(new g.nY(k.innerWidth,k.innerHeight)).round():Jr(k||window).round()}catch(t){return new g.nY(-12245933,-12245933)}};
  var d0D = class{constructor(){this.data=[];this.B=-1}set(f,k=!0){0<=f&&f<52&&Number.isInteger(f)&&this.data[f]!==k&&(this.data[f]=k,this.B=-1)}get(f){return!!this.data[f]}};
  AC = function(f,k=document){return k.createElement(String(f).toLowerCase())};
  var taD = {Fq:"allow-forms",a_:"allow-modals",mf:"allow-orientation-lock",T8:"allow-pointer-lock",o_:"allow-popups",wZ:"allow-popups-to-escape-sandbox",I_:"allow-presentation",PN:"allow-same-origin",Xq:"allow-scripts",vN:"allow-top-navigation",jR:"allow-top-navigation-by-user-activation"};
  qp = function(f,k){if(f)for(let G in f)Object.prototype.hasOwnProperty.call(f,G)&&k(f[G],G,f)};
  Zia = function(){var f=[];qp(taD,k=>{f.push(k)});
return f};
  ir = function(f){var k=!1,G;return function(){k||(G=f(),k=!0);return G}};
  var DAO = undefined;
  Vaa = function(){var f=AC("IFRAME"),k={};g.HH(DAO(),G=>{f.sandbox&&f.sandbox.supports&&f.sandbox.supports(G)&&(k[G]=!0)});
return k};
  WLc = function(f){f.B===-1&&(f.B=f.data.reduce((k,G,t)=>k+(G?2**t:0),0));
return f.B};
  V7 = function(f){return f.prerendering?3:{visible:1,hidden:2,prerender:3,preview:4,unloaded:5,"":0}[f.visibilityState||f.webkitVisibilityState||f.mozVisibilityState||""]??0};
  QPu = function(){return g.qd("yt.ads.biscotti.lastId_")||""};
  EH = function(f=QPu()){var k=LJX,G=Object,t=G.assign,Z=nba(k);var u=k.B;try{var h=u.screenX;var W=u.screenY}catch(a){}try{var D=u.outerWidth;var V=u.outerHeight}catch(a){}try{var U=u.innerWidth;var e=u.innerHeight}catch(a){}try{var q=u.screenLeft;var O=u.screenTop}catch(a){}try{U=u.innerWidth,e=u.innerHeight}catch(a){}try{var F=u.screen.availWidth;var m=u.screen.availTop}catch(a){}u=[q,O,h,W,F,m,D,V,U,e];h=Vo(!1,k.B.top);W=new d0D;"SVGElement"in g.Nd&&"createElementNS"in g.Nd.document&&W.set(0);D=Vaa();
D["allow-top-navigation-by-user-activation"]&&W.set(1);D["allow-popups-to-escape-sandbox"]&&W.set(2);g.Nd.crypto&&g.Nd.crypto.subtle&&W.set(3);"TextDecoder"in g.Nd&&"TextEncoder"in g.Nd&&W.set(4);W=WLc(W);k=t.call(G,Z,{bc:W,bih:h.height,biw:h.width,brdim:u.join(),vis:V7(k.K),wgl:!!Qj.WebGLRenderingContext});k.ca_type="image";f&&(k.bid=f);return k};
  g.is = function(f,k,G){for(let t in f)k.call(G,f[t],t,f)};
  QZ = function(f){var k=[];g.is(f,(G,t)=>{var Z=g.o7(t);g.HH(Array.isArray(G)?G:[G],u=>{u==""?k.push(Z):k.push(`${Z}=${g.o7(u)}`)})});
return k.join("&")};
  auF = function(f,k={}){var G=i$(f),t=g.DR("INNERTUBE_CLIENT_NAME"),Z=g.e3("web_ajax_ignore_global_headers_if_set");for(let W in rT6){let D=g.DR(rT6[W]),V=W==="X-Goog-AuthUser"||W==="X-Goog-PageId";W!=="X-Goog-Visitor-Id"||D||(D=g.DR("VISITOR_DATA"));var u;if(!(u=!D)){if(!(u=G||(g.sb(f)?!1:!0))){u=f;var h;if(h=g.e3("add_auth_headers_to_remarketing_google_dot_com_ping")&&W==="Authorization"&&(t==="TVHTML5"||t==="TVHTML5_UNPLUGGED"||t==="TVHTML5_SIMPLY")&&CNa(u))u=be(u)||"",u=u.split("/"),u="/"+(u.length>
1?u[1]:""),h=u==="/pagead";u=h?!0:!1}u=!u}u||Z&&k[W]!==void 0||t==="TVHTML5_UNPLUGGED"&&V||(k[W]=D)}"X-Goog-EOM-Visitor-Id"in k&&"X-Goog-Visitor-Id"in k&&delete k["X-Goog-Visitor-Id"];if(G||!g.sb(f))k["X-YouTube-Utc-Offset"]=String(-(new Date).getTimezoneOffset());if(G||!g.sb(f)){let W;try{W=(new Intl.DateTimeFormat).resolvedOptions().timeZone}catch{}W&&(k["X-YouTube-Time-Zone"]=W)}document.location.hostname.endsWith("youtubeeducation.com")||!G&&g.sb(f)||(k["X-YouTube-Ad-Signals"]=QZ(EH()));return k};
  wv = function(f,k,G="GET",t="",Z,u,h,W=!1,D){var V=b6H();if(!V)return null;var U=()=>{(V&&"readyState"in V?V.readyState:0)===4&&k&&g.j3(k)(V)};
"onloadend"in V?V.addEventListener("loadend",U,!1):V.onreadystatechange=U;g.e3("debug_forward_web_query_parameters")&&(f=wcD(f));V.open(G,f,!0);u&&(V.responseType=u);h&&(V.withCredentials=!0);G=G==="POST"&&(window.FormData===void 0||!(t instanceof FormData));if(Z=auF(f,Z))for(let e in Z)V.setRequestHeader(e,Z[e]),"content-type"===e.toLowerCase()&&(G=!1);G&&V.setRequestHeader("Content-Type","application/x-www-form-urlencoded");D&&"onprogress"in V&&(V.onprogress=()=>{D(V.responseText)});
if(W&&"setAttributionReporting"in XMLHttpRequest.prototype){f={eventSourceEligible:!0,triggerEligible:!1};try{V.setAttributionReporting(f)}catch(e){NZ(e)}}V.send(t);return V};
  var luO = wv;
  g.aE = function(f,k){var G=k.format||"JSON";f=MjH(f,k);var t=H6E(f,k),Z=!1,u=luO(f,W=>{if(!Z){Z=!0;h&&g.sH(h);var D=g.nt(W),V=null,U=400<=W.status&&W.status<500,e=500<=W.status&&W.status<600;if(D||U||e)V=Trf(f,G,W,k.convertToSafeHtml);D&&(D=SOy(G,W,V));V=V||{};U=k.context||g.Nd;D?k.onSuccess&&k.onSuccess.call(U,W,V):k.onError&&k.onError.call(U,W,V);k.onFinish&&k.onFinish.call(U,W,V)}},k.method,t,k.headers,k.responseType,k.withCredentials,!1,k.onProgress);
t=k.timeout||0;if(k.onTimeout&&t>0){let W=k.onTimeout;var h=g.Lt(()=>{Z||(Z=!0,u.abort(),g.sH(h),W.call(k.context||g.Nd,u))},t)}return u};
  rv = function(f,k){k.method="POST";k.postParams||(k.postParams={});return g.aE(f,k)};
  QWX = function(f){try{return(new Blob(f.split(""))).size}catch(k){return NZ(k),null}};
  g.L5 = function(f){var k=[],G=0;for(let t=0;t<f.length;t++){let Z=f.charCodeAt(t);Z<128?k[G++]=Z:(Z<2048?k[G++]=Z>>6|192:((Z&64512)==55296&&t+1<f.length&&(f.charCodeAt(t+1)&64512)==56320?(Z=65536+((Z&1023)<<10)+(f.charCodeAt(++t)&1023),k[G++]=Z>>18|240,k[G++]=Z>>12&63|128):k[G++]=Z>>12|224,k[G++]=Z>>6&63|128),k[G++]=Z&63|128)}return k};
  var s7C = undefined;
  var AmE = undefined;
  var I8 = {};
  var Z66 = function(){this.input=null;this.IH=this.uh=this.Fl=0;this.output=null;this.C8=this.Iw=this.YS=0;this.msg="";this.state=null;this.q7=2;this.Ep=0};
  HT = function(f){for(var k=f.length;--k>=0;)f[k]=0};
  GrO = function(){this.Mh=null;this.status=0;this.kG=null;this.wrap=this.pending=this.hC=this.Ze=0;this.bp=null;this.Rq=0;this.method=8;this.ZN=-1;this.by=this.ue=this.cI=0;this.window=null;this.UZ=0;this.head=this.Ol=null;this.fg=this.aj=this.strategy=this.level=this.r7=this.yg=this.Kh=this.KE=this.DN=this.FA=this.eb=this.rJ=this.yB=this.b1=this.kP=this.Zs=this.Xz=this.sI=this.HO=0;this.EA=new I8.a8(1146);this.xW=new I8.a8(122);this.GN=new I8.a8(78);HT(this.EA);HT(this.xW);HT(this.GN);this.W6=this.Ox=
this.jp=null;this.cB=new I8.a8(16);this.heap=new I8.a8(573);HT(this.heap);this.cK=this.Ga=0;this.depth=new I8.a8(573);HT(this.depth);this.bv=this.N5=this.Xx=this.matches=this.xv=this.Q2=this.O0=this.nh=this.a$=this.ML=0};
  var rB = {2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"};
  M5 = function(f,k){f.msg=rB[k];return k};
  var Ev = Array(256);
  var m9 = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var ne = Array(29);
  var Le = Array(512);
  var dB = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  var bT = Array(30);
  var Xe = Array(576);
  Hxc = function(f,k){var G=0;do G|=f&1,f>>>=1,G<<=1;while(--k>0);return G>>>1};
  xPy = function(f,k,G){var t=Array(16),Z=0,u;for(u=1;u<=15;u++)t[u]=Z=Z+G[u-1]<<1;for(G=0;G<=k;G++)Z=f[G*2+1],Z!==0&&(f[G*2]=Hxc(t[Z]++,Z))};
  var lT = Array(60);
  A2 = function(f,k,G,t,Z){this.yr=f;this.Wu=k;this.fG=G;this.dI=t;this.J6=Z;this.cS=f&&f.length};
  hSO = undefined;
  oba = undefined;
  var D0c = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7];
  WJu = undefined;
  var u$c = !1;
  Ke = function(f,k){this.Eu=f;this.e5=0;this.Fn=k};
  XRu = function(f){var k;for(k=0;k<286;k++)f.EA[k*2]=0;for(k=0;k<30;k++)f.xW[k*2]=0;for(k=0;k<19;k++)f.GN[k*2]=0;f.EA[512]=1;f.Q2=f.xv=0;f.nh=f.matches=0};
  var cT = function(f,k,G,t){var Z=f&65535|0;f=f>>>16&65535|0;for(var u;G!==0;){u=G>2E3?2E3:G;G-=u;do Z=Z+k[t++]|0,f=f+Z|0;while(--u);Z%=65521;f%=65521}return Z|f<<16|0};
  gB = function(f){var k=f.cI,G;do{var t=f.UZ-f.KE-f.FA;if(f.FA>=k+(k-262)){I8.BK(f.window,f.window,k,k,0);f.DN-=k;f.FA-=k;f.b1-=k;var Z=G=f.sI;do{var u=f.head[--Z];f.head[Z]=u>=k?u-k:0}while(--G);Z=G=k;do u=f.Ol[--Z],f.Ol[Z]=u>=k?u-k:0;while(--G);t+=k}if(f.Mh.uh===0)break;Z=f.Mh;G=f.window;u=f.FA+f.KE;var h=Z.uh;h>t&&(h=t);h===0?G=0:(Z.uh-=h,I8.BK(G,Z.input,Z.Fl,h,u),Z.state.wrap===1?Z.Ep=cT(Z.Ep,G,h,u):Z.state.wrap===2&&(Z.Ep=pe(Z.Ep,G,h,u)),Z.Fl+=h,Z.IH+=h,G=h);f.KE+=G;if(f.KE+f.Xx>=3)for(t=f.FA-f.Xx,
f.HO=f.window[t],f.HO=(f.HO<<f.kP^f.window[t+1])&f.Zs;f.Xx&&!(f.HO=(f.HO<<f.kP^f.window[t+3-1])&f.Zs,f.Ol[t&f.by]=f.head[f.HO],f.head[f.HO]=t,t++,f.Xx--,f.KE+f.Xx<3););}while(f.KE<262&&f.Mh.uh!==0)};
  gHE = function(f){var k=4093624447,G;for(G=0;G<=31;G++,k>>>=1)if(k&1&&f.EA[G*2]!==0)return 0;if(f.EA[18]!==0||f.EA[20]!==0||f.EA[26]!==0)return 1;for(G=32;G<256;G++)if(f.EA[G*2]!==0)return 1;return 0};
  S2D = function(f,k,G,t){var Z=k*2,u=G*2;return f[Z]<f[u]||f[Z]===f[u]&&t[k]<=t[G]};
  Ce = function(f,k,G){for(var t=f.heap[G],Z=G<<1;Z<=f.Ga;){Z<f.Ga&&S2D(k,f.heap[Z+1],f.heap[Z],f.depth)&&Z++;if(S2D(k,t,f.heap[Z],f.depth))break;f.heap[G]=f.heap[Z];G=Z;Z<<=1}f.heap[G]=t};
  wB = function(f,k){var G=k.Eu,t=k.Fn.yr,Z=k.Fn.cS,u=k.Fn.dI,h,W=-1;f.Ga=0;f.cK=573;for(h=0;h<u;h++)G[h*2]!==0?(f.heap[++f.Ga]=W=h,f.depth[h]=0):G[h*2+1]=0;for(;f.Ga<2;){var D=f.heap[++f.Ga]=W<2?++W:0;G[D*2]=1;f.depth[D]=0;f.Q2--;Z&&(f.xv-=t[D*2+1])}k.e5=W;for(h=f.Ga>>1;h>=1;h--)Ce(f,G,h);D=u;do h=f.heap[1],f.heap[1]=f.heap[f.Ga--],Ce(f,G,1),t=f.heap[1],f.heap[--f.cK]=h,f.heap[--f.cK]=t,G[D*2]=G[h*2]+G[t*2],f.depth[D]=(f.depth[h]>=f.depth[t]?f.depth[h]:f.depth[t])+1,G[h*2+1]=G[t*2+1]=D,f.heap[1]=D++,
Ce(f,G,1);while(f.Ga>=2);f.heap[--f.cK]=f.heap[1];h=k.Eu;D=k.e5;t=k.Fn.yr;Z=k.Fn.cS;u=k.Fn.Wu;var V=k.Fn.fG,U=k.Fn.J6,e,q=0;for(e=0;e<=15;e++)f.cB[e]=0;h[f.heap[f.cK]*2+1]=0;for(k=f.cK+1;k<573;k++){var O=f.heap[k];e=h[h[O*2+1]*2+1]+1;e>U&&(e=U,q++);h[O*2+1]=e;if(!(O>D)){f.cB[e]++;var F=0;O>=V&&(F=u[O-V]);var m=h[O*2];f.Q2+=m*(e+F);Z&&(f.xv+=m*(t[O*2+1]+F))}}if(q!==0){do{for(e=U-1;f.cB[e]===0;)e--;f.cB[e]--;f.cB[e+1]+=2;f.cB[U]--;q-=2}while(q>0);for(e=U;e!==0;e--)for(O=f.cB[e];O!==0;)t=f.heap[--k],
t>D||(h[t*2+1]!==e&&(f.Q2+=(e-h[t*2+1])*h[t*2],h[t*2+1]=e),O--)}xPy(G,W,f.cB)};
  cAF = function(f,k,G){var t,Z=-1,u=k[1],h=0,W=7,D=4;u===0&&(W=138,D=3);k[(G+1)*2+1]=65535;for(t=0;t<=G;t++){var V=u;u=k[(t+1)*2+1];++h<W&&V===u||(h<D?f.GN[V*2]+=h:V!==0?(V!==Z&&f.GN[V*2]++,f.GN[32]++):h<=10?f.GN[34]++:f.GN[36]++,h=0,Z=V,u===0?(W=138,D=3):V===u?(W=6,D=3):(W=7,D=4))}};
  var Y2u = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
  $v = function(f,k){f.kG[f.pending++]=k&255;f.kG[f.pending++]=k>>>8&255};
  iT = function(f,k,G){f.bv>16-G?(f.N5|=k<<f.bv&65535,$v(f,f.N5),f.N5=k>>16-f.bv,f.bv+=G-16):(f.N5|=k<<f.bv&65535,f.bv+=G)};
  zp = function(f,k,G){iT(f,G[k*2],G[k*2+1])};
  pRE = function(f,k,G){var t,Z=-1,u=k[1],h=0,W=7,D=4;u===0&&(W=138,D=3);for(t=0;t<=G;t++){var V=u;u=k[(t+1)*2+1];if(!(++h<W&&V===u)){if(h<D){do zp(f,V,f.GN);while(--h!==0)}else V!==0?(V!==Z&&(zp(f,V,f.GN),h--),zp(f,16,f.GN),iT(f,h-3,2)):h<=10?(zp(f,17,f.GN),iT(f,h-3,3)):(zp(f,18,f.GN),iT(f,h-11,7));h=0;Z=V;u===0?(W=138,D=3):V===u?(W=6,D=3):(W=7,D=4)}}};
  R2f = function(f,k,G){var t=0;if(f.nh!==0){do{var Z=f.kG[f.O0+t*2]<<8|f.kG[f.O0+t*2+1];var u=f.kG[f.ML+t];t++;if(Z===0)zp(f,u,k);else{var h=Ev[u];zp(f,h+256+1,k);var W=m9[h];W!==0&&(u-=ne[h],iT(f,u,W));Z--;h=Z<256?Le[Z]:Le[256+(Z>>>7)];zp(f,h,G);W=dB[h];W!==0&&(Z-=bT[h],iT(f,Z,W))}}while(t<f.nh)}zp(f,256,k)};
  lpy = function(f){f.bv>8?$v(f,f.N5):f.bv>0&&(f.kG[f.pending++]=f.N5);f.N5=0;f.bv=0};
  TKf = function(f,k,G){lpy(f);$v(f,G);$v(f,~G);I8.BK(f.kG,f.window,k,G,f.pending);f.pending+=G};
  xv = function(f){var k=f.state,G=k.pending;G>f.Iw&&(G=f.Iw);G!==0&&(I8.BK(f.output,k.kG,k.hC,G,f.YS),f.YS+=G,k.hC+=G,f.C8+=G,f.Iw-=G,k.pending-=G,k.pending===0&&(k.hC=0))};
  Tp = function(f,k){var G=f.b1>=0?f.b1:-1,t=f.FA-f.b1,Z=0;if(f.level>0){f.Mh.q7===2&&(f.Mh.q7=gHE(f));wB(f,f.jp);wB(f,f.Ox);cAF(f,f.EA,f.jp.e5);cAF(f,f.xW,f.Ox.e5);wB(f,f.W6);for(Z=18;Z>=3&&f.GN[Y2u[Z]*2+1]===0;Z--);f.Q2+=3*(Z+1)+5+5+4;var u=f.Q2+3+7>>>3;var h=f.xv+3+7>>>3;h<=u&&(u=h)}else u=h=t+5;if(t+4<=u&&G!==-1)iT(f,k?1:0,3),TKf(f,G,t);else if(f.strategy===4||h===u)iT(f,2+(k?1:0),3),R2f(f,Xe,lT);else{iT(f,4+(k?1:0),3);G=f.jp.e5+1;t=f.Ox.e5+1;Z+=1;iT(f,G-257,5);iT(f,t-1,5);iT(f,Z-4,4);for(u=0;u<Z;u++)iT(f,
f.GN[Y2u[u]*2+1],3);pRE(f,f.EA,G-1);pRE(f,f.xW,t-1);R2f(f,f.EA,f.xW)}XRu(f);k&&lpy(f);f.b1=f.FA;xv(f.Mh)};
  ft = function(f,k,G,t,Z){this.vu=f;this.E1=k;this.Bg=G;this.dn=t;this.func=Z};
  JAf = function(f,k){var G=f.yg,t=f.FA,Z=f.Kh,u=f.fg,h=f.FA>f.cI-262?f.FA-(f.cI-262):0,W=f.window,D=f.by,V=f.Ol,U=f.FA+258,e=W[t+Z-1],q=W[t+Z];f.Kh>=f.aj&&(G>>=2);u>f.KE&&(u=f.KE);do{var O=k;if(W[O+Z]===q&&W[O+Z-1]===e&&W[O]===W[t]&&W[++O]===W[t+1]){t+=2;for(O++;W[++t]===W[++O]&&W[++t]===W[++O]&&W[++t]===W[++O]&&W[++t]===W[++O]&&W[++t]===W[++O]&&W[++t]===W[++O]&&W[++t]===W[++O]&&W[++t]===W[++O]&&t<U;);O=258-(U-t);t=U-258;if(O>Z){f.DN=k;Z=O;if(O>=u)break;e=W[t+Z-1];q=W[t+Z]}}}while((k=V[k&D])>h&&--G!==
0);return Z<=f.KE?Z:f.KE};
  a8 = function(f,k,G){f.kG[f.O0+f.nh*2]=k>>>8&255;f.kG[f.O0+f.nh*2+1]=k&255;f.kG[f.ML+f.nh]=G&255;f.nh++;k===0?f.EA[G*2]++:(f.matches++,k--,f.EA[(Ev[G]+256+1)*2]++,f.xW[(k<256?Le[k]:Le[256+(k>>>7)])*2]++);return f.nh===f.a$-1};
  Yv = function(f,k){for(var G;;){if(f.KE<262){gB(f);if(f.KE<262&&k===0)return 1;if(f.KE===0)break}G=0;f.KE>=3&&(f.HO=(f.HO<<f.kP^f.window[f.FA+3-1])&f.Zs,G=f.Ol[f.FA&f.by]=f.head[f.HO],f.head[f.HO]=f.FA);G!==0&&f.FA-G<=f.cI-262&&(f.yB=JAf(f,G));if(f.yB>=3)if(G=a8(f,f.FA-f.DN,f.yB-3),f.KE-=f.yB,f.yB<=f.r7&&f.KE>=3){f.yB--;do f.FA++,f.HO=(f.HO<<f.kP^f.window[f.FA+3-1])&f.Zs,f.Ol[f.FA&f.by]=f.head[f.HO],f.head[f.HO]=f.FA;while(--f.yB!==0);f.FA++}else f.FA+=f.yB,f.yB=0,f.HO=f.window[f.FA],f.HO=(f.HO<<f.kP^
f.window[f.FA+1])&f.Zs;else G=a8(f,0,f.window[f.FA]),f.KE--,f.FA++;if(G&&(Tp(f,!1),f.Mh.Iw===0))return 1}f.Xx=f.FA<2?f.FA:2;return k===4?(Tp(f,!0),f.Mh.Iw===0?3:4):f.nh&&(Tp(f,!1),f.Mh.Iw===0)?1:2};
  J2 = function(f,k){for(var G,t;;){if(f.KE<262){gB(f);if(f.KE<262&&k===0)return 1;if(f.KE===0)break}G=0;f.KE>=3&&(f.HO=(f.HO<<f.kP^f.window[f.FA+3-1])&f.Zs,G=f.Ol[f.FA&f.by]=f.head[f.HO],f.head[f.HO]=f.FA);f.Kh=f.yB;f.rJ=f.DN;f.yB=2;G!==0&&f.Kh<f.r7&&f.FA-G<=f.cI-262&&(f.yB=JAf(f,G),f.yB<=5&&(f.strategy===1||f.yB===3&&f.FA-f.DN>4096)&&(f.yB=2));if(f.Kh>=3&&f.yB<=f.Kh){t=f.FA+f.KE-3;G=a8(f,f.FA-1-f.rJ,f.Kh-3);f.KE-=f.Kh-1;f.Kh-=2;do++f.FA<=t&&(f.HO=(f.HO<<f.kP^f.window[f.FA+3-1])&f.Zs,f.Ol[f.FA&f.by]=
f.head[f.HO],f.head[f.HO]=f.FA);while(--f.Kh!==0);f.eb=0;f.yB=2;f.FA++;if(G&&(Tp(f,!1),f.Mh.Iw===0))return 1}else if(f.eb){if((G=a8(f,0,f.window[f.FA-1]))&&Tp(f,!1),f.FA++,f.KE--,f.Mh.Iw===0)return 1}else f.eb=1,f.FA++,f.KE--}f.eb&&(a8(f,0,f.window[f.FA-1]),f.eb=0);f.Xx=f.FA<2?f.FA:2;return k===4?(Tp(f,!0),f.Mh.Iw===0?3:4):f.nh&&(Tp(f,!1),f.Mh.Iw===0)?1:2};
  ki = [];
  var VjE = {};
  MeF = function(f){var k,G,t=f.length,Z=0;for(k=0;k<t;k++){var u=f.charCodeAt(k);if((u&64512)===55296&&k+1<t){var h=f.charCodeAt(k+1);(h&64512)===56320&&(u=65536+(u-55296<<10)+(h-56320),k++)}Z+=u<128?1:u<2048?2:u<65536?3:4}var W=new I8.U7(Z);for(k=G=0;G<Z;k++)u=f.charCodeAt(k),(u&64512)===55296&&k+1<t&&(h=f.charCodeAt(k+1),(h&64512)===56320&&(u=65536+(u-55296<<10)+(h-56320),k++)),u<128?W[G++]=u:(u<2048?W[G++]=192|u>>>6:(u<65536?W[G++]=224|u>>>12:(W[G++]=240|u>>>18,W[G++]=128|u>>>12&63),W[G++]=128|u>>>
6&63),W[G++]=128|u&63);return W};
  GS = function(f){if(!(this instanceof GS))return new GS(f);f=this.options=I8.assign({level:-1,method:8,chunkSize:16384,yq:15,uz:8,strategy:0,to:""},f||{});f.raw&&f.yq>0?f.yq=-f.yq:f.j_&&f.yq>0&&f.yq<16&&(f.yq+=16);this.err=0;this.msg="";this.ended=!1;this.chunks=[];this.Mh=new Z66;this.Mh.Iw=0;var k=this.Mh;var G=f.level,t=f.method,Z=f.yq,u=f.uz,h=f.strategy;if(k){var W=1;G===-1&&(G=6);Z<0?(W=0,Z=-Z):Z>15&&(W=2,Z-=16);if(u<1||u>9||t!==8||Z<8||Z>15||G<0||G>9||h<0||h>4)k=M5(k,-2);else{Z===8&&(Z=9);var D=
new GrO;k.state=D;D.Mh=k;D.wrap=W;D.bp=null;D.ue=Z;D.cI=1<<D.ue;D.by=D.cI-1;D.Xz=u+7;D.sI=1<<D.Xz;D.Zs=D.sI-1;D.kP=~~((D.Xz+3-1)/3);D.window=new I8.U7(D.cI*2);D.head=new I8.a8(D.sI);D.Ol=new I8.a8(D.cI);D.a$=1<<u+6;D.Ze=D.a$*4;D.kG=new I8.U7(D.Ze);D.O0=1*D.a$;D.ML=3*D.a$;D.level=G;D.strategy=h;D.method=t;if(k&&k.state){k.IH=k.C8=0;k.q7=2;G=k.state;G.pending=0;G.hC=0;G.wrap<0&&(G.wrap=-G.wrap);G.status=G.wrap?42:113;k.Ep=G.wrap===2?0:1;G.ZN=0;if(!u$c){t=Array(16);for(u=h=0;u<28;u++)for(ne[u]=h,Z=0;Z<
1<<m9[u];Z++)Ev[h++]=u;Ev[h-1]=u;for(u=h=0;u<16;u++)for(bT[u]=h,Z=0;Z<1<<dB[u];Z++)Le[h++]=u;for(h>>=7;u<30;u++)for(bT[u]=h<<7,Z=0;Z<1<<dB[u]-7;Z++)Le[256+h++]=u;for(Z=0;Z<=15;Z++)t[Z]=0;for(Z=0;Z<=143;)Xe[Z*2+1]=8,Z++,t[8]++;for(;Z<=255;)Xe[Z*2+1]=9,Z++,t[9]++;for(;Z<=279;)Xe[Z*2+1]=7,Z++,t[7]++;for(;Z<=287;)Xe[Z*2+1]=8,Z++,t[8]++;xPy(Xe,287,t);for(Z=0;Z<30;Z++)lT[Z*2+1]=5,lT[Z*2]=Hxc(Z,5);hSO=new A2(Xe,m9,257,286,15);oba=new A2(lT,dB,0,30,15);WJu=new A2([],D0c,0,19,7);u$c=!0}G.jp=new Ke(G.EA,hSO);
G.Ox=new Ke(G.xW,oba);G.W6=new Ke(G.GN,WJu);G.N5=0;G.bv=0;XRu(G);G=0}else G=M5(k,-2);G===0&&(k=k.state,k.UZ=2*k.cI,HT(k.head),k.r7=ki[k.level].E1,k.aj=ki[k.level].vu,k.fg=ki[k.level].Bg,k.yg=ki[k.level].dn,k.FA=0,k.b1=0,k.KE=0,k.Xx=0,k.yB=k.Kh=2,k.eb=0,k.HO=0);k=G}}else k=-2;if(k!==0)throw Error(rB[k]);f.header&&(k=this.Mh)&&k.state&&k.state.wrap===2&&(k.state.bp=f.header);if(f.Nu){var V;typeof f.Nu==="string"?V=MeF(f.Nu):VjE.call(f.Nu)==="[object ArrayBuffer]"?V=new Uint8Array(f.Nu):V=f.Nu;f=this.Mh;
u=V;h=u.length;if(f&&f.state)if(V=f.state,k=V.wrap,k===2||k===1&&V.status!==42||V.KE)k=-2;else{k===1&&(f.Ep=cT(f.Ep,u,h,0));V.wrap=0;h>=V.cI&&(k===0&&(HT(V.head),V.FA=0,V.b1=0,V.Xx=0),G=new I8.U7(V.cI),I8.BK(G,u,h-V.cI,V.cI,0),u=G,h=V.cI);G=f.uh;t=f.Fl;Z=f.input;f.uh=h;f.Fl=0;f.input=u;for(gB(V);V.KE>=3;){u=V.FA;h=V.KE-2;do V.HO=(V.HO<<V.kP^V.window[u+3-1])&V.Zs,V.Ol[u&V.by]=V.head[V.HO],V.head[V.HO]=u,u++;while(--h);V.FA=u;V.KE=2;gB(V)}V.FA+=V.KE;V.b1=V.FA;V.Xx=V.KE;V.KE=0;V.yB=V.Kh=2;V.eb=0;f.Fl=
t;f.input=Z;f.uh=G;V.wrap=k;k=0}else k=-2;if(k!==0)throw Error(rB[k]);this.Boy=!0}};
  vbQ = function(f){var k=k||{};k.j_=!0;k=new GS(k);k.push(f,!0);if(k.err)throw k.msg||rB[k.err];return k.result};
  var Kdy = 0;
  Ff = function(){return g.qd("ytPubsub2Pubsub2Instance")};
  Az = function(f,k){var G=Ff();G&&G.publish.call(G,f.toString(),f,k)};
  ic = function(f,k,G={sampleRate:.1}){Math.random()<Math.min(.02,G.sampleRate/100)&&Az("meta_logging_csi_event",{timerName:f,timelineData:k})};
  var FdH = undefined;
  var IrD = undefined;
  zq = function(f,k,G,t){var Z={startTime:(0,g.S)(),ticks:{},infos:{}};try{let h=QWX(k);if(h==null||!(h>IrD||h<FdH)){var u=vbQ(AmE(k));let W=(0,g.S)();Z.ticks.gelc=W;Kdy++;g.e3("gel_compression_csi_killswitch")||!g.e3("log_gel_compression_latency")&&!g.e3("log_gel_compression_latency_lr")||ic("gel_compression",Z,{sampleRate:.1});G.headers||(G.headers={});G.headers["Content-Encoding"]="gzip";G.postBody=u;G.postParams=void 0}t(f,G)}catch(h){NZ(h),t(f,G)}};
  F1 = function(f,k){return f.W?f.W:f.W=new Promise(async G=>{var t=window.AbortController?new window.AbortController:void 0,Z=t?.signal,u=!1;try{t&&(f.B=f.sz.Sw(()=>{t.abort()},k||2E4)),await fetch("/generate_204",{method:"HEAD",
signal:Z}),u=!0}catch{u=!1}finally{f.W=void 0,f.B&&(f.sz.Cl(f.B),f.B=0),u!==f.isOnline&&(f.isOnline=u,f.isOnline?f.dispatchEvent("networkstatus-online"):f.dispatchEvent("networkstatus-offline")),G(u)}})};
  um = function(f){this.src=f;this.listeners={};this.B=0};
  g.n = um.prototype;
  oa = function(f,k,G,t){for(let Z=0;Z<f.length;++Z){let u=f[Z];if(!u.removed&&u.listener==k&&u.capture==!!G&&u.handler==t)return Z}return-1};
  var yCL = 0;
  qVH = function(f,k,G,t,Z){this.listener=f;this.proxy=null;this.src=k;this.type=G;this.capture=!!t;this.handler=Z;this.key=++yCL;this.removed=this.MS=!1};
  g.n.add = function(f,k,G,t,Z){var u=f.toString();f=this.listeners[u];f||(f=this.listeners[u]=[],this.B++);var h=oa(f,k,t,Z);h>-1?(k=f[h],G||(k.MS=!1)):(k=new qVH(k,this.src,u,!!t,Z),k.MS=G,f.push(k));return k};
  ZD = function(f){f.removed=!0;f.listener=null;f.proxy=null;f.src=null;f.handler=null};
  g.n.remove = function(f,k,G,t){f=f.toString();if(!(f in this.listeners))return!1;var Z=this.listeners[f];k=oa(Z,k,G,t);return k>-1?(ZD(Z[k]),g.op(Z,k),Z.length==0&&(delete this.listeners[f],this.B--),!0):!1};
  g.n.removeAll = function(f){f=f&&f.toString();var k=0;for(let G in this.listeners)if(!f||G==f){let t=this.listeners[G];for(let Z=0;Z<t.length;Z++)++k,ZD(t[Z]);delete this.listeners[G];this.B--}return k};
  g.n.I4 = function(f,k,G,t){f=this.listeners[f.toString()];var Z=-1;f&&(Z=oa(f,k,G,t));return Z>-1?f[Z]:null};
  g.En = function(f,k,G){for(let t in f)if(k.call(G,f[t],t,f))return!0;return!1};
  g.n.hasListener = function(f,k){var G=f!==void 0,t=G?f.toString():"",Z=k!==void 0;return g.En(this.listeners,function(u){for(let h=0;h<u.length;++h)if(!(G&&u[h].type!=t||Z&&u[h].capture!=k))return!0;return!1})};
  g.yN = function(){g.I0.call(this);this.Xo=new um(this);this.He=this;this.Nr=null};
  g.n = g.yN.prototype;
  var eD = undefined;
  v7 = function(f){if(typeof f==="function")return f;f[eD]||(f[eD]=function(k){return f.handleEvent(k)});
return f[eD]};
  var jD = undefined;
  B7 = function(f){f=f[jD];return f instanceof um?f:null};
  g.kp = function(f,k){this.type=f;this.currentTarget=this.target=k;this.defaultPrevented=this.K=!1};
  Gn = function(f,k){g.kp.call(this,f?f.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.key="";this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.B=null;f&&this.init(f,k)};
  var U8 = {};
  QGH = function(f){return f in U8?U8[f]:U8[f]="on"+f};
  var IgO = 0;
  g.hV = function(f,k){var G=k.type;G in f.listeners&&g.We(f.listeners[G],k)&&(ZD(k),f.listeners[G].length==0&&(delete f.listeners[G],f.B--))};
  var el6 = undefined;
  tV = function(f){return!(!f||!f[el6])};
  N7 = function(f){if(typeof f!=="number"&&f&&!f.removed){var k=f.src;if(tV(k))g.hV(k.Xo,f);else{var G=f.type,t=f.proxy;k.removeEventListener?k.removeEventListener(G,t,f.capture):k.detachEvent?k.detachEvent(QGH(G),t):k.addListener&&k.removeListener&&k.removeListener(t);IgO--;(G=B7(k))?(g.hV(G,f),G.B==0&&(G.src=null,k[jD]=null)):ZD(f)}}};
  FCd = function(f,k){if(f.removed)f=!0;else{k=new Gn(k,this);let G=f.listener,t=f.handler||f.src;f.MS&&N7(f);f=G.call(t,k)}return f};
  PRD = function(){function f(G){return k.call(f.src,f.listener,G)}
var k=FCd;return f};
  O5E = function(f,k,G,t,Z,u){if(!k)throw Error("Invalid event type");var h=g.AQ(Z)?!!Z.capture:!!Z,W=B7(f);W||(f[jD]=W=new um(f));G=W.add(k,G,t,h,u);if(G.proxy)return G;t=PRD();G.proxy=t;t.src=f;t.listener=G;if(f.addEventListener)Z===void 0&&(Z=!1),f.addEventListener(k.toString(),t,Z);else if(f.attachEvent)f.attachEvent(QGH(k.toString()),t);else if(f.addListener&&f.removeListener)f.addListener(t);else throw Error("addEventListener and attachEvent are unavailable.");IgO++;return G};
  DD = function(f,k,G,t,Z){if(Array.isArray(k)){for(let u=0;u<k.length;u++)DD(f,k[u],G,t,Z);return null}G=v7(G);return tV(f)?f.Fw(k,G,g.AQ(t)?!!t.capture:!!t,Z):O5E(f,k,G,!0,t,Z)};
  g.VN = function(f,k,G,t,Z){if(t&&t.once)return DD(f,k,G,t,Z);if(Array.isArray(k)){for(let u=0;u<k.length;u++)g.VN(f,k[u],G,t,Z);return null}G=v7(G);return tV(f)?f.listen(k,G,g.AQ(t)?!!t.capture:!!t,Z):O5E(f,k,G,!1,t,Z)};
  g.n.addEventListener = function(f,k,G,t){g.VN(this,f,k,G,t)};
  ACF = function(f,k,G,t,Z){if(Array.isArray(k))for(let u=0;u<k.length;u++)ACF(f,k[u],G,t,Z);else t=g.AQ(t)?!!t.capture:!!t,G=v7(G),tV(f)?f.jd(k,G,t,Z):f&&(f=B7(f))&&(k=f.I4(k,G,t,Z))&&N7(k)};
  g.n.removeEventListener = function(f,k,G,t){ACF(this,f,k,G,t)};
  q7 = function(f,k,G,t){k=f.Xo.listeners[String(k)];if(!k)return!0;k=k.concat();var Z=!0;for(let u=0;u<k.length;++u){let h=k[u];if(h&&!h.removed&&h.capture==G){let W=h.listener,D=h.handler||h.src;h.MS&&g.hV(f.Xo,h);Z=W.call(D,t)!==!1&&Z}}return Z&&!t.defaultPrevented};
  g.n.dispatchEvent = function(f){var k=this.Nr;if(k){var G=[];for(var t=1;k;k=k.Nr)G.push(k),++t}k=this.He;t=f.type||f;if(typeof f==="string")f=new g.kp(f,k);else if(f instanceof g.kp)f.target=f.target||k;else{var Z=f;f=new g.kp(t,k);g.pi(f,Z)}Z=!0;var u;if(G)for(u=G.length-1;!f.K&&u>=0;u--){var h=f.currentTarget=G[u];Z=q7(h,t,!0,f)&&Z}f.K||(h=f.currentTarget=k,Z=q7(h,t,!0,f)&&Z,f.K||(Z=q7(h,t,!1,f)&&Z));if(G)for(u=0;!f.K&&u<G.length;u++)h=f.currentTarget=G[u],Z=q7(h,t,!1,f)&&Z;return Z};
  g.n.GB = function(){g.yN.bY.GB.call(this);this.Xo&&this.Xo.removeAll(void 0);this.Nr=null};
  g.n.listen = function(f,k,G,t){return this.Xo.add(String(f),k,!1,G,t)};
  g.n.Fw = function(f,k,G,t){return this.Xo.add(String(f),k,!0,G,t)};
  g.n.jd = function(f,k,G,t){this.Xo.remove(String(f),k,G,t)};
  g.n.I4 = function(f,k,G,t){return this.Xo.I4(String(f),k,G,t)};
  g.n.hasListener = function(f,k){return this.Xo.hasListener(f!==void 0?String(f):void 0,k)};
  var Ii = class extends g.yN{constructor(f){super();this.S=this.B=0;this.sz=f??{Sw:(k,G)=>setTimeout(k,G),
Cl:k=>{clearTimeout(k)}};
this.isOnline=window.navigator?.onLine??!0;this.K=async()=>{await F1(this)};
window.addEventListener("offline",this.K);window.addEventListener("online",this.K);this.S||this.lc()}dispose(){window.removeEventListener("offline",this.K);window.removeEventListener("online",this.K);this.sz.Cl(this.S);delete Ii.instance}xo(){return this.isOnline}lc(){this.S=this.sz.Sw(async()=>{this.isOnline?window.navigator?.onLine||await F1(this):await F1(this);this.lc()},3E4)}};
  oHH = function(){var f=g.QL;Ii.instance||(Ii.instance=new Ii(f));return Ii.instance};
  bc = undefined;
  am = function(){bc||(bc=new w_("yt.offline"));return bc};
  var Mb = class extends g.yN{constructor(){super();this.K=!1;this.B=oHH();this.B.listen("networkstatus-online",()=>{if(this.K&&g.e3("offline_error_handling")){var f=am().get("errors",!0);if(f){for(let k in f)if(f[k]){let G=new g.U3(k,"sent via offline_errors");G.name=f[k].name;G.stack=f[k].stack;G.level=f[k].level;g.BY(G)}am().set("errors",{},2592E3,!0)}}})}xo(){return this.B.xo()}YZ(f){this.B.isOnline=f}Xv(){var f=window.navigator.onLine;
return f===void 0?!0:f}JH(){this.K=!0}listen(f,k){return this.B.listen(f,k)}bk(f){return F1(this.B,f)}};
  fDf = function(){if(!Mb.instance){let f=g.qd("yt.networkStatusManager.instance")||new Mb;g.eF("yt.networkStatusManager.instance",f);Mb.instance=f}return Mb.instance};
  knc = function(f,k){f.rateLimit?f.B?(g.QL.Cl(f.S),f.S=g.QL.Sw(()=>{f.W!==k&&(f.dispatchEvent(k),f.W=k,f.B=(0,g.S)())},f.rateLimit-((0,g.S)()-f.B))):(f.dispatchEvent(k),f.W=k,f.B=(0,g.S)()):f.dispatchEvent(k)};
  var r_ = class{constructor(){this.B=new Map;this.K=!1}requestComplete(f,k){k&&(this.K=!0);f=this.removeParams(f);this.B.get(f)||this.B.set(f,k)}isEndpointCFR(f){f=this.removeParams(f);return(f=this.B.get(f))?!1:f===!1&&this.K?!0:null}removeParams(f){return f.split("?")[0]}};
  Jma = function(){if(!r_.instance){let f=g.qd("yt.networkRequestMonitor.instance")||new r_;g.eF("yt.networkRequestMonitor.instance",f);r_.instance=f}return r_.instance};
  g.q3 = class extends g.yN{constructor(f={}){super();this.B=this.S=0;this.K=fDf();var k=g.qd("yt.networkStatusManager.instance.listen").bind(this.K);k&&(f.rateLimit?(this.rateLimit=f.rateLimit,k("networkstatus-online",()=>{knc(this,"publicytnetworkstatus-online")}),k("networkstatus-offline",()=>{knc(this,"publicytnetworkstatus-offline")})):(k("networkstatus-online",()=>{this.dispatchEvent("publicytnetworkstatus-online")}),k("networkstatus-offline",()=>{this.dispatchEvent("publicytnetworkstatus-offline")})))}xo(){var f=
g.qd("yt.networkStatusManager.instance.isNetworkAvailable");
return f?f.bind(this.K)():!0}YZ(f){var k=g.qd("yt.networkStatusManager.instance.networkStatusHint").bind(this.K);k&&k(f)}async bk(f){var k=g.qd("yt.networkStatusManager.instance.sendNetworkCheckRequest").bind(this.K);return g.e3("skip_network_check_if_cfr")&&Jma().isEndpointCFR("generate_204")?new Promise(G=>{this.YZ(window.navigator?.onLine||!0);G(this.xo())}):k?k(f):!0}};
  Ol = undefined;
  nd = undefined;
  l5 = function(f,k){f.B.objectStoreNames.contains(k)&&f.B.deleteObjectStore(k)};
  nJQ = function(){if(nd)return nd();nd=om("LogsDatabaseV2",{b4:{LogsRequestsStore:{Xm:2}},shared:!1,upgrade(f,k,G){k(2)&&Xy(f,"LogsRequestsStore",{keyPath:"id",autoIncrement:!0});k(3);k(5)&&(G=G.objectStore("LogsRequestsStore"),G.B.indexNames.contains("newRequest")&&G.B.deleteIndex("newRequest"),TV(G,"newRequestV2",["status","interface","timestamp"]));k(7)&&l5(f,"sapisid");k(9)&&l5(f,"SWHealthLog")},version:9});return nd()};
  Ld = function(f){return g.Y9(nJQ(),f)};
  rmX = async function(f){f=await Ld(f);var k=(0,g.S)()-2592E6;await g.x9(f,["LogsRequestsStore"],{mode:"readwrite",C7:!0},G=>g.RB(G.objectStore("LogsRequestsStore"),{},t=>{if(t.getValue().timestamp<=k)return t.delete().then(()=>g.cq(t))}))};
  ara = async function(f,k){return(await Ld(k)).delete("LogsRequestsStore",f)};
  Lda = function(f){g.e3("nwl_csi_killswitch")||ic("networkless_performance",f,{sampleRate:1})};
  sWD = async function(f,k){var G={startTime:(0,g.S)(),infos:{transactionType:"YT_IDB_TRANSACTION_TYPE_READ"},ticks:{}};k=await Ld(k);var t=g.DR("INNERTUBE_CONTEXT_CLIENT_NAME",0),Z=[f,t,0];t=[f,t,(0,g.S)()];var u=IDBKeyRange.bound(Z,t),h="prev";g.e3("use_fifo_for_networkless")&&(h="next");var W=void 0;Z=f==="NEW"?"readwrite":"readonly";g.e3("use_readonly_for_get_most_recent_by_status_killswitch")&&(Z="readwrite");await g.x9(k,["LogsRequestsStore"],{mode:Z,C7:!0},D=>g.pa(D.objectStore("LogsRequestsStore").index("newRequestV2"),
{query:u,direction:h},V=>{V.getValue()&&(W=V.getValue(),f==="NEW"&&(W.status="QUEUED",V.update(W)))}));
G.ticks.tc=(0,g.S)();Lda(G);return W};
  bv6 = async function(f,k){return g.x9(await Ld(k),["LogsRequestsStore"],{mode:"readwrite",C7:!0},G=>{var t=G.objectStore("LogsRequestsStore");return t.get(f).then(Z=>{if(Z)return Z.status="QUEUED",t.put(Z).then(()=>Z)})})};
  wbu = async function(f,k,G=!0,t){return g.x9(await Ld(k),["LogsRequestsStore"],{mode:"readwrite",C7:!0},Z=>{var u=Z.objectStore("LogsRequestsStore");return u.get(f).then(h=>h?(h.status="NEW",G&&(h.sendCount+=1),t!==void 0&&(h.options.compress=t),u.put(h).then(()=>h)):g.b5.resolve(void 0))})};
  dhH = async function(f,k){var G={startTime:(0,g.S)(),infos:{transactionType:"YT_IDB_TRANSACTION_TYPE_WRITE"},ticks:{}};k=await Ld(k);f={...f,options:JSON.parse(JSON.stringify(f.options)),interface:g.DR("INNERTUBE_CONTEXT_CLIENT_NAME",0)};f=await k.put("LogsRequestsStore",f);G.ticks.tc=(0,g.S)();Lda(G);return f};
  var pbX = 0;
  var sM = {};
  RIX = function(f,k,G={}){var t=new Image,Z=`${pbX++}`;sM[Z]=t;t.onload=t.onerror=()=>{k&&sM[Z]&&k();delete sM[Z]};
G.scrubReferrer&&(t.referrerPolicy="no-referrer");t.src=f};
  var T9f = class{constructor({url:f,PuI:k}){this.K=f;this.S=k;this.W=(new Date).getTime()-17040672E5;this.B={};for(var G=/[?&]([^&=]+)=([^&]*)/g;k=G.exec(f);)this.B[k[1]]=k[2]}};
  md = function(f,k){return k?"&"+f+"="+encodeURIComponent(k):""};
  PrQ = function(f){f=f.S;if(!f)return"";var k=md("uap",f.platform)+md("uapv",f.platformVersion)+md("uafv",f.uaFullVersion)+md("uaa",f.architecture)+md("uam",f.model)+md("uab",f.bitness);f.fullVersionList&&(k+="&uafvl="+encodeURIComponent(f.fullVersionList.map(G=>encodeURIComponent(G.brand)+";"+encodeURIComponent(G.version)).join("|")));
f.wow64!=null&&(k+="&uaw="+Number(f.wow64));return k.slice(1)};
  E0 = function(f,...k){k=k.filter(Boolean).join("&");if(!k)return f;var G=f.match(/[?&]adurl=/);return G?f.slice(0,G.index+1)+k+"&"+f.slice(G.index+1):f+(f.indexOf("?")<0?"?":"&")+k};
  var pN = /#|$/;
  cy = function(f,k,G,t){for(var Z=G.length;(k=f.indexOf(G,k))>=0&&k<t;){var u=f.charCodeAt(k-1);if(u==38||u==63)if(u=f.charCodeAt(k+Z),!u||u==61||u==38||u==35)return k;k+=Z+1}return-1};
  gG = function(f,k){var G=f.search(pN),t=cy(f,0,k,G);if(t<0)return null;var Z=f.indexOf("&",t);if(Z<0||Z>G)Z=G;t+=k.length+1;return WI(f.slice(t,Z!==-1?Z:0))};
  S0f = function(f,k=""){try{if(window.navigator&&window.navigator.sendBeacon&&window.navigator.sendBeacon(f,k))return!0}catch(G){}return!1};
  g.DJ = function(f){var k=g.D6();return k?k.toLowerCase().indexOf(f)>=0:!1};
  g.vf = function(){return g.DJ("cobalt")};
  g.d_ = function(f,k,G,t,Z="",u=!1,h=!1){if(f)if(!G||g.vf()||g.e3("web_ping_disable_scrub_referrer"))if(Z)wv(f,k,"POST",Z,t);else if(g.DR("USE_NET_AJAX_FOR_PING_TRANSPORT",!1)||t||h)wv(f,k,"GET","",t,void 0,u,h);else{b:{try{c:{var W=new T9f({url:f});if(W.B.dsh==="1")var D=null;else{var V=W.B.ae;if(V==="1"){let e=W.B.adurl;if(e)try{D={version:3,vj:decodeURIComponent(e),X7:E0(W.K,"act=1","ri=1",PrQ(W))};break c}catch(q){}}D=V==="2"?{version:4,vj:E0(W.K,"dct=1","suid="+W.W,"ri=1"),X7:E0(W.K,"act=1","ri=1",
"suid="+W.W)}:null}}if(D){let e=be(f);var U=!(!e||!e.endsWith("/aclk")||gG(f,"ri")!=="1");break b}}catch(e){}U=!1}U?S0f(f)?(k&&k(),G=!0):G=!1:G=!1;G||RIX(f,k)}else NZ(new g.U3("Legacy referrer-scrubbed ping detected")),f&&RIX(f,void 0,{scrubReferrer:!0})};
  ZbL = function(f,k,G){k=g.e3("web_fp_via_jspb")?Object.assign({},k):k;g.e3("use_request_time_ms_header")?k.headers&&i$(f)&&(k.headers["X-Goog-Request-Time"]=JSON.stringify(Math.round((0,g.S)()))):k.postParams?.requestTimeMs&&(k.postParams.requestTimeMs=Math.round((0,g.S)()));G&&Object.keys(k).length===0?g.d_(f):k.compress?k.postBody?(typeof k.postBody!=="string"&&(k.postBody=JSON.stringify(k.postBody)),zq(f,k.postBody,k,g.aE)):zq(f,JSON.stringify(k.postParams),k,rv):g.aE(f,k)};
  Y0F = function(f){if(g.e3("offline_error_handling")){var k=am().get("errors",!0)||{};k[f.message]={name:f.name,stack:f.stack};f.level&&(k[f.message].level=f.level);am().set("errors",k,2592E3,!0)}};
  g.$S = class{constructor(){this.promise=new Promise((f,k)=>{this.resolve=f;this.reject=k})}};
  $GO = async function(f,k){var G=[];k=await g.Y9(JR,k);await g.x9(k,["databases"],{C7:!0,mode:"readonly"},t=>{G.length=0;return g.RB(t.objectStore("databases"),{},Z=>{f(Z.getValue())&&G.push(Z.getValue());return g.cq(Z)})});
return G};
  inf = function(f,k){return $GO(G=>G.publicName===f&&G.userIdentifier!==void 0,k)};
  s0c = function(f,k,G){f=f.map(async t=>{await g0(t.actualName,k);await fd(t.actualName,G)});
return Promise.all(f).then(()=>{})};
  bny = async function(f){var k={},G=await g.hz();G&&(Ca(f),f=await inf(f,G),await s0c(f,k,G))};
  M_f = async function(){await bny("LogsDatabaseV2")};
  xc = function(f,k){g.e3("use_event_time_ms_header")&&i$(f)&&(k.headers||(k.headers={}),k.headers["X-Goog-Event-Time"]=JSON.stringify(Math.round((0,g.S)())));return k};
  Cd = function(f){return!!f.PC||f.Dz};
  zId = function(f){Cd(f)&&!f.iR&&(f.B=!0,f.zk&&Math.random()<=f.m$&&f.CZ.NC(f.PC),f.FY(),f.FR.xo()&&f.W(),f.FR.listen(f.Jb,f.W.bind(f)),f.FR.listen(f.kU,f.S.bind(f)))};
  m2 = function(f,k){f.EZ&&!f.FR.xo()?f.EZ(k):f.handleError(k)};
  Cd6 = function(f){return(f=f?.error?.code)&&f>=400&&f<=599?!1:!0};
  EJX = function(f){f=f?.error?.code;return!(f!==400&&f!==415)};
  mhf = function(f,k){if(!Cd(f))throw Error("IndexedDB is not supported: updateRequestHandlers");var G=k.options.onError?k.options.onError:()=>{};
k.options.onError=async(Z,u)=>{var h=Cd6(u),W=EJX(u);W&&f.rH&&f.rH("web_enable_error_204")&&f.handleError(Error("Request failed due to compression"),k.url,u);if(f.rH&&f.rH("nwl_consider_error_code")&&h||f.rH&&!f.rH("nwl_consider_error_code")&&f.potentialEsfErrorCounter<=f.BL)if(f.FR.bk&&await f.FR.bk(),!f.FR.xo()){G(Z,u);f.rH&&f.rH("nwl_consider_error_code")&&k?.id!==void 0&&await f.CZ.wP(k.id,f.PC,!1);return}f.rH&&f.rH("nwl_consider_error_code")&&!h&&f.potentialEsfErrorCounter>f.BL||(f.potentialEsfErrorCounter++,
k?.id!==void 0&&(k.sendCount<f.s8?(await f.CZ.wP(k.id,f.PC,!0,W?!1:void 0),f.sz.Sw(()=>{f.FR.xo()&&f.W()},f.Gn)):await f.CZ.Mf(k.id,f.PC)),G(Z,u))};
var t=k.options.onSuccess?k.options.onSuccess:()=>{};
k.options.onSuccess=async(Z,u)=>{k?.id!==void 0&&await f.CZ.Mf(k.id,f.PC);f.FR.YZ&&f.rH&&f.rH("vss_network_hint")&&f.FR.YZ(!0);t(Z,u)};
return k};
  var wII = class{constructor(f){this.Dz=this.B=!1;this.potentialEsfErrorCounter=this.K=0;this.handleError=()=>{};
this.Em=()=>{};
this.now=Date.now;this.iR=!1;this.OQ={nLt:k=>{this.PC=k},
IBE:()=>{this.W()},
uG:()=>{this.S()},
B8:async k=>{await this.B8(k)},
YF:(k,G)=>this.YF(k,G),
FY:()=>{this.FY()}};
this.O8=f.O8??100;this.s8=f.s8??1;this.RP=f.RP??2592E6;this.O2=f.O2??12E4;this.Gn=f.Gn??5E3;this.PC=f.PC??void 0;this.zk=!!f.zk;this.m$=f.m$??.1;this.BL=f.BL??10;f.handleError&&(this.handleError=f.handleError);f.Em&&(this.Em=f.Em);f.iR&&(this.iR=f.iR);f.Dz&&(this.Dz=f.Dz);this.rH=f.rH;this.sz=f.sz;this.CZ=f.CZ;this.FR=f.FR;this.Ks=f.Ks;this.Jb=f.Jb;this.kU=f.kU;Cd(this)&&(!this.rH||this.rH("networkless_logging"))&&zId(this)}writeThenSend(f,k={}){if(Cd(this)&&this.B){let G={url:f,options:k,timestamp:this.now(),
status:"NEW",sendCount:0};this.CZ.set(G,this.PC).then(t=>{G.id=t;this.FR.xo()&&this.B8(G)}).catch(t=>{this.B8(G);
m2(this,t)})}else this.Ks(f,k)}sendThenWrite(f,k={},G){if(Cd(this)&&this.B){let t={url:f,
options:k,timestamp:this.now(),status:"NEW",sendCount:0};this.rH&&this.rH("nwl_skip_retry")&&(t.skipRetry=G);if(this.FR.xo()||this.rH&&this.rH("nwl_aggressive_send_then_write")&&!t.skipRetry){if(!t.skipRetry){let Z=k.onError?k.onError:()=>{};
k.onError=async(u,h)=>{await this.CZ.set(t,this.PC).catch(W=>{m2(this,W)});
Z(u,h)}}this.Ks(f,k,t.skipRetry)}else this.CZ.set(t,this.PC).catch(Z=>{this.Ks(f,k,t.skipRetry);
m2(this,Z)})}else G=this.rH&&this.rH("nwl_skip_retry")&&G,this.Ks(f,k,G)}sendAndWrite(f,k={}){if(Cd(this)&&this.B){let G={url:f,
options:k,timestamp:this.now(),status:"NEW",sendCount:0},t=!1,Z=k.onSuccess?k.onSuccess:()=>{};
G.options.onSuccess=(u,h)=>{G.id!==void 0?this.CZ.Mf(G.id,this.PC):t=!0;this.FR.YZ&&this.rH&&this.rH("vss_network_hint")&&this.FR.YZ(!0);Z(u,h)};
this.Ks(G.url,G.options,void 0,!0);this.CZ.set(G,this.PC).then(u=>{G.id=u;t&&this.CZ.Mf(G.id,this.PC)}).catch(u=>{m2(this,u)})}else this.Ks(f,k,void 0,!0)}W(){if(!Cd(this))throw Error("IndexedDB is not supported: throttleSend");
this.K||(this.K=this.sz.Sw(async()=>{var f=await this.CZ.M3("NEW",this.PC);f?(await this.B8(f),this.K&&(this.K=0,this.W())):this.S()},this.O8))}S(){this.sz.Cl(this.K);
this.K=0}async B8(f){if(!Cd(this))throw Error("IndexedDB is not supported: immediateSend");f.id!==void 0&&(await this.CZ.yK(f.id,this.PC)||this.Em(Error("The request cannot be found in the database.")));this.YF(f,this.RP)?(f.skipRetry||(f=mhf(this,f)),f&&(f.skipRetry&&f.id!==void 0&&await this.CZ.Mf(f.id,this.PC),this.Ks(f.url,f.options,!!f.skipRetry))):(this.Em(Error("Networkless Logging: Stored logs request expired age limit")),f.id!==void 0&&await this.CZ.Mf(f.id,this.PC))}YF(f,k){f=f.timestamp;
return this.now()-f>=k?!1:!0}FY(){if(!Cd(this))throw Error("IndexedDB is not supported: retryQueuedRequests");this.CZ.M3("QUEUED",this.PC).then(f=>{f&&!this.YF(f,this.O2)?this.sz.Sw(async()=>{f.id!==void 0&&await this.CZ.wP(f.id,this.PC);this.FY()}):this.FR.xo()&&this.W()})}};
  var Gnf = class extends wII{constructor(){Ol||(Ol=new g.q3({ilt:!0,vG6:!0}));super({CZ:{NC:rmX,Mf:ara,M3:sWD,yK:bv6,wP:wbu,set:dhH},FR:Ol,handleError:(f,k,G)=>{var t=G?.error?.code;t===400||t===415?(f=new g.U3(f.message,k,G?.error?.code),NZ(f,void 0,void 0,void 0,!0)):g.BY(f)},
Em:NZ,Ks:ZbL,now:g.S,EZ:Y0F,sz:g.O3(),Jb:"publicytnetworkstatus-online",kU:"publicytnetworkstatus-offline",zk:!0,m$:.1,BL:yZ("potential_esf_error_limit",10),rH:g.e3,iR:!(NC()&&g.sb(document.location.toString())!=="www.youtube-nocookie.com")});this.Z=new g.$S;g.e3("networkless_immediately_drop_all_requests")&&M_f();w0D("LogsDatabaseV2")}writeThenSend(f,k){k||(k={});k=xc(f,k);NC()||(this.B=!1);super.writeThenSend(f,k)}sendThenWrite(f,k,G){k||(k={});k=xc(f,k);NC()||(this.B=!1);super.sendThenWrite(f,
k,G)}sendAndWrite(f,k){k||(k={});k=xc(f,k);NC()||(this.B=!1);super.sendAndWrite(f,k)}awaitInitialization(){return this.Z.promise}};
  var HvO = undefined;
  xhD = function(f){return g.Y9(HvO(),f)};
  XbL = async function(f){f=await xhD(f);var k=(0,g.S)()-2592E6;await g.x9(f,["SWHealthLog"],{mode:"readwrite",C7:!0},G=>g.RB(G.objectStore("SWHealthLog"),{},t=>{if(t.getValue().timestamp<=k)return t.delete().then(()=>g.cq(t))}))};
  lry = async function(f){await (await xhD(f)).clear("SWHealthLog")};
  tDX = async function(f){if(!f.PC)throw g.s3("clearSWHealthLogsDb");lry(f.PC).catch(k=>{f.handleError(k)})};
  HJ = function(){var f=g.qd("yt.networklessRequestController.instance");f||(f=new Gnf,g.eF("yt.networklessRequestController.instance",f),g.e3("networkless_logging")&&g.hz().then(k=>{f.PC=k;zId(f);f.Z.resolve();f.zk&&Math.random()<=f.m$&&f.PC&&XbL(f.PC);g.e3("networkless_immediately_drop_sw_health_store")&&tDX(f)}));
return f};
  var uKQ = {};
  g.Xf = function(f,k,G,t){!g.DR("VISITOR_DATA")&&k!=="visitor_id"&&Math.random()<.01&&NZ(new g.U3("Missing VISITOR_DATA when sending innertube request.",k,G,t));if(!f.isReady())throw f=new g.U3("innertube xhrclient not ready",k,G,t),g.BY(f),f;var Z={headers:t.headers||{},method:"POST",postParams:G,postBody:t.postBody,postBodyFormat:t.postBodyFormat||"JSON",onTimeout:()=>{t.onTimeout()},
onFetchTimeout:t.onTimeout,onSuccess:(V,U)=>{if(t.onSuccess)t.onSuccess(U)},
onFetchSuccess:V=>{if(t.onSuccess)t.onSuccess(V)},
onProgress:V=>{if(t.onProgress)t.onProgress(V)},
onError:(V,U)=>{if(t.onError)t.onError(U)},
onFetchError:V=>{if(t.onError)t.onError(V)},
timeout:t.timeout,withCredentials:!0,compress:t.compress};Z.headers["Content-Type"]||(Z.headers["Content-Type"]="application/json");G="";var u=f.config_.BW;u&&(G=u);u=f.config_.K$||!1;var h=N9D(u,G,t);Object.assign(Z.headers,h);Z.headers.Authorization&&!G&&u&&(Z.headers["x-origin"]=window.location.origin);var W=Kt(`${G}${`/youtubei/${f.config_.innertubeApiVersion}/${k}`}`,{alt:"json"}),D=(V=!1)=>{try{if(V&&t.retry&&!t.networklessOptions.bypassNetworkless)Z.method="POST",t.networklessOptions.writeThenSend?
HJ().writeThenSend(W,Z):HJ().sendAndWrite(W,Z);else if(t.compress)if(Z.postBody){let U=Z.postBody;typeof U!=="string"&&(U=JSON.stringify(Z.postBody));zq(W,U,Z,g.aE)}else zq(W,JSON.stringify(Z.postParams),Z,rv);else rv(W,Z)}catch(U){if(U.name==="InvalidAccessError")NZ(Error("An extension is blocking network request."));else throw U;}};
g.qd("ytNetworklessLoggingInitializationOptions")&&uKQ.isNwlInitialized?C9a().then(V=>{D(V)}):D(!1)};
  var SN = !0;
  f1u = function(f,k,G,t,Z={},u,h){if(f.size===0)G();else{var W=Math.round((0,g.S)()),D=f.size,V=D2H(h);for(let [U,e]of f){f=U;h=e;let q=g.Rp({context:g.ew(k.config_||g.UM())});if(!g.FL(h)&&!g.e3("throw_err_when_logevent_malformed_killswitch")){t();break}q.events=h;(h=lE[f])&&VHa(q,f,h);delete lE[f];let O=f==="visitorOnlyApprovedKey";vSE(q,W,O);BhL(Z);let F=r=>{g.e3("start_client_gcf")&&g.QL.Sw(async()=>{await juu(r)});
D--;D||G()},m=0,a=()=>{m++;
if(Z.bypassNetworkless&&m===1)try{g.Xf(k,V,q,Ro({writeThenSend:!0},O,F,a,u)),SN=!1}catch(r){g.BY(r),t()}D--;D||G()};
try{g.Xf(k,V,q,Ro(Z,O,F,a,u)),SN=!1}catch(r){g.BY(r),t()}}}};
  agy = function(f){f.A||(f.A=!0,g.Cb(f.Bu,f))};
  var Xja = mC;
  MQf = function(f,k){f.Z=!0;g.Cb(function(){f.Z&&Xja.call(null,k)})};
  rc = function(f,k){if(Error.captureStackTrace)Error.captureStackTrace(this,rc);else{let G=Error().stack;G&&(this.stack=G)}f&&(this.message=String(f));k!==void 0&&(this.cause=k)};
  nb = function(f){rc.call(this,f)};
  g.$Z = function(){};
  CRQ = function(){this.next=this.context=this.K=this.W=this.B=null;this.S=!1};
  var EkE = {};
  Kb = function(f,k,G){var t=EkE.get();t.W=f;t.K=k;t.context=G;return t};
  E8 = function(f,k){f.K||f.B!=2&&f.B!=3||agy(f);f.S?f.S.next=k:f.K=k;f.S=k};
  dp6 = function(f,k,G,t){E8(f,Kb(k||g.$Z,G||null,t))};
  H5a = function(f,k,G,t,Z){function u(D){W||(W=!0,t.call(Z,D))}
function h(D){W||(W=!0,G.call(Z,D))}
var W=!1;try{k.call(f,h,u)}catch(D){u(D)}};
  mp6 = function(f,k,G,t){if(f instanceof g.AV)return dp6(f,k,G,t),!0;if(f)try{var Z=!!f.$goog_Thenable}catch(u){Z=!1}else Z=!1;if(Z)return f.then(k,G,t),!0;if(g.AQ(f))try{let u=f.then;if(typeof u==="function")return H5a(f,u,k,G,t),!0}catch(u){return G.call(t,u),!0}return!1};
  FK = function(f,k,G){f.B==0&&(f===G&&(k=3,G=new TypeError("Promise cannot resolve to itself")),f.B=1,mp6(G,f.P7,f.XQ,f)||(f.V=G,f.B=k,f.W=null,agy(f),k!=3||G instanceof nb||MQf(f,G)))};
  g.AV = function(f,k){this.B=0;this.V=void 0;this.S=this.K=this.W=null;this.Z=this.A=!1;if(f!=g.$Z)try{let G=this;f.call(k,function(t){FK(G,2,t)},function(t){FK(G,3,t)})}catch(G){FK(this,3,G)}};
  g.n = g.AV.prototype;
  var O8 = undefined;
  g.n.finally = function(f){f=O8(f);return new g.AV((k,G)=>{dp6(this,t=>{f();k(t)},t=>{f();
G(t)})})};
  rCu = function(f,k,G,t){var Z=Kb(null,null,null);Z.B=new g.AV(function(u,h){Z.W=k?function(W){try{let D=k.call(t,W);u(D)}catch(D){h(D)}}:u;
Z.K=G?function(W){try{let D=G.call(t,W);D===void 0&&W instanceof nb?h(W):u(D)}catch(D){h(D)}}:h});
Z.B.W=f;E8(f,Z);return Z.B};
  g.n.Xr = function(f,k){return rCu(this,null,O8(f),k)};
  g.n.catch = {};
  b5E = function(f){var k=null;f.K&&(k=f.K,f.K=k.next,k.next=null);f.K||(f.S=null);return k};
  xpf = function(f,k,G){k==2?f.W.call(f.context,G):f.K&&f.K.call(f.context,G)};
  wjX = function(f,k,G,t){if(G==3&&k.K&&!k.S)for(;f&&f.Z;f=f.W)f.Z=!1;if(k.B)k.B.W=null,xpf(k,G,t);else try{k.S?k.W.call(k.context):xpf(k,G,t)}catch(Z){Xja.call(null,Z)}EkE.put(k)};
  sGQ = function(f,k){if(f.B==0)if(f.W){var G=f.W;if(G.K){var t=0,Z=null,u=null;for(let h=G.K;h&&(h.S||(t++,h.B==f&&(Z=h),!(Z&&t>1)));h=h.next)Z||(u=h);Z&&(G.B==0&&t==1?sGQ(G,k):(u?(t=u,t.next==G.S&&(G.S=t),t.next=t.next.next):b5E(G),wjX(G,Z,3,k)))}f.W=null}else FK(f,3,k)};
  g.n.cancel = function(f){if(this.B==0){let k=new nb(f);g.Cb(function(){sGQ(this,k)},this)}};
  g.n.P7 = function(f){this.B=0;FK(this,2,f)};
  g.n.XQ = function(f){this.B=0;FK(this,3,f)};
  g.n.Bu = function(){for(var f;f=b5E(this);)wjX(this,f,this.B,this.V);this.A=!1};
  R_X = function(f,k){if(f.endpoint==="log_event"){g.e3("more_accurate_gel_parser")&&nH().storePayload({isJspb:!1},f.payload);dI(f);var G=s_(f),t=new Map;t.set(G,[f.payload]);var Z=lDa(f.payload)||"";(f=MD6(k))&&E_(f);return new g.AV((u,h)=>{CH&&CH.isReady()?f1u(t,CH,u,h,{bypassNetworkless:!0},!0,wI(Z)):u()})}};
  var bE = {};
  var I$ = class{constructor(){this.S=this.K=this.W=0;this.B=!1}};
  var AtX = {};
  var uOy = {};
  var FrX = {};
  var ZXL = {};
  ao = function(f,k=200){return f?k===300?ZXL:FrX:k===300?uOy:AtX};
  Th = function(f){g.e3("transport_use_scheduler")?g.QL.Cl(f):g.sH(f)};
  g.cQ = class extends xb{constructor(f){super(f)}};
  n$ = function(f){if(f==null)return f;if(typeof f==="string"&&f)f=+f;else if(typeof f!=="number")return;return zc(f)?f|0:void 0};
  O2 = function(f,k){f=Es(f,k);return(f==null?f:zc(f)?f|0:void 0)??0};
  var Fub = class extends xb{constructor(f){super(f)}};
  var NhO = class extends xb{constructor(f){super(f)}getDeviceId(){return qP(this,6)}vK(f){var k=rq(this,9,n$,3,!0);o5(k,f);return k[f]}getPlayerType(){return O2(this,36)}setHomeGroupInfo(f){return BR(this,Fub,81,f)}clearLocationPlayabilityToken(){return nP(this,89)}};
  var pH = class extends xb{constructor(f){super(f)}W(f){return BR(this,NhO,1,f)}};
  FQ = function(f){if(f!=null&&typeof f!=="number")throw Error(`Value of float/double field must be a number, found ${typeof f}: ${f}`);return f};
  var U2d = class extends xb{constructor(f){super(f)}};
  var gI = [2,3,4,5,6];
  var es6 = class extends xb{constructor(f){super(f)}getValue(){return qP(this,fx(this,gI,2))}clearValue(){return Yj(this,2,gI)}};
  ow = function(f,k,G,t,Z,u,h,W,D){var V=uy(f,G);u=V?1:u;W=!!W||u===3;V=D&&!V;(u===2||V)&&KP(f)&&(k=f.q0,G=k[ZQ]|0);f=LP(k,Z,h);var U=f===dq?7:f[ZQ]|0,e=bh(U,G);if(D=!(4&e)){var q=f,O=G;let F=!!(2&e);F&&(O|=2);let m=!F,a=!0,r=0,X=0;for(;r<q.length;r++){let l=YG(q[r],t,O);if(l instanceof t){if(!F){let R=uy(l);m&&(m=!R);a&&(a=R)}q[X++]=l}}X<r&&(q.length=X);e|=4;e=a?e&-4097:e|4096;e=m?e|8:e&-9}e!==U&&(f[ZQ]=e,2&e&&Object.freeze(f));if(V&&!(8&e||!f.length&&(u===1||(u!==4?0:2&e||!(16&e)&&32&G)))){Mj(e)&&(f=
[...f],e=wq(e,G),G=mA(k,G,Z,f,h));t=f;V=e;for(U=0;U<t.length;U++)q=t[U],e=Ao(q),q!==e&&(t[U]=e);V|=8;e=V=t.length?V|4096:V&-4097;f[ZQ]=e}return f=as(f,e,k,G,Z,h,u,D,W)};
  U2 = function(f,k,G,t){var Z=t;ih(f);t=f.q0;f=ow(f,t,t[ZQ]|0,G,k,2,void 0,!0);Z=Z!=null?cU(Z,G):new G;f.push(Z);k=G=f===dq?7:f[ZQ]|0;(Z=uy(Z))?(G&=-9,f.length===1&&(G&=-4097)):G|=4096;G!==k&&(f[ZQ]=G);Z||zT(t)};
  var YX = class extends xb{constructor(f){super(f)}setSafetyMode(f){return Kx(this,5,f)}};
  xsL = function(f){switch(f){case "DESKTOP":return 1;case "UNKNOWN_PLATFORM":return 0;case "TV":return 2;case "GAME_CONSOLE":return 3;case "MOBILE":return 4;case "TABLET":return 5}};
  Ee = function(f){if(typeof f!=="number")throw JC("int32");if(!zc(f))throw JC("int32");return f|0};
  m$ = function(f){return f==null?f:Ee(f)};
  var ytL = class extends xb{constructor(f){super(f)}getToken(){return Qs(this,2)}setToken(f){return FZ(this,2,f)}};
  Iw = function(f,k,G){return nP(f,k,a5(G))};
  var OXy = class extends xb{constructor(f){super(f)}};
  var f2 = 1;
  var LH = new Map;
  var C7 = class{constructor(f){this.B=f}toString(){return this.B+""}};
  Ek = function(f){var k=zt();f=k?k.createScriptURL(f):f;return new C7(f)};
  u$ = function(f){return f?(f=f.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue)?Ek(f):null:null};
  var Av = void 0;
  bbH = function(){Av||(Av=u$(g.DR("WORKER_SERIALIZATION_URL")));return Av||void 0};
  mO = function(f){if(f instanceof C7)return f.B;throw Error("");};
  var KH = void 0;
  w7c = function(){var f=bbH();KH||f===void 0||(KH=new Worker(mO(f),void 0));return KH};
  var kQ = class extends xb{constructor(f){super(f,500)}};
  x7E = function(f,k,G,t={},Z,u,h,W={value:0}){u=D2H(u);t=Ro(t,h,D=>{g.e3("start_client_gcf")&&g.QL.Sw(async()=>{await juu(D)});
W.value--;W.value||G()},()=>{W.value--;
W.value||G()},Z);
t.headers["Content-Type"]="application/json+protobuf";t.postBodyFormat="JSPB";t.postBody=f;g.Xf(k,u,"",t);SN=!1};
  kWO = function(f,k,G,t={},Z,u){if(f.size===0)G();else{var h=Math.round((0,g.S)()),W={value:f.size},D=new Map([...f]);for(let [a]of D){var V=a,U=f.get(V);D=new g.cQ;var e=k.config_||g.UM(),q=new pH,O=new NhO;FZ(O,1,e.On);FZ(O,2,e.uT);Kx(O,16,e.nI);FZ(O,17,e.innertubeContextClientVersion);if(e.xB){var F=e.xB,m=new OM;F.coldConfigData&&FZ(m,1,F.coldConfigData);F.appInstallData&&FZ(m,6,F.appInstallData);F.coldHashData&&FZ(m,3,F.coldHashData);F.hotHashData&&m.W2(F.hotHashData);BR(O,OM,62,m)}(F=g.Nd.devicePixelRatio)&&
F!=1&&nP(O,65,FQ(F));F=qZ();F!==""&&FZ(O,54,F);F=OH();if(F.length>0){m=new U2d;for(let r=0;r<F.length;r++){let X=new es6;FZ(X,1,F[r].key);Yj(X,2,gI,Sf(F[r].value));U2(m,15,es6,X)}BR(q,U2d,5,m)}u7E(e,O);hIa(q);oJF(O);WdQ(e,O);Dha(O);g.e3("start_client_gcf")&&V_y(O);g.DR("DELEGATED_SESSION_ID")&&!g.e3("pageid_as_header_web")&&(e=new YX,FZ(e,3,g.DR("DELEGATED_SESSION_ID")));!g.e3("fill_delegate_context_in_gel_killswitch")&&(F=g.DR("INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT"))&&(m=hA(q,YX,3)||new YX,
e=q,F=FZ(m,18,F),BR(e,YX,3,F));e=O;F=g.DR("DEVICE","");for(let [r,X]of Object.entries(IE(F)))F=r,m=X,F==="cbrand"?FZ(e,12,m):F==="cmodel"?FZ(e,13,m):F==="cbr"?FZ(e,87,m):F==="cbrver"?FZ(e,88,m):F==="cos"?FZ(e,18,m):F==="cosver"?FZ(e,19,m):F==="cplatform"&&Kx(e,42,xsL(m));g.e3("web_attention_logging_enabled")&&(nP(O,55,m$(window.innerWidth)),nP(O,56,m$(window.innerHeight)));q.W(O);BR(D,pH,1,q);if(O=X9[V])a:{if(O.YX())q=1;else if(O.getPlaylistId())q=2;else break a;BR(D,GWD,4,O);O=hA(D,pH,1)||new pH;
e=hA(O,YX,3)||new YX;F=new ytL;F.setToken(V);Kx(F,1,q);U2(e,12,ytL,F);BR(O,YX,3,e)}delete X9[V];V=V==="visitorOnlyApprovedKey";Jv()||Iw(D,2,h);!V&&(q=g.DR("EVENT_ID"))&&(O=qBQ(),e=new OXy,FZ(e,1,q),Iw(e,2,O),BR(D,OXy,5,e));BhL(t);if(g.e3("jspb_serialize_with_worker")&&(q=w7c())&&t.writeThenSend){LH.set(f2,{client:k,resolve:G,networklessOptions:t,isIsolated:Z,useVSSEndpoint:u,dangerousLogToVisitorSession:V,requestsOutstanding:W});q.postMessage({op:"gelBatchToSerialize",batchRequest:Us(D),clientEvents:U,
key:f2});f2++;break}if(U){q=[];for(O=0;O<U.length;O++)try{q.push(new kQ(U[O]))}catch{g.BY(new g.U3("Transport failed to deserialize "+String(U[O])))}U=q}else U=[];for(let r of U)U2(D,3,kQ,r);U={startTime:(0,g.S)(),ticks:{},infos:{}};D=D.Bk();U.ticks.geljspc=(0,g.S)();g.e3("log_jspb_serialize_latency")&&ic("gel_jspb_serialize",U,{sampleRate:.1});x7E(D,k,G,t,Z,u,V,W)}}};
  tHL = function(f,k,G={},t=!1,Z=200,u=!1){var h=CH,W=new Map,D=new Map,V={isJspb:t,cttAuthInfo:void 0,tier:Z},U={isJspb:t,cttAuthInfo:void 0};if(t){for(let e of Object.keys(bE))k=g.e3("enable_web_tiered_gel")?nH().smartExtractMatchingEntries({keys:[V,U],sizeLimit:1E3}):nH().extractMatchingEntries({isJspb:!0,cttAuthInfo:e}),k.length>0&&W.set(e,k),(g.e3("web_fp_via_jspb_and_json")&&G.writeThenSend||!g.e3("web_fp_via_jspb_and_json"))&&delete bE[e];kWO(W,h,f,G,!1,u)}else{for(let e of Object.keys(bE))W=g.e3("enable_web_tiered_gel")?
nH().smartExtractMatchingEntries({keys:[{isJspb:!1,cttAuthInfo:e,tier:Z},{isJspb:!1,cttAuthInfo:e}],sizeLimit:1E3}):nH().extractMatchingEntries({isJspb:!1,cttAuthInfo:e}),W.length>0&&D.set(e,W),(g.e3("web_fp_via_jspb_and_json")&&G.writeThenSend||!g.e3("web_fp_via_jspb_and_json"))&&delete bE[e];f1u(D,h,f,k,G,!1,u)}};
  rI = function(f={},k=!1,G){new g.AV((t,Z)=>{var u=ao(k,G),h=u.B;u.B=!1;if(g.e3("enable_web_tiered_gel")&&g.e3("web_vss_routing_check_all_tier_policies")){let W=ao(k,300),D=ao(k,200);h=h||W.B||D.B;W.B=!1;D.B=!1}Th(u.W);Th(u.K);u.K=0;CH&&CH.isReady()?G===void 0&&g.e3("enable_web_tiered_gel")?tHL(t,Z,f,k,300,h):tHL(t,Z,f,k,G,h):(JVf(k,G),t())})};
  var hsf = undefined;
  g.y5 = function(f,k,G){return eU(0,k,0,G)};
  var yw = window;
  qK = function(){return"h5vcc"in yw&&yw.h5vcc.traceEvent?.traceBegin&&yw.h5vcc.traceEvent?.traceEnd?1:"performance"in yw&&yw.performance.mark&&yw.performance.measure?2:0};
  H1 = function(f,k=`unexpected value ${f}!`){throw Error(k);};
  O_ = function(f){var k=qK();switch(k){case 1:yw.h5vcc.traceEvent.traceBegin("YTLR",f);break;case 2:yw.performance.mark(`${f}-start`);break;case 0:break;default:H1(k,"unknown trace type")}};
  var Io = {};
  IDL = function(f){var k=qK();switch(k){case 1:yw.h5vcc.traceEvent.traceEnd("YTLR",f);break;case 2:k=`${f}-start`;let G=`${f}-end`;yw.performance.mark(G);yw.performance.measure(f,k,G);break;case 0:break;default:H1(k,"unknown trace type")}};
  FgD = function(f){var k=Array.from(f.B.keys()).sort((G,t)=>(f.B[t].priority??0)-(f.B[G].priority??0));
for(let G of k)k=f.B[G],k.jobId===void 0||k.kF||(f.scheduler.Cl(k.jobId),eU(0,k.Au,10))};
  var AVD = undefined;
  Kga = function(f,k,G){AVD&&console.groupCollapsed&&console.groupEnd&&(console.groupCollapsed(`[${f.constructor.name}] '${f.state}' to '${k}'`),console.log("with message: ",G),console.groupEnd())};
  EpX = function(f){Io&&f&&O_(f)};
  m7D = function(f){if(g.e3("web_lifecycle_error_handling_killswitch"))return f();try{return f()}catch(k){window.onerror?.(k.message,"",0,0,k)}};
  Qw = function(f){Io&&f&&IDL(f)};
  npy = function(f,...k){return()=>{EpX(f.name);m7D(()=>f.callback(...k));
Qw(f.name)}};
  goL = function(f){var k=g.qd("yt.scheduler.instance.addImmediateJob");k?k(f):f()};
  z_E = function(f,...k){g.O3();for(let G of f)f=npy(G,...k),goL(f)};
  var Lgf = class{constructor(f){this.scheduler=g.O3();this.K=new g.$S;this.B=f;for(let k=0;k<this.B.length;k++){let G=this.B[k];f=()=>{G.Au();this.B[k].kF=!0;this.B.every(Z=>Z.kF===!0)&&this.K.resolve()};
let t=eU(0,f,G.priority??0);this.B[k]={...G,Au:f,jobId:t}}}cancel(){for(let f of this.B)f.jobId===void 0||f.kF||this.scheduler.Cl(f.jobId),f.kF=!0;this.K.resolve()}};
  ibF = function(f,k,...G){k=k.map(t=>{var Z=f.K??t.priority??0;return{Au:npy(t,...G),priority:Z}});
k.length&&(f.W=new Lgf(k))};
  var PQ = undefined;
  $7d = async function(f,...k){g.O3();for(let G of f){let t;goL(()=>{EpX(G.name);var Z=m7D(()=>G.callback(...k));
PQ(Z)?t=g.e3("web_lifecycle_error_handling_killswitch")?Z.then(()=>{Qw(G.name)}):Z.then(()=>{Qw(G.name)},u=>{window.onerror?.(u.message,"",0,0,u);
Qw(G.name)}):Qw(G.name)});
t&&await t}};
  Cmd = function(f,k){var G=k.filter(Z=>(f.K??Z.priority??0)===10),t=k.filter(Z=>(f.K??Z.priority??0)!==10);
return f.S.ePE?async(...Z)=>{await $7d(G,...Z);ibF(f,t,...Z)}:(...Z)=>{z_E(G,...Z);
ibF(f,t,...Z)}};
  var HYs = class{constructor(){this.state="none";this.plugins=[];this.K=void 0;this.S={};Io&&O_(this.state)}get currentState(){return this.state}install(f){this.plugins.push(f);return this}uninstall(...f){f.forEach(k=>{k=this.plugins.indexOf(k);k>-1&&this.plugins.splice(k,1)})}transition(f,k){Io&&IDL(this.state);
var G=this.transitions.find(t=>Array.isArray(t.from)?t.from.find(Z=>Z===this.state&&t.to===f):t.from===this.state&&t.to===f);
if(G){this.W&&(FgD(this.W),this.W=void 0);Kga(this,f,k);this.state=f;Io&&O_(this.state);G=G.action.bind(this);let t=this.plugins.filter(Z=>Z[f]).map(Z=>Z[f]);
G(Cmd(this,t),k)}else throw Error(`no transition specified from ${this.state} to ${f}`);}};
  var d7a = class extends HYs{constructor(){super();this.B=null;this.K=10;this.transitions=[{from:"none",to:"application_navigating",action:this.Z},{from:"application_navigating",to:"none",action:this.A},{from:"application_navigating",to:"application_navigating",action:()=>{}},
{from:"none",to:"none",action:()=>{}}]}Z(f,k){this.B=g.y5(0,()=>{this.currentState==="application_navigating"&&this.transition("none")},5E3);
f(k?.event)}A(f,k){this.B&&(g.QL.Cl(this.B),this.B=null);f(k?.event)}};
  F9 = undefined;
  saQ = function(){F9||(F9=new d7a);return F9};
  HQ = function(f,k){return g.e3("transport_use_scheduler")===!1?g.Lt(f,k):g.e3("logging_avoid_blocking_during_navigation")||g.e3("lr_logging_avoid_blocking_during_navigation")?g.y5(0,()=>{saQ().currentState==="none"?f():saQ().install({none:{callback:f}})},k):g.y5(0,f,k)};
  var oSL = undefined;
  var WrL = undefined;
  JVf = function(f=!1,k=200){var G=()=>{rI({writeThenSend:!0},f,k)},t=ao(f,k),Z=t===ZXL||t===uOy?5E3:hsf;
g.e3("web_gel_timeout_cap")&&!t.K&&(Z=HQ(()=>{G()},Z),t.K=Z);
Th(t.W);Z=g.DR("LOGGING_BATCH_TIMEOUT",yZ("web_gel_debounce_ms",1E4));g.e3("shorten_initial_gel_batch_timeout")&&SN&&(Z=oSL);Z=HQ(()=>{yZ("gel_min_batch_size")>0?nH().getSequenceCount({cttAuthInfo:void 0,isJspb:f,tier:k})>=WrL&&G():G()},Z);
t.W=Z};
  MK = undefined;
  cVc = function(f,k=!1,G,t=!1){f&&E_(f);f=yZ("tvhtml5_logging_max_batch_ads_fork")||yZ("tvhtml5_logging_max_batch")||yZ("web_logging_max_batch")||100;var Z=(0,g.S)(),u=ao(k,G.tier),h=u.S;t&&(u.B=!0);t=0;G&&(t=nH().getSequenceCount(G));t>=1E3?rI({writeThenSend:!0},k,G.tier):t>=f?MK||(MK=HQ(()=>{rI({writeThenSend:!0},k,G.tier);MK=void 0},0)):Z-h>=10&&(JVf(k,G.tier),u.S=Z)};
  p7y = function(f,k){if(f.endpoint==="log_event"){dI(f);var G=s_(f),t=lDa(f.payload)||"",Z=T56(t),u=200;if(Z){if(Z.enabled===!1&&!g.e3("web_payload_policy_disabled_killswitch"))return;u=S8d(Z.tier);if(u===400){R_X(f,k);return}}bE[G]=!0;G={cttAuthInfo:G,isJspb:!1,tier:u};nH().storePayload(G,f.payload);cVc(k,!1,G,wI(t))}};
  Zm = function(f,k,G,t={}){var Z={},u=Math.round(t.timestamp||(0,g.S)());Z.eventTimeMs=u<Number.MAX_SAFE_INTEGER?u:0;Z[f]=k;f=MZ();Z.context={lastActivityMs:String(t.timestamp||!isFinite(f)?-1:f)};t.sequenceGroup&&!g.e3("web_gel_sequence_info_killswitch")&&(f=Z.context,k=t.sequenceGroup,k={index:$2Q(k),groupKey:k},f.sequence=k,t.endOfSequence&&delete tE[t.sequenceGroup]);g.e3("web_tag_automated_log_events")&&(Z.context.automatedLogEventSource=t.automatedLogEventSource);(t.sendIsolatedPayload?R_X:p7y)({endpoint:"log_event",
payload:Z,cttAuthInfo:t.cttAuthInfo,dangerousLogToVisitorSession:t.dangerousLogToVisitorSession},G)};
  g.hE = function(f,k,G={}){var t=g.u8;g.DR("ytLoggingEventsDefaultDisabled",!1)&&g.u8===g.u8&&(t=null);Zm(f,k,t,G)};
  var u1c = 0;
  var hKc = ["PhantomJS","Googlebot","TO STOP THIS SECURITY SCAN go/scan"];
  VZ = function(f){var k=oE.EXPERIMENT_FLAGS;return k?k[f]:void 0};
  var ogy = [];
  iXu = function(f=!1){rI(void 0,f)};
  var GGa = {};
  var YBd = 0;
  tyy = function(f,k="ERROR"){if(k==="ERROR"){AE.publish("handleError",f);if(g.e3("record_app_crashed_web")&&ZWu===0&&f.sampleWeight===1){ZWu++;var G={appCrashType:"APP_CRASH_TYPE_BREAKPAD"};g.e3("report_client_error_with_app_crash_ks")||(G.systemHealth={crashData:{clientError:{logMessage:{message:f.message}}}});g.hE("appCrashed",G)}u1c++}else k==="WARNING"&&AE.publish("handleWarning",f);if(g.e3("kevlar_gel_error_routing")){G={};b:{for(t of hKc)if(g.DJ(t.toLowerCase())){var t=!0;break b}t=!1}if(t)G=void 0;
else{var Z={stackTrace:f.stack};f.fileName&&(Z.filename=f.fileName);t=f.lineNumber&&f.lineNumber.split?f.lineNumber.split(":"):[];t.length!==0&&(t.length!==1||isNaN(Number(t[0]))?t.length!==2||isNaN(Number(t[0]))||isNaN(Number(t[1]))||(Z.lineNumber=Number(t[0]),Z.columnNumber=Number(t[1])):Z.lineNumber=Number(t[0]));t={level:"ERROR_LEVEL_UNKNOWN",message:f.message,errorClassName:f.name,sampleWeight:f.sampleWeight};k==="ERROR"?t.level="ERROR_LEVEL_ERROR":k==="WARNING"&&(t.level="ERROR_LEVEL_WARNNING");
Z={isObfuscated:!0,browserStackInfo:Z};G.pageUrl=window.location.href;G.kvPairs=[];g.DR("FEXP_EXPERIMENTS")&&(G.experimentIds=g.DR("FEXP_EXPERIMENTS"));var u=g.DR("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS");if(!VZ("web_disable_gel_stp_ecatcher_killswitch")&&u)for(var h of Object.keys(u))G.kvPairs.push({key:h,value:String(u[h])});if(h=f.params)for(var W of Object.keys(h))G.kvPairs.push({key:`client.${W}`,value:String(h[W])});if(W=f.params?.sessionReplayId)G.sessionReplayId=String(W);W=g.DR("SERVER_NAME");
h=g.DR("SERVER_VERSION");W&&h&&(G.kvPairs.push({key:"server.name",value:W}),G.kvPairs.push({key:"server.version",value:h}));(W=g.DR("PLAYER_CLIENT_VERSION"))&&G.kvPairs.push({key:"client.player.version",value:W});G={errorMetadata:G,stackTrace:Z,logMessage:t}}if(G&&(g.hE("clientError",G),k==="ERROR"||g.e3("errors_flush_gel_always_killswitch")))a:{if(g.e3("web_fp_via_jspb")){G=ogy;ogy=[];if(G)for(var D of G)Zm(D.payloadName,D.payload,g.u8,D.options);iXu(!0);if(!g.e3("web_fp_via_jspb_and_json"))break a}iXu()}}if(!g.e3("suppress_error_204_logging")){D=
f.params||{};k={urlParams:{a:"logerror",t:"jserror",type:f.name,msg:f.message.substr(0,250),line:f.lineNumber,level:k,"client.name":D.name},postParams:{url:g.DR("PAGE_NAME",window.location.href),file:f.fileName},method:"POST"};D.version&&(k["client.version"]=D.version);if(k.postParams){f.stack&&(k.postParams.stack=f.stack);for(var V of Object.keys(D))k.postParams[`client.${V}`]=D[V];if(V=g.DR("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS"))for(var U of Object.keys(V))k.postParams[U]=V[U];(U=g.DR("LAVA_VERSION"))&&
(k.postParams["lava.version"]=U);U=g.DR("SERVER_NAME");V=g.DR("SERVER_VERSION");U&&V&&(k.postParams["server.name"]=U,k.postParams["server.version"]=V);(U=g.DR("PLAYER_CLIENT_VERSION"))&&(k.postParams["client.player.version"]=U)}g.aE(`${g.DR("ECATCHER_REPORT_HOST","")}/error_204`,k)}try{GGa.add(f.message)}catch(e){}YBd++};
  gSf = function(f,k,G="ERROR"){if(f){f.hasOwnProperty("level")&&f.level&&(G=f.level);if(g.e3("wiz_enable_metadata_extraction_killswitch")){var t=k;if(!t?.componentStack){var Z=f.dK?.Bj;Z&&(t||(t={}),t.componentStack=Z)}k=t||k}else k=pMa(f,k),t=f.dK?.HZ,t!==void 0&&G!=="IGNORED"&&(G=t>=3?"ERROR":"WARNING");if(g.e3("console_log_js_exceptions")||["test","dev","autopush","staging"].includes(g.DR("SERVER_VERSION")))t=[],t.push(`Name: ${f.name}`),t.push(`Message: ${f.message}`),f.hasOwnProperty("params")&&
t.push(`Error Params: ${JSON.stringify(f.params)}`),f.hasOwnProperty("args")&&t.push(`Error args: ${JSON.stringify(f.args,null,2)}`),t.push(`File name: ${f.fileName}`),t.push(`Stacktrace: ${f.stack}`),window.console.log(t.join("\n"),f);if(!(YBd>=5)){t=[];for(u of Jt6)try{u()&&t.push(u())}catch(F){}var u=t;u=[...f3f,...u];var h=CaF(f);t=h.message||"Unknown Error";Z=h.name||"UnknownError";var W=h.stack||f.xGG||"Not available";if(W.startsWith(`${Z}: ${t}`)){var D=W.split("\n");D.shift();W=D.join("\n")}D=
h.lineNumber||"Not available";h=h.fileName||"Not available";let O=0;if(f.hasOwnProperty("args")&&f.args&&f.args.length)for(var V=0;V<f.args.length&&!(O=ctH(f.args[V],`params.${V}`,k,O),O>=500);V++);else if(f.hasOwnProperty("params")&&f.params){let F=f.params;if(typeof f.params==="object")for(V in F){if(!F[V])continue;let m=`params.${V}`,a=Oo(F[V]);k[m]=a;O+=m.length+a.length;if(O>500)break}else k.params=Oo(F)}if(u.length)for(V=0;V<u.length&&!(O=ctH(u[V],`params.context.${V}`,k,O),O>=500);V++);navigator.vendor&&
!k.hasOwnProperty("vendor")&&(k["device.vendor"]=navigator.vendor);V={message:t,name:Z,lineNumber:D,fileName:h,stack:W,params:k,sampleWeight:1};k=Number(f.columnNumber);isNaN(k)||(V.lineNumber=`${V.lineNumber}:${k}`);if(f.level==="IGNORED")var U=0;else a:{f=eE();for(U of f.oU)if(V.message&&V.message.match(U.CC)){U=U.weight;break a}for(var e of f.t0)if(e.callback(V)){U=e.weight;break a}U=1}V.sampleWeight=U;U=V;for(var q of kGL){if(!q.lP[U.name])continue;e=q.lP[U.name];for(let F of e){e=U.message.match(F.mX);
if(!e)continue;U.params["params.error.original"]=e[0];f=F.groups;V={};for(k=0;k<f.length;k++)V[f[k]]=e[k+1],U.params[`params.error.${f[k]}`]=e[k+1];U.message=q.OV(V);break}}U.params||(U.params={});q=eE();U.params["params.errorServiceSignature"]=`msg=${q.oU.length}&cb=${q.t0.length}`;U.params["params.serviceWorker"]="false";g.Nd.document&&g.Nd.document.querySelectorAll&&(U.params["params.fscripts"]=String(document.querySelectorAll("script:not([nonce])").length));(new Iz(FI,"sample")).constructor!==
Iz&&(U.params["params.fconst"]="true");window.yterr&&typeof window.yterr==="function"&&window.yterr(U);U.sampleWeight===0||GGa.has(U.message)||tyy(U,G)}}};
  g.PZ = function(f,k="ERROR"){var G={};G.name=g.DR("INNERTUBE_CONTEXT_CLIENT_NAME",1);G.version=g.DR("INNERTUBE_CONTEXT_CLIENT_VERSION");gSf(f,G,k)};
  g.xi = function(f){g.PZ(f,"WARNING")};
  gk = function(f,k,G=!1,t=""){!f&&G&&g.xi(Error(`Player URL validator detects invalid url. ${t}: ${k}`));return f};
  JO = function(f){return gk(Yf(f,u9F,hBu),f,!1,"Trusted Stream URL")};
  fW = function(f,k){this.K=this.B=null;this.W=f||null;this.S=!!k};
  g.n = fW.prototype;
  Ms = function(f,k){if(f){f=f.split("&");for(let G=0;G<f.length;G++){let t=f[G].indexOf("="),Z,u=null;t>=0?(Z=f[G].substring(0,t),u=f[G].substring(t+1)):Z=f[G];k(Z,u?WI(u):"")}}};
  uD = function(f){f.B||(f.B=new Map,f.K=0,f.W&&Ms(f.W,function(k,G){f.add(WI(k),G)}))};
  hL = function(f,k){k=String(k);f.S&&(k=k.toLowerCase());return k};
  g.n.add = function(f,k){uD(this);this.W=null;f=hL(this,f);var G=this.B.get(f);G||this.B.set(f,G=[]);G.push(k);this.K=this.K+1;return this};
  g.n.remove = function(f){uD(this);f=hL(this,f);return this.B.has(f)?(this.W=null,this.K=this.K-this.B.get(f).length,this.B.delete(f)):!1};
  g.n.clear = function(){this.B=this.W=null;this.K=0};
  g.n.isEmpty = function(){uD(this);return this.K==0};
  g.n.forEach = function(f,k){uD(this);this.B.forEach(function(G,t){G.forEach(function(Z){f.call(k,Z,t,this)},this)},this)};
  g.n.dE = function(){uD(this);var f=Array.from(this.B.values()),k=Array.from(this.B.keys()),G=[];for(let t=0;t<k.length;t++){let Z=f[t];for(let u=0;u<Z.length;u++)G.push(k[t])}return G};
  LAH = function(f,k){uD(f);k=hL(f,k);return f.B.has(k)};
  g.n.t_ = function(f){uD(this);var k=[];if(typeof f==="string")LAH(this,f)&&(k=k.concat(this.B.get(hL(this,f))));else{f=Array.from(this.B.values());for(let G=0;G<f.length;G++)k=k.concat(f[G])}return k};
  g.n.set = function(f,k){uD(this);this.W=null;f=hL(this,f);LAH(this,f)&&(this.K=this.K-this.B.get(f).length);this.B.set(f,[k]);this.K=this.K+1;return this};
  g.n.get = function(f,k){if(!f)return k;f=this.t_(f);return f.length>0?String(f[0]):k};
  g.n.toString = function(){if(this.W)return this.W;if(!this.B)return"";var f=[],k=Array.from(this.B.keys());for(let t=0;t<k.length;t++){var G=k[t];let Z=g.o7(G);G=this.t_(G);for(let u=0;u<G.length;u++){let h=Z;G[u]!==""&&(h+="="+g.o7(G[u]));f.push(h)}}return this.W=f.join("&")};
  g.n.clone = function(){var f=new fW;f.W=this.W;this.B&&(f.B=new Map(this.B),f.K=this.K);return f};
  g.bs = function(f){var k=[],G=0;for(let t in f)k[G++]=t;return k};
  zaQ = function(f){if(f.dE&&typeof f.dE=="function")return f.dE();if(!f.t_||typeof f.t_!="function"){if(typeof Map!=="undefined"&&f instanceof Map)return Array.from(f.keys());if(!(typeof Set!=="undefined"&&f instanceof Set)){if(g.FL(f)||typeof f==="string"){let k=[];f=f.length;for(let G=0;G<f;G++)k.push(G);return k}return g.bs(f)}}};
  sn = function(f){var k=[],G=0;for(let t in f)k[G++]=f[t];return k};
  iPu = function(f){if(f.t_&&typeof f.t_=="function")return f.t_();if(typeof Map!=="undefined"&&f instanceof Map||typeof Set!=="undefined"&&f instanceof Set)return Array.from(f.values());if(typeof f==="string")return f.split("");if(g.FL(f)){let k=[],G=f.length;for(let t=0;t<G;t++)k.push(f[t]);return k}return sn(f)};
  ChO = function(f,k,G){if(f.forEach&&typeof f.forEach=="function")f.forEach(k,G);else if(g.FL(f)||typeof f==="string")Array.prototype.forEach.call(f,k,G);else{let t=zaQ(f),Z=iPu(f),u=Z.length;for(let h=0;h<u;h++)k.call(G,Z[h],t&&t[h],f)}};
  g.n.extend = function(f){for(let k=0;k<arguments.length;k++)ChO(arguments[k],function(G,t){this.add(t,G)},this)};
  Jt = function(f,k){return f?k?decodeURI(f.replace(/%25/g,"%2525")):decodeURIComponent(f):""};
  g.cM = function(f,k,G){f.Z=G?Jt(k,!0):k;f.Z&&(f.Z=f.Z.replace(/:$/,""))};
  g.pX = function(f,k,G){f.B=G?Jt(k,!0):k};
  g.gh = function(f,k){if(k){k=Number(k);if(isNaN(k)||k<0)throw Error("Bad port number "+k);f.W=k}else f.W=null};
  var mjE = /[#\?@]/g;
  njO = function(f){f=f.charCodeAt(0);return"%"+(f>>4&15).toString(16)+(f&15).toString(16)};
  kg = function(f,k,G){return typeof f==="string"?(f=encodeURI(f).replace(k,njO),G&&(f=f.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f):null};
  g.ve = function(f){var k=f.length;if(k>0){let G=Array(k);for(let t=0;t<k;t++)G[t]=f[t];return G}return[]};
  g.djc = function(f,k,G){f.remove(k);G.length>0&&(f.W=null,f.B.set(hL(f,k),g.ve(G)),f.K=f.K+G.length)};
  EjH = function(f,k){k&&!f.S&&(uD(f),f.W=null,f.B.forEach(function(G,t){var Z=t.toLowerCase();t!=Z&&(this.remove(t),g.djc(this,Z,G))},f));
f.S=k};
  YS = function(f,k,G){k instanceof fW?(f.S=k,EjH(f.S,f.V)):(G||(k=kg(k,mjE)),f.S=new fW(k,f.V))};
  g.Ru = function(f){this.B=this.C=this.Z="";this.W=null;this.A=this.K="";this.V=!1;var k;f instanceof g.Ru?(this.V=f.V,g.cM(this,f.Z),this.C=f.C,g.pX(this,f.B),g.gh(this,f.W),this.K=f.K,YS(this,f.S.clone()),this.A=f.A):f&&(k=g.CN(String(f)))?(this.V=!1,g.cM(this,k[1]||"",!0),this.C=Jt(k[2]||""),g.pX(this,k[3]||"",!0),g.gh(this,k[4]),this.K=Jt(k[5]||"",!0),YS(this,k[6]||"",!0),this.A=Jt(k[7]||"")):(this.V=!1,this.S=new fW(null,this.V))};
  g.tL = function(f){return f instanceof g.Ru?f.clone():new g.Ru(f)};
  dZ = function(f,k,G,t,Z){var u=k^f;if(f+5>>1<f&&(f-9|11)>=f){for(var h=u^6445,W=[];++h-W[Q[u^6502]]-(u^6477);)switch(h){case u^6467:h=u^6450;default:W[Q[u^6500]](String[Q[u^6464]](h));case u^6451:case u^6450:case u^6413:break;case u^6422:h-=u^6433;case u^6449:case u^6448:continue;case u^6487:h=u^6465;case u^6454:}var D=W}if((f+6^30)>=f&&f+1>>1<f){h=u^5102;for(W=[];++h-W[Q[u^5029]]-(u^5006);){switch(h){case u^5109:h=u^4994;continue;case u^5077:h=u^5103;break;case u^5103:h-=u^5052;continue;case u^5012:h=
u^5070;continue;case u^4992:h=u^5105}W[Q[u^5031]](String[Q[u^4995]](h))}D=W}f-5<30&&f+8>=26&&(t===Q[u^6931]&&((h=Z[Q[u^7004]](Q[u^6999]))>=0?(t=`cmo=${Z[Q[u^6991]](0,h)}`,Z=Z[Q[u^6991]](h+1)):(h=Z[Q[u^7004]](Q[u^6923]))>=0&&(t=`cmo=${Z[Q[u^6991]](0,h)}`,Z=Z[Q[u^6991]](h+3))),G[t]=Z);return D};
  fE = function(f,k,G,t,Z,u,h,W){var D=k^f;if(f-4>=23&&(f+7&16)<1){var V=G[t];let e=V[Q[D^2028]](Q[D^2023]);e>0?dZ(D^2022,D^7331,Z,V[Q[D^2047]](0,e),V[Q[D^2047]](e+1)):V&&(Z[V]=Q[5]);var U=[]}(f+3&57)<f&&f-9<<1>=f&&(U=t(u,h,W));if((f-4|4)<f&&(f-1^14)>=f)for(V=G[Q[D^710]];V;)G[Q[D^708]](G[Q[1]](--V,1)[0]);(f-3^10)<f&&(f-8^17)>=f&&G[Q[11]]!=0&&(t=(t%G[Q[11]]+G[Q[11]])%G[Q[11]],G[Q[1]](0,1,G[Q[1]](t,1,G[0])[0]));return U};
  var gyO = function(f,k){return fE[Q[22]](this,11,8767,f,k)};
  var JpF = {};
  var Ik = {gC:function(f,k){f[Q[1]](0,k)},
Bh:function(f){f[Q[44]]()},
pH:function(f,k){var G=f[0];f[0]=f[k%f[Q[11]]];f[k%f[Q[11]]]=G}};
  var br = function(f,k,G,t,Z,u,h,W,D){var V=k^f;
if((f-3&7)==2)a:{var U=g.x(G,JpF)||G[Q[V^3273]],e={Ij:!1,U0:Q[5],vX:Q[5],s:Q[5]};if(!U){var q=e;break a}U=IE(U);e[Q[V^3281]]=!0;e[Q[V^3263]]=U[Q[V^3307]];e[Q[V^3282]]=U[Q[V^3278]];e[Q[V^3323]]=U[Q[V^3323]];q=e}f-3>>3==1&&(q=G(h,W,D));(f-7^5)<f&&f+6>>1>=f&&(G[V^4110]!==-(V^4126)&&(G[V^4128]!=-5&&((((0,G[V^4129])(G[V^4147],G[V^4149]),G[1])(G[0]),G[V^4096])(G[V^4108],G[V^4168]),1)||(0,G[V^4103])((0,G[V^4174])(G[new t(Q[V^4161])/(V^5118)],G[5]),G[V^4125],(0,G[V^4145])(G[V^4168],G[V^4124]),G[V^4132],G[V^
4182],G[V^4143],(0,G[V^4105])())),G[V^4188]!=-(V^4127)&&((0,G[V^4096])(G[V^4167],G[V^4187]),1)||(0,G[V^4145])(G[V^4191],G[V^4173]),G[new t(Q[V^4180])/(V^5118)]===-1?(0,G[V^4125])((0,G[V^4174])(G[V^4187],G[V^4179]),G[V^4096],G[V^4189],G[V^4144]):(0,G[V^4125])((0,G[V^4174])(G[V^4143],G[V^4184]),G[V^4111],G[V^4187]),G[V^4150]<5&&((((0,G[V^4129])(G[V^4142],G[V^4164]),G[V^4156])(G[V^4104],G[V^4191],(0,G[V^4152])()),G[V^4154])(G[V^4104],G[V^4142],(0,G[V^4137])()),Q[V^4138])||(0,G[V^4165])((0,G[V^4165])((0,G[V^
4173])(G[0],G[V^4153]),G[V^4179],G[V^4103]),G[3],G[V^4144],G[V^4136]),G[V^4107]>=-3&&(0,G[2])(G[V^4145],(0,G[3])(G[V^4099],G[V^4135]),(0,G[3])(G[V^4191],G[V^4104]),(0,G[V^4096])(G[V^4155],G[V^4173]),G[V^4143],G[V^4139]),G[V^4155]!=2&&(G[V^4158]==-(V^4124)&&((0,G[V^4145])(G[V^4143],G[V^4102]),1)||(0,G[V^4096])(G[V^4166],G[V^4099])),q=[]);f+9&11||(e=G[Q[V^8715]](Q[5]),Ik[Q[V^8760]](e,2),Ik[Q[V^8761]](e,V^8709),Ik[Q[V^8761]](e,V^8741),Ik[Q[V^8760]](e,3),Ik[Q[V^8712]](e,V^8736),Ik[Q[V^8760]](e,2),Ik[Q[V^
8712]](e,V^8798),Ik[Q[V^8760]](e,2),Ik[Q[V^8712]](e,V^8712),q=e[Q[V^8727]](Q[5]));return q};
  var K1F = function(f,k,G,t,Z,u,h){return br[Q[22]](this,12,2041,f,k,G,t,Z,u,h)};
  var iBu = function(f){return fE[Q[22]](this,1,716,f)};
  var O96 = function(f,k){return Xm[Q[22]](this,4,2583,f,k)};
  wZ = function(f,k,G,t,Z,u,h,W,D,V){var U=k^f;if(!((f|4)>>4)){(0,G[3])(G[U^5074],G[U^5018]);(0,G[U^5053])(G[U^5065],G[U^5040],(0,G[U^5049])());(0,G[3])(G[U^5056],G[U^5045]);(((0,G[3])(G[U^5056],G[4]),G[U^5038])(G[U^5040],G[1]),G[U^5038])(G[U^5039],G[U^5055]);var e=[]}if(((f|8)&7)==3){var q=Z3(U^694,U^7813,G);t[Q[U^664]](Q[U^756],q);e=[]}if((f-2|29)<f&&(f+2^7)>=f){q=G[Q[U^1280]](Q[4]);let F={};for(let m=0;m<q[Q[U^1311]];m++)var O=fE(U^1289,U^764,q,m,F);e=F}(f-2^12)>=f&&(f+2^24)<f&&(e=G(W,D,V));return e};
  var z8y = function(f,k,G,t,Z,u,h,W){return wZ[Q[22]](this,18,4592,f,k,G,t,Z,u,h,W)};
  OZ = function(f,k,G,t,Z,u,h,W,D,V){var U=k^f;if((f-1^1)>=f&&(f-1^18)<f){G=(G%t[Q[U^5319]]+t[Q[U^5319]])%t[Q[U^5319]];var e=t[0];t[0]=t[G];t[G]=e;var q=[G]}(f+7&40)<f&&(f-6|6)>=f&&(t=(t%G[Q[U^6678]]+G[Q[U^6678]])%G[Q[U^6678]],G[Q[1]](t,1));f-8>>4||(q=t(Z,u,h,W,D,V));(f+8&70)>=f&&f+7>>2<f&&(Xm(U^4686,U^2278,G),(e=G[Q[U^4735]][Q[U^4644]]||null)&&(e=wZ(U^4727,U^4299,e,G)),q=[]);return q};
  PS = function(f,k,G,t,Z){var u=k^f;if((f|56)==f&&t[Q[11]]!=0){var h=OZ(25,5333,G,t);G=h[0]}if(f+1>=6&&f>>1<12){var W=Z[Q[u^990]];t[Q[u^1019]](function(U,e,q){this[Q[u^988]](q[e]=Z[(Z[Q[u^972]](U)-Z[Q[u^972]](this[e])+e+W--)%Z[Q[u^990]]])},G[Q[u^961]](Q[5]))}if((f+1&15)==3){h=u^3251;
for(var D=[];++h-D[Q[u^3320]]-(u^3283);)switch(h){case u^3273:h=u^3219;continue;case u^3240:h=u^3295;break;case u^3250:h=u^3292;continue;case u^3293:h=u^3178;case u^3208:h-=u^3273;default:D[Q[u^3322]](String[Q[u^3294]](h))}var V=D}f+3&27||(G[6]!=-5&&(0,G[u^3330])(G[u^3408],G[1],(0,G[u^3352])()),G[3]!=5&&(G[0]===6&&((0,G[u^3443])(G[1],G[u^3355]),Q[u^3340])||(0,G[u^3453])(G[u^3429])),G[u^3348]!==-2&&(G[u^3397]>=0&&((0,G[u^3430])(G[new t(Q[u^3336])/(u^3760)],G[u^3405]),Q[u^3356])||(0,G[u^3443])(G[u^
3405],G[u^3412])),G[u^3410]!=(u^3410)&&(G[0]>(u^3408)||(((0,G[u^3353])(G[u^3451]),G[u^3430])(G[u^3353],G[u^3428]),null))&&(0,G[u^3348])((0,G[u^3353])(G[0],G[u^3354]),G[u^3451],G[u^3407],G[u^3354],(0,G[u^3455])()),V=[]);(f^76)>>3==1&&G[Q[1]](G[Q[11]],0,t);return V};
  var gIy = function(f,k,G){return PS[Q[22]](this,5,976,f,k,G)};
  var Imd = function(f,k,G){return sZ[Q[22]](this,4,2912,f,k,G)};
  var Cuf = function(){return Z3[Q[22]](this,1,5038)};
  var R4d = function(f,k){return OZ[Q[22]](this,46,6707,f,k)};
  var jI6 = function(f,k){return PS[Q[22]](this,64,2915,f,k)};
  var EeQ = function(){return PS[Q[22]](this,2,3313)};
  var TCc = function(){return dZ[Q[22]](this,2,5036)};
  var fOy = function(f,k,G,t,Z,u){return fE[Q[22]](this,20,3160,f,k,G,t,Z,u)};
  EM = function(f,k,G,t,Z,u,h){var W;(f+8^28)>=f&&(f+9&43)<f&&G[Q[44]]();(f>>1&7)==1&&(W=G[Q[26]]?G[Q[26]][Q[34]](Q[6]):G[Q[17]]===Q[6]);(f^3)>=18&&f+8>>4<3&&(W=t(Z,u,h));return W};
  var ivO = function(f){return EM[Q[22]](this,7,8763,f)};
  var Eod = function(){return dZ[Q[22]](this,14,6499)};
  var mYf = function(f,k){return PS[Q[22]](this,56,5040,f,k)};
  var Ct6 = function(f,k,G,t,Z,u,h,W){return OZ[Q[22]](this,8,1839,f,k,G,t,Z,u,h,W)};
  FA = function(f,k,G,t){var Z=k^f;if(f-1>>4<4&&(f|4)>=24){Xm(Z^7237,Z^1773,G);var u=G[Q[Z^7246]]}(f+3&8)<3&&(f+3&3)>=0&&(G=(G%t[Q[Z^2436]]+t[Q[Z^2436]])%t[Q[Z^2436]],t[Q[1]](-G)[Q[Z^2467]]()[Q[Z^2465]](function(h){t[Q[Z^2487]](h)}));
return u};
  var jRH = function(f,k){return FA[Q[22]](this,1,2446,f,k)};
  var hgu = function(f,k,G,t,Z){return EM[Q[22]](this,16,55,f,k,G,t,Z)};
  var neu = -1808487191;
  rZ = function(f,k,G){var t=k^f;if(f+5>>2<f&&(f+7&31)>=f){var Z=G[Q[t^6735]](Q[t^6740]);let h=0;Z[0]||h++;let W={};for(;h<Z[Q[t^6736]];h+=2)Z[h]&&dZ(t^6729,t^268,W,Z[h],Z[h+1]);var u=W}if(f+2>>2<f&&(f-8|21)>=f){try{G[t^3195]<=-5&&(0,G[t^3132])(G[0],G[t^3116]),G[t^3134]!==-(t^3172)&&(G[t^3108]<=4||((0,G[t^3110])((0,G[t^3107])(G[t^3116]),G[t^3117],(0,G[t^3132])(G[t^3138],G[t^3191]),G[t^3116],G[t^3174])-(0,G[t^3132])(G[t^3144],G[t^3172]),new Date(Q[t^3125])/(t^3973)))&&((0,G[t^3107])(G[t^3135]),G[t^3121])((0,G[t^
3130])(G[t^3156],G[t^3191]),G[t^3165],G[t^3187],G[t^3108])^(0,G[t^3129])(G[t^3171],G[t^3162])}catch(h){(0,G[t^3144])(G[t^3194],G[t^3164],(0,G[t^3157])())|(0,G[t^3129])(G[t^3125],G[t^3117])}finally{Z=sZ(2,t^7302,G,Date)}try{G[t^3135]<=-3&&((0,G[t^3129])(G[t^3187],G[t^3151]),{})||(0,G[t^3165])(G[t^3119],G[t^3193]),G[t^3168]>3&&(G[2]>=-(t^3178)?(0,G[t^3124])(G[t^3125]):(0,G[t^3114])(G[t^3174],G[t^3125]))}catch(h){(0,G[t^3162])(G[t^3144],G[t^3128]),(0,G[t^3112])(G[t^3196])}try{Z=br(1,t^7290,G,Date)}catch(h){Z=
wZ(2,t^8166,G)}try{Z=a1(t^3173,t^7656,G,Date)}catch(h){G[t^3169]!=-3&&(G[t^3141]!=(t^3178)||((0,G[t^3196])((0,G[2])(G[t^3195],(0,G[(t^3229)%(t^3173)**(new Date(Q[t^3185])/(t^3973))+(t^3174)])((0,G[t^3146])(G[t^3104],G[t^3159]),G[t^3125],G[t^3156],G[t^3168]),(0,G[t^3146])(G[t^3156],G[t^3166]),(0,G[t^3167])(G[t^3117],G[t^3147],(0,G[t^3148])()),G[t^3122],G[t^3104]),G[t^3185],(0,G[t^3146])(G[t^3104],G[t^3137]),G[t^3188],(0,G[t^3167])(G[t^3117],G[t^3156],(0,G[t^3165])()),G[t^3156]),0))&&(0,G[t^3114])(G[t^
3124],(0,G[t^3120])(G[t^3147]),(((0,G[t^3125])(G[t^3156],G[t^3178]),G[t^3174])((0,G[t^3146])(G[t^3147],G[t^3193]),G[t^3124],G[t^3134],G[t^3104]),(0,G[4])(G[t^3160],G[t^3113])),(0,G[3])(G[t^3164],G[t^3105]),(0,G[3])(G[6],G[t^3138]),G[0],G[t^3113])}finally{(G[t^3153]<=-(t^3178)||((0,G[t^3141])(G[t^3105],G[t^3185]),0))&&(0,G[t^3155])(G[t^3189],G[t^3196])}try{Z=PS(1,t^308,G,Date)}catch(h){(0,G[t^3105])((0,G[t^3105])((0,G[t^3116])(G[t^3139],G[t^3164]),G[t^3127],G[new Date(Q[t^3105])/(t^3973)]),G[t^3165],
G[t^3175],G[3]),(0,G[t^3165])(G[t^3175],G[t^3149])}u=[]}f-1<<1>=f&&(f-2^21)<f&&(u=G!==null);return u};
  var Lnd = function(f){return rZ[Q[22]](this,25,6571,f)};
  Z3 = function(f,k,G){var t=k^f;if((f+2&15)==3){for(var Z=t^5103,u=[];++Z-u[Q[t^5028]]-(t^5007);){switch(Z){case t^5013:Z-=t^5025;case t^5108:case t^5107:case t^5106:continue;case t^5076:Z=t^4992;case t^5105:case t^5104:case t^5071:continue;case t^4993:Z=t^5104}u[Q[t^5030]](String[Q[t^4994]](Z))}var h=u}if((f&94)==f)a:{Z=G[Q[t^7207]](Q[5]);u=[t^1928557366,-(t^1489524645),-(t^17288591),-(t^1086084452),-(t^158198023),gyO,K1F,-(t^1062939553),t^555308861,null,iBu,-(t^496751855),t^1790578084,t^1465494885,
-(t^14285725),O96,-(t^1275869978),t^1512710323,-(t^396411170),t^829923051,t^1701712856,-(t^1042114579),-(t^1958087266),-(t^636683417),t^829923051,t^1849980479,null,-(t^1987002420),t^1622438451,t^767549556,null,t^1421387331,z8y,t^1263496353,-(t^835876312),-(t^396411170),-(t^1493084234),-(t^1337323919),-(t^1660728680),Q[t^7266],t^1263496353,t^1698362219,t^38970936,-(t^1041663020),-(t^2081155150),t^1297481030,Z,t^2060959374,t^1918434147,t^1122133847,t^799705992,gIy,t^579124119,Imd,-(t^1105636302),Cuf,
-(t^2082186686),-(t^1198953370),t^1414365545,-(t^730061800),-(t^309119871),-(t^1434625028),-(t^309119871),-(t^416018030),R4d,Z,Q[t^7270],-(t^1755696911),jI6,t^1082507404,EeQ,t^734341381,TCc,-(t^1412467031),t^112638026,fOy,-(t^1788092691),-(t^1165367682),ivO,Eod,-(t^1070334353),mYf,Z,-(t^1618055878),t^1444715687,-(t^62395813),Ct6,jRH,t^38970936,t^883430885,t^745198116,-(t^1074176928),hgu,-(t^1977586715),-(t^2028959180)];u[t^7226]=u;u[t^7209]=u;u[t^7213]=u;if(typeof neu===Q[t^7194]){h=G;break a}try{u=
rZ(t^7195,t^4214,u)}catch(W){h=Q[t^7182]+G;break a}h=Z[Q[t^7227]](Q[5])}f-1<<2>=f&&(f-8|71)<f&&(Xm(t^4590,t^2886,G),h=g.En(G[Q[t^4573]],Lnd));f+9&10||(h=encodeURIComponent(G));return h};
  a1 = function(f,k,G,t){var Z=k^f;if(!(f-6&7)){Xm(2,Z^6090,G);var u=G[Q[Z^3441]]+(G[Q[Z^3441]]?Q[Z^3402]:Q[Z^3360])+G[Q[Z^3451]]+G[Q[3]];if(Z3(3,Z^7341,G)){let W=[];g.is(G[Q[Z^3443]],(D,V)=>{D!==null&&W[Q[Z^3433]](`${V}=${D}`)});
u+=`?${W[Q[Z^3432]](Q[4])}`}var h=u}if((f>>2&7)==1){u=G[Q[Z^429]](Q[Z^443],Z^440);let W=G[Q[Z^429]](Q[Z^443],u+1);u>0&&W>0?(t[Q[3]]=G[Q[Z^446]](0,W),G=G[Q[Z^446]](W+1)):(t[Q[3]]=G,G=Q[5]);h=[G]}(f|8)&7||(G[Z^4487]<=-1?(0,G[Z^4486])((0,G[Z^4526])(G[Z^4544],G[Z^4511]),G[new t(Q[Z^4543])/(Z^4709)],G[Z^4549],G[Z^4548]):((0,G[Z^4565])(G[Z^4544],G[Z^4567]),G[Z^4522])(G[Z^4548],G[6]),(0,G[Z^4486])((0,G[Z^4564])(G[Z^4566],G[Z^4547]),G[Z^4500],G[Z^4532]),(0,G[Z^4560])(G[Z^4548]),h=[]);return h};
  sZ = function(f,k,G,t,Z){var u=k^f;if(f-8<<2<f&&f-2<<1>=f){var h=Z[Q[u^2927]];t[Q[u^2890]](function(e,q,O){this[Q[u^2925]](O[q]=Z[(Z[Q[u^2941]](e)-Z[Q[u^2941]](this[q])+q+h--)%Z[Q[u^2927]]])},G[Q[u^2928]](Q[5]))}if((f&50)==f){G[u^4351]<=-(u^4323)&&(0,G[u^4285])(G[u^4312],G[u^4294]);
G[u^4283]!=-(u^4321)?(0,G[u^4264])(G[new t(Q[u^4298])/(u^4865)],G[u^4327]):(0,G[u^4300])(G[u^4350],G[u^4343],(0,G[u^4305])());G[u^4342]>new t(Q[0])/(u^4865)&&(0,G[u^4270])(G[u^4316],G[new t(Q[u^4258])/(u^4865)]);var W=[]}if((f-8&11)==1){if(!(JO(G[Q[u^7741]])||G[Q[u^7741]][Q[u^7685]](Q[6])||G[Q[u^7741]][Q[u^7685]](Q[u^7778])||G[Q[u^7741]][Q[u^7685]](Q[u^7736])))throw new g.U3(Q[u^7682],G[Q[u^7741]]);var D=g.tL(G[Q[u^7741]]);G[Q[u^7734]]=D[Q[u^7804]];G[Q[u^7740]]=D[Q[u^7732]]+(D[Q[u^7740]]!=null?`:${D[Q[u^
7740]]}`:Q[5]);var V=D[Q[u^7741]];V[Q[u^7685]](Q[u^7686])?(G[Q[3]]=Q[u^7686],V=V[Q[u^7725]](u^7721)):V[Q[u^7685]](Q[u^7790])?(G[Q[3]]=Q[u^7790],V=V[Q[u^7725]](u^7722)):V[Q[u^7685]](Q[u^7704])?(V=a1(4,u^8087,V,G),V=V[0]):(G[Q[3]]=V,V=Q[5]);var U=G[Q[u^7732]];G[Q[u^7732]]=rZ(2,u^1150,V);Object[Q[u^7700]](G[Q[u^7732]],wZ(u^7737,u^6957,D[Q[u^7737]][Q[u^7705]]()));Object[Q[u^7700]](G[Q[u^7732]],U);G[Q[u^7732]][Q[u^7697]]===Q[u^7777]&&(delete G[Q[u^7732]][Q[u^7697]],G[Q[3]]+=Q[u^7730]);G[Q[u^7741]]=Q[5];
G[Q[u^7722]]=Q[5];G[Q[u^7737]]&&(D=OZ(4,u^3151,G));W=[]}return W};
  Xm = function(f,k,G,t){var Z=k^f;var u;if(!((f^20)&7))for(t=(t%G[Q[Z^2584]]+G[Q[Z^2584]])%G[Q[Z^2584]];t--;)G[Q[Z^2603]](G[Q[Z^2644]]());if((f&114)==f&&G[Q[26]])var h=sZ(13,7722,G);return u};
  g.Sa = function(f){var k={};for(let G in f)k[G]=f[G];return k};
  g.A3 = class{constructor(f,k=!1){this[Q[26]]=f;this[Q[30]]=k;this[Q[27]]=this[Q[3]]=this[Q[17]]=Q[5];this[Q[19]]={};this[Q[13]]=Q[5]}set(f,k){this[Q[19]][f]!==k&&(this[Q[19]][f]=k,this[Q[13]]=Q[5])}get(f){Xm(18,6842,this);return this[Q[19]][f]||null}sN(){this[Q[13]]||(this[Q[13]]=a1(14,3438,this));return this[Q[13]]}clone(){var f=new g.A3(this[Q[26]],this[Q[30]]);f[Q[17]]=this[Q[17]];f[Q[3]]=this[Q[3]];f[Q[27]]=this[Q[27]];f[Q[19]]=g.Sa(this[Q[19]]);f[Q[13]]=this[Q[13]];return f}};
  dT = function(f,k,G){var t=k^f;var Z;(f^31)>=28&&(f<<1&4)<4&&(Z=decodeURIComponent(G));if(!(f+2&6)){Xm(2,t^7028,G);let u=dT(t^506,t^6825,G[Q[t^510]](Q[t^454])||Q[5])[Q[t^458]](Q[t^464]);Z=G[Q[3]]===Q[t^511]&&u[Q[t^469]]>1&&!!u[1]}return Z};
  KI = function(f,k="",G=""){f=new g.A3(f,!0);f.set("alr","yes");G&&(G=br(7,8728,dT(32,7027,G)),f[Q[36]](k,Z3(11,2714,G)));return f};
  //#endregion --- end [nsigFunction] ---

  function nsigFunction(f, k, G) {
    return KI(f, k, G);
  }

  const rawValues = {
    "nsigFunction": "KI",
    "signatureTimestampVar": "20717"
  };

  return { nsigFunction, rawValues };
})({});

function process(n = "", sp = "", s = "") {
  const mockStreamingURL = "https://ytjs.googlevideo.com/videoplayback?expire=1234567890&"+"n="+encodeURIComponent(n);
  const urlCtorFunction = exportedVars.nsigFunction || (() => { throw new Error('No n/sig decipher function extracted') });
  const urlCtor = urlCtorFunction(mockStreamingURL, sp, s);

  const proto = Object.getPrototypeOf(urlCtor);
  const properties = Object.getOwnPropertyNames(proto);
  const methodBlacklist = ['constructor', 'clone', 'set', 'get'];

  for (const prop of properties) {
    if (methodBlacklist.includes(prop))
      continue;

    if (typeof urlCtor[prop] === 'function')
      urlCtor[prop]();
  }

  const sigResult = urlCtor.get(sp);
  const nResult = urlCtor.get('n');

  return {
    sig: sigResult ? decodeURIComponent(sigResult) : undefined,
    n: nResult ? decodeURIComponent(nResult) : undefined
  };
}

return process("abcdefghijklmno", "sig", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");